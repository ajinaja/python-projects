from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql

import datetime

app = Tk()


# insect to database
def save():
    bednumber = bed_number.get();
    patientname = patient_name.get();
    patientaddress = patient_address.get();
    patientphoneno = patient_phone_number.get();
    nextofkinname = next_of_kin_name.get();
    nextofkinnumber = next_of_kin_number.get();
    problem = e_problem.get();
    doctor = e_doctor.get();

    if (
            bednumber == "" or patientname == "" or patientaddress == "" or patientphoneno == "" or nextofkinname == "" or nextofkinnumber == "" or problem == "" or doctor == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hospital_management")
        cursor = con.cursor()
        cursor.execute(
            "insert into hospital_table values('" + bednumber + "','" + patientname + "', '" + patientaddress + "', '" + patientphoneno + "','" + nextofkinname + "', '" + nextofkinnumber + "','" + problem + "', '" + doctor + "')")
        cursor.execute("commit");

        bed_number.delete(0, 'end')
        patient_name.delete(0, 'end')
        patient_address.delete(0, 'end')
        patient_phone_number.delete(0, 'end')
        next_of_kin_name.delete(0, 'end')
        next_of_kin_number.delete(0, 'end')
        e_problem.delete(0, 'end')
        e_doctor.delete(0, 'end')

        # show()
        MessageBox.showinfo("Insert Status", "Item saved Successfully")
        con.close();


# delete from database
def delete():
    if (bed_number.get() == ""):
        MessageBox.showinfo("Delete  Status", "Bed space feild is compulsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hospital_management")
        cursor = con.cursor()
        cursor.execute("delete from hospital_table where bednumber='" + bed_number.get() + "'")
        cursor.execute("commit");

        bed_number.delete(0, 'end')
        patient_name.delete(0, 'end')
        patient_address.delete(0, 'end')
        patient_phone_number.delete(0, 'end')
        next_of_kin_name.delete(0, 'end')
        next_of_kin_number.delete(0, 'end')
        e_problem.delete(0, 'end')
        e_doctor.delete(0, 'end')
        # show()
        MessageBox.showinfo("Delete Status", "Record has been deleted successfully")
        con.close();

# update database
def update():
    bednumber = bed_number.get();
    patientname = patient_name.get();
    patientaddress = patient_address.get();
    patientphoneno = patient_phone_number.get();
    nextofkinname = next_of_kin_name.get();
    nextofkinnumber = next_of_kin_number.get();
    problem = e_problem.get();
    doctor = e_doctor.get();

    if (
            bednumber == "" or patientname == "" or patientaddress == "" or patientphoneno == "" or nextofkinname == "" or nextofkinnumber == "" or problem == "" or doctor == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hospital_management")
        cursor = con.cursor()
        cursor.execute(
            "Update hospital_table set bednumber='" + bednumber + "', patientname='" + patientname + "', patientaddress='" + patientaddress + "', patientphoneno='" + patientphoneno + "', nextofkinname='" + nextofkinname + "', nextofkinnumber='" + nextofkinnumber + "', problem='" + problem + "', doctor='" + doctor + "' where bednumber='" + bed_number.get() + "'")
        cursor.execute("commit");

        bed_number.delete(0, 'end')
        patient_name.delete(0, 'end')
        patient_address.delete(0, 'end')
        patient_phone_number.delete(0, 'end')
        next_of_kin_name.delete(0, 'end')
        next_of_kin_number.delete(0, 'end')
        e_problem.delete(0, 'end')
        e_doctor.delete(0, 'end')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();

# get from database
def get():
    if(bed_number.get() == ""):
        MessageBox.showinfo("Fetch  Status", "car serial number field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hospital_management")
        cursor = con.cursor()
        cursor.execute("select * from hospital_table where bednumber='"+ bed_number.get() +"'")
        rows = cursor.fetchall()


        for row in rows:
            patient_name.insert(0, row[1])
            patient_address.insert(0, row[2])
            patient_phone_number.insert(0, row[3])
            next_of_kin_name.insert(0, row[4])
            next_of_kin_number.insert(0, row[5])
            e_problem.insert(0, row[6])
            e_doctor.insert(0, row[7])

        con.close();

date = datetime.datetime.now().date()

# components
heading = Label(app, text="Hospital Management System (Patient Record)", font=('Goudy 26 bold'), fg='gray')
heading.place(x=60, y=0)

date_l = Label(app, text="Today's Date: " + str(date), font=('arial 12 '), fg='black')
date_l.place(x=700, y=480)

# bed number
bed_number = Label(app, text="Patient bed Number", font=('Goudy 12'), fg='black')
bed_number.place(x=30, y=70)
bed_number = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
bed_number.place(x=30, y=100, height=35, width=300)

# patient name
patient_name = Label(app, text="Patient Name", font=('Goudy 12'), fg='black')
patient_name.place(x=30, y=150)
patient_name = Entry(width=25, font=('arial 12 '), bg='gray', fg='white')
patient_name.place(x=30, y=180, height=35, width=300)

# patient address
patient_address = Label(app, text="Patient Address", font=('Goudy 12'), fg='black')
patient_address.place(x=30, y=230)
patient_address = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
patient_address.place(x=30, y=260, height=35, width=300)

# problem
e_problem = Label(app, text="Patient Problem", font=('Goudy 12'), fg='black')
e_problem.place(x=30, y=310)
e_problem = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
e_problem.place(x=30, y=340, height=35, width=300)

# patient phone number
patient_phone_number = Label(app, text="Patient Phone Number", font=('Goudy 12'), fg='black')
patient_phone_number.place(x=500, y=70)
patient_phone_number = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
patient_phone_number.place(x=500, y=100, height=35, width=300)

# next of kin name
next_of_kin_name = Label(app, text="Patient Next of Kin", font=('Goudy 12'), fg='black')
next_of_kin_name.place(x=500, y=150)
next_of_kin_name = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
next_of_kin_name.place(x=500, y=180, height=35, width=300)

# next of kin number
next_of_kin_number = Label(app, text="Next of Kin Number", font=('Goudy 12'), fg='black')
next_of_kin_number.place(x=500, y=230)
next_of_kin_number = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
next_of_kin_number.place(x=500, y=260, height=35, width=300)

# doctor
e_doctor = Label(app, text="Doctor", font=('Goudy 12'), fg='black')
e_doctor.place(x=500, y=310)
e_doctor = Entry(width=25, font=('arial 12'), bg='gray', fg='white')
e_doctor.place(x=500, y=340, height=35, width=300)

# button
save = Button(app, text="SAVE", width=15, height=2, bg='gray', command=save, cursor="hand2")
save.place(x=100, y=430)

delete = Button(app, text="DELETE", width=15, height=2, bg='gray', command=delete, cursor="hand2")
delete.place(x=300, y=430)

update = Button(app, text="UPDATE", width=15, height=2, bg='gray', command=update, cursor="hand2")
update.place(x=500, y=430)

get = Button(app, text="GET", width=15, height=2, bg='gray', command=get, cursor="hand2")
get.place(x=700, y=430)

app.title("Cafe Management System")
app.geometry('900x500')

app.mainloop()

