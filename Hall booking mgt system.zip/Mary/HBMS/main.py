import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql


def checks():
    rf_nos = e_rf_no.get()
    if (rf_nos == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Contact No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute("SELECT * FROM `event_records` WHERE `Reference_No`='" + rf_nos + "'")
        rows = curses.fetchall()

        if (rows):
            messagebox.showinfo("Insert Status", "Reference already Exist")
        else:
            check_book()

            con.close()
def check_book():
    rf_nos = e_rf_no.get()
    date_starts = e_date_start.get()
    date_ends = e_date_end.get()
    if (rf_nos == "" or date_starts == "" or date_ends == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Contact No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute("SELECT * FROM `event_records` WHERE `Date_Start` BETWEEN '" + date_starts + "' AND '" + date_ends + "' OR `Date_End` BETWEEN '" + date_starts + "' AND '" + date_ends +"' ")
        # SELECT * FROM `event_records` WHERE `Date_Start` BETWEEN '2022-06-27'AND '2022-06-27' OR `Date_End` BETWEEN '2022-06-27'AND '2022-06-27';
        # `Date_Start`, `Date_End`
        rows = curses.fetchall()

        if (rows):
            messagebox.showinfo("Insert Status", "This particular date has been booked")
        else:
            insert()

            con.close()

def clear():
    e_rf_no.delete(0, 'end')
    e_full_name.delete(0, 'end')
    e_contact_no.delete(0, 'end')
    e_email.delete(0, 'end')
    e_address.delete(0, 'end')
    e_event_type.delete(0, 'end')
    e_date_start.delete(0, 'end')
    e_date_end.delete(0, 'end')


def insert():
    rf_nos = e_rf_no.get()
    full_names = e_full_name.get()
    contact_nos = e_contact_no.get()
    emails = e_email.get()
    addresss = e_address.get()
    event_types = e_event_type.get()
    date_starts = e_date_start.get()
    date_ends = e_date_end.get()

    if (rf_nos == "" or full_names == "" or contact_nos == "" or emails == "" or addresss == "" or event_types == "" or date_starts == "" or date_ends == ""):
        messagebox.showinfo("Insert Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        cursor = con.cursor()
        cursor.execute("INSERT INTO `event_records`(`Reference_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Event_Type`, `Date_Start`, `Date_End`) VALUES ('" + rf_nos + "','" + full_names + "','" + contact_nos + "','" + emails + "','" + addresss + "','" + event_types + "','" + date_starts + "','" + date_ends + "')")
        #   INSERT INTO `event_records`(`ID`, `Reference_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Event_Type`, `Date_Start`, `Date_End`, `Created_Date`, `Last_Update`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11])
        cursor.execute("commit")

        e_rf_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_contact_no.delete(0, 'end')
        e_email.delete(0, 'end')
        e_address.delete(0, 'end')
        e_event_type.delete(0, 'end')
        e_date_start.delete(0, 'end')
        e_date_end.delete(0, 'end')

        messagebox.showinfo("Insert Status", "Inserted Successfully")
        con.close()


def delete():
    rf_nos = e_rf_no.get()
    if (rf_nos == ""):
        messagebox.showinfo("Delete Status", "Please, fill up the field of reference No.")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        cursor = con.cursor()
        cursor.execute("DELETE FROM `event_records` WHERE Reference_No='" + rf_nos + "' ")
        cursor.execute("commit")

        e_rf_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_contact_no.delete(0, 'end')
        e_email.delete(0, 'end')
        e_address.delete(0, 'end')
        e_event_type.delete(0, 'end')
        e_date_start.delete(0, 'end')
        e_date_end.delete(0, 'end')

        messagebox.showinfo("Delete Status", "Deleted Successfully")
        con.close()


def update():
    rf_nos = e_rf_no.get()
    full_names = e_full_name.get()
    contact_nos = e_contact_no.get()
    emails = e_email.get()
    addresss = e_address.get()
    event_types = e_event_type.get()
    date_starts = e_date_start.get()
    date_ends = e_date_end.get()

    if (rf_nos == "" or full_names == "" or contact_nos == "" or emails == "" or addresss == "" or event_types == "" or date_starts == "" or date_ends == ""):
        messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        cursor = con.cursor()
        cursor.execute("UPDATE `event_records` SET `Full_Name`='" + full_names + "',`Phone_No`='"+ contact_nos + "',`Email`='" + emails + "',`Address`='" + addresss + "',`Event_Type`='" + event_types + "',`Date_Start`='" + date_starts + "',`Date_End`='" + date_ends + "' WHERE `Reference_No`='" + rf_nos + "'")
        cursor.execute("commit");

        messagebox.showinfo("Update Status", "Updated Successfully")
        con.close()


def get():
    rf_nos = e_rf_no.get()
    if (rf_nos == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Contact No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="hbms")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute("SELECT * FROM `event_records` WHERE `Reference_No`='" + rf_nos + "'")
        rows = curses.fetchall()

        if (rows):
            for row in rows:
                # Clear

                e_rf_no.delete(0, 'end')
                e_full_name.delete(0, 'end')
                e_contact_no.delete(0, 'end')
                e_email.delete(0, 'end')
                e_address.delete(0, 'end')
                e_event_type.delete(0, 'end')
                e_date_start.delete(0, 'end')
                e_date_end.delete(0, 'end')
                #  Fetch
                e_rf_no.insert(0, row[1])
                e_full_name.insert(0, row[2])
                e_contact_no.insert(0, row[3])
                e_email.insert(0, row[4])
                e_address.insert(0, row[5])
                e_event_type.insert(0, row[6])
                e_date_start.insert(0, row[7])
                e_date_end.insert(0, row[8])
        else:
            e_rf_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_contact_no.delete(0, 'end')
            e_email.delete(0, 'end')
            e_address.delete(0, 'end')
            e_event_type.delete(0, 'end')
            e_date_start.delete(0, 'end')
            e_date_end.delete(0, 'end')
            messagebox.showinfo("Fetch Status", "Record does not exist")

        con.close()

# Create window object
app = Tk()


rf_no = Label(app, text='Hall Booking Management System', bg='black', fg='white', font=('bold', 22))
rf_no.place(x=100, y=2)


# Reference Number
rf_no = Label(app, text='Reference No.:', font=('bold', 15))
rf_no.place(x=20, y=50)

e_rf_no = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_rf_no.place(x=250, y=50)


# Name
full_name = Label(app, text='Name:', font=('bold', 15))
full_name.place(x=20, y=120)

e_full_name = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_full_name.place(x=250, y=120)


# Contact
contact_no = Label(app, text='Contact No.:', font=('bold', 15))
contact_no.place(x=20, y=190)

e_contact_no = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_contact_no.place(x=250, y=190)


# Email
email = Label(app, text='Email:', font=('bold', 15))
email.place(x=20, y=260)

e_email = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_email.place(x=250, y=260)


# Address
address = Label(app, text='Address:', font=('bold', 15))
address.place(x=20, y=330)

e_address = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_address.place(x=250, y=330)


# Event Type
event_type = Label(app, text='Event Type:', font=('bold', 15))
event_type.place(x=20, y=400)

e_event_type = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_event_type.place(x=250, y=400)


# Start Date
date_start = Label(app, text='Start Date:', font=('bold', 15))
date_start.place(x=20, y=470)

e_date_start = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_date_start.place(x=250, y=470)


# End Date
date_end = Label(app, text='End Date:', font=('bold', 14))
date_end.place(x=20, y=540)

e_date_end = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_date_end.place(x=250, y=540)



clear = Button(app, text="Reset", font="italic, 15", bg="gray", command=clear)
clear.place(x=600, y=390)

insert = Button(app, text="Save", font="italic, 15", bg="gold", command=checks)
insert.place(x=600, y=320)

delete = Button(app, text="Delete", font="italic, 15", bg="red", command=delete)
delete.place(x=600, y=460)

update = Button(app, text="Update", font="italic, 15", bg="green", command=update)
update.place(x=600, y=530)

get = Button(app, text="Search", fg="white", font="italic, 15", bg="blue", command=get)
get.place(x=600, y=250)

app.title('Hall Booking Management System')
app.geometry('700x630')
app.configure(bg="dark slate gray")

# Start program
app.mainloop()
