-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 11:09 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arichostelm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `S_N` int(11) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`S_N`, `Username`, `Password`) VALUES
(1, 'Admin', 'admin123'),
(2, 'Admin2', 'admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `beds`
--

CREATE TABLE `beds` (
  `ID` int(255) NOT NULL,
  `Buildings` int(255) NOT NULL,
  `Room_No` int(10) NOT NULL,
  `Bed_No` int(10) NOT NULL,
  `Status` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beds`
--

INSERT INTO `beds` (`ID`, `Buildings`, `Room_No`, `Bed_No`, `Status`) VALUES
(1, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE `buildings` (
  `ID` int(255) NOT NULL,
  `Reg_No` int(255) NOT NULL,
  `Full_Name` varchar(50) NOT NULL,
  `Phone_No` varchar(25) NOT NULL,
  `Email` varchar(35) NOT NULL,
  `Address` text NOT NULL,
  `Total_Room` int(5) NOT NULL,
  `Price` decimal(20,2) NOT NULL,
  `Payment_Type` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Status` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buildings`
--

INSERT INTO `buildings` (`ID`, `Reg_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Total_Room`, `Price`, `Payment_Type`, `Gender`, `Status`) VALUES
(1, 1, 'gygyugtyug', '76867', 'ghghjghj', 'Ore', 8, '50000.00', 'Cash', 'Male', 0),
(3, 2, 'dcjgfgfg', '76867', 'ghghjghj', 'Ore', 5, '40000.00', 'Cash', 'Female', 0),
(4, 3, 'hfkbdj', '6546', 'ghghjghj', 'Ondo', 8, '60000.00', 'Card', 'Male', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `ID` int(255) NOT NULL,
  `Building` int(255) NOT NULL,
  `Room_No` int(10) NOT NULL,
  `Total_Bed` int(10) NOT NULL,
  `Status` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`ID`, `Building`, `Room_No`, `Total_Bed`, `Status`) VALUES
(1, 2, 1, 8, 0),
(2, 2, 2, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `students_allocation_records`
--

CREATE TABLE `students_allocation_records` (
  `S_N` int(11) NOT NULL,
  `Matric_No` varchar(35) NOT NULL,
  `Full_name` varchar(75) NOT NULL,
  `Contact_No` varchar(25) NOT NULL,
  `Department` text NOT NULL,
  `Level` varchar(10) NOT NULL,
  `Address` text NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Building` int(11) NOT NULL,
  `Room_No` int(10) NOT NULL,
  `Bed_No` int(10) NOT NULL,
  `Status` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students_allocation_records`
--

INSERT INTO `students_allocation_records` (`S_N`, `Matric_No`, `Full_name`, `Contact_No`, `Department`, `Level`, `Address`, `Gender`, `Building`, `Room_No`, `Bed_No`, `Status`) VALUES
(3, 'FPI/CPE/19/001', 'JHJGHHG', '09087654545', 'Comp. Eng.', 'ND I', 'bkhghkjghkjb', 'Male', 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`S_N`);

--
-- Indexes for table `beds`
--
ALTER TABLE `beds`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `students_allocation_records`
--
ALTER TABLE `students_allocation_records`
  ADD PRIMARY KEY (`S_N`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `S_N` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `beds`
--
ALTER TABLE `beds`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buildings`
--
ALTER TABLE `buildings`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students_allocation_records`
--
ALTER TABLE `students_allocation_records`
  MODIFY `S_N` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
