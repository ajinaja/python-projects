import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql




def admin_login():

    # Create window object
    alp = Tk()

    def clear():
        e_username.delete(0, 'end')
        e_password.delete(0, 'end')

    def logins():
        usernames = e_username.get()
        passwords = e_password.get()

        if (usernames == "" or passwords == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the empty space ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            curses = con.cursor()
            curses.execute("SELECT * FROM `admin_login` WHERE `Username`='" + usernames + "' AND `Password`='" + passwords + "'")
            #  »Table: admin_login
            # SELECT `S_N`, ``, `` FROM `admin_login` WHERE 1
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Login Status", "Login Successful ...?")
                alp.withdraw()
                dashboard()
            else:
                messagebox.showinfo("Login Status", "Invalid Username or Password ...?")

            con.close()


    # Username
    username = Label(alp, text='Username:', font=('bold', 15))
    username.place(x=20, y=90)

    e_username = Entry(alp, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_username.place(x=250, y=90)


    # Password
    password = Label(alp, text='Password:', font=('bold', 15))
    password.place(x=20, y=160)

    e_password = Entry(alp, width=18, fg="#000", show='*', border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_password.place(x=250, y=160)


    clear = Button(alp, text="Reset", font="italic, 15", bg="white", command=clear)
    clear.place(x=300, y=230)

    login = Button(alp, text="Log In", font="italic, 15", bg="white", command=logins)
    login.place(x=400, y=230)


    alp.title('Administration Login')
    alp.geometry('580x350')

    # Start program
    alp.mainloop()

def dashboard():
    def add_buildings():
        adb.withdraw()
        add_buindings()


    def add_roomss():
        adb.withdraw()
        add_rooms()

    def add_bedss():
        adb.withdraw()
        add_bed11()

    def add_students():
        adb.withdraw()
        add_student11()
    def closes():
        adb.destroy()

    adb = Tk()
    tittle = Label(adb, text="Aric Hostel Allocating Management System", font=('bold', 15))
    tittle.place(x=290, y=5)
    closef = Button(adb, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=650, y=2)

    add_building = Button(adb, text="Add Building", font="italic, 35", bg="white", command=add_buildings)
    add_building.place(x=20, y=50)

    add_room = Button(adb, text="Add Bedroom", font="italic, 35", bg="white", command=add_roomss)
    add_room.place(x=350, y=50)

    add_bed = Button(adb, text="Add Bed", font="italic, 35", bg="white", command=add_bedss)
    add_bed.place(x=20, y=150)

    add_student = Button(adb, text="Book", font="italic, 35", bg="white", command=add_students)
    add_student.place(x=350, y=150)


    adb.title('Aric Hostel Allocating Management System')
    adb.geometry('700x450')

def add_buindings():
    def insert_building():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        emails = e_email.get()
        addresss = e_address.get()
        total_rooms = e_total_room.get()
        prices = e_price.get()
        payment_types = e_payment_type.get()
        genders = e_gender.get()

        if (reg_nos == "" or full_names == "" or contact_nos == "" or emails == "" or addresss == "" or total_rooms == "" or prices == "" or payment_types == "" or genders == ""):
            messagebox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("INSERT INTO `buildings`(`Reg_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Total_Room`, `Price`, `Payment_Type`, `Gender`) VALUES ('" + reg_nos + "','" + full_names + "','" + contact_nos + "','" + emails + "','" + addresss + "','" + total_rooms + "','" + prices + "','" + payment_types + "','" + genders + "')")
            cursor.execute("commit")

            e_reg_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_contact_no.delete(0, 'end')
            e_email.delete(0, 'end')
            e_address.delete(0, 'end')
            e_total_room.delete(0, 'end')
            e_price.delete(0, 'end')
            e_payment_type.delete(0, 'end')
            e_gender.delete(0, 'end')

            messagebox.showinfo("Insert Status", "Inserted Successfully")
            con.close()

    def checks():
        reg_nos = e_reg_no.get()
        if (reg_nos == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `buildings` WHERE `Reg_No`='" + reg_nos + "'")
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Insert Status", "Building already exist")
            else:
                insert_building()

                con.close()


    def delete():
        reg_nos = e_reg_no.get()
        if (reg_nos == ""):
            messagebox.showinfo("Delete Status", "Please, fill up the field of registration No.")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("DELETE FROM `buildings` WHERE Reg_No='" + reg_nos + "' ")
            # SELECT `ID`, `Reference_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Event_Type`, `Date_Start`, `Date_End`, `Created_Date`, `Last_Update` FROM `event_records` WHERE 1
            #
            # DELETE FROM `event_records` WHERE 0
            cursor.execute("commit");

            e_reg_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_contact_no.delete(0, 'end')
            e_email.delete(0, 'end')
            e_address.delete(0, 'end')
            e_total_room.delete(0, 'end')
            e_price.delete(0, 'end')
            e_payment_type.delete(0, 'end')
            e_gender.delete(0, 'end')

            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()


    def update():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        emails = e_email.get()
        addresss = e_address.get()
        total_rooms = e_total_room.get()
        prices = e_price.get()
        payment_types = e_payment_type.get()
        genders = e_gender.get()

        if (reg_nos == "" or full_names == "" or contact_nos == "" or emails == "" or addresss == "" or total_rooms == "" or prices == "" or payment_types == "" or genders == ""):
            messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("UPDATE `buildings` SET `Full_Name`='" + full_names + "',`Phone_No`='" + contact_nos + "',`Email`='" + emails + "',`Address`='" + addresss + "',`Total_Room`='"+ total_rooms + "',`Price`='" + prices + "',`Payment_Type`='" + payment_types + "', `Gender` ='" + genders + "' WHERE `Reg_No`='" + reg_nos + "'")
            cursor.execute("commit");

            messagebox.showinfo("Update Status", "Updated Successfully")
            con.close()


    def get():
        reg_nos = e_reg_no.get()
        if (reg_nos == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `buildings` WHERE Reg_No='" + reg_nos + "' ")
            rows = curses.fetchall()

            for row in rows:
                # Clear
                e_reg_no.delete(0, 'end')
                e_full_name.delete(0, 'end')
                e_contact_no.delete(0, 'end')
                e_email.delete(0, 'end')
                e_address.delete(0, 'end')
                e_total_room.delete(0, 'end')
                e_price.delete(0, 'end')
                e_payment_type.delete(0, 'end')
                e_gender.delete(0, 'end')
                #  Fetch
                e_reg_no.insert(0, row[1])
                e_full_name.insert(0, row[2])
                e_contact_no.insert(0, row[3])
                e_email.insert(0, row[4])
                e_address.insert(0, row[5])
                e_total_room.insert(0, row[6])
                e_price.insert(0, row[7])
                e_payment_type.insert(0, row[8])
                e_gender.insert(0, row[9])

                con.close()

    def clears():
        e_reg_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_contact_no.delete(0, 'end')
        e_email.delete(0, 'end')
        e_address.delete(0, 'end')
        e_total_room.delete(0, 'end')
        e_price.delete(0, 'end')
        e_payment_type.delete(0, 'end')
        e_gender.delete(0, 'end')
    def closes():
        app.withdraw()
        dashboard()

    # Create window object
    app = Tk()
    tittle = Label(app, text="Add a new Building", font=('bold', 15))
    tittle.place(x=290, y=5)
    closef = Button(app, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=650, y=2)

    # Registration Number
    reg_no = Label(app, text='Reg. No.:', font=('bold', 15))
    reg_no.place(x=20, y=40)

    e_reg_no = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_reg_no.place(x=250, y=40)


    # Name of Owner
    full_name = Label(app, text="Owner's Name:", font=('bold', 15))
    full_name.place(x=20, y=80)

    e_full_name = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_full_name.place(x=250, y=80)


    # Contact
    contact_no = Label(app, text='Contact No.:', font=('bold', 15))
    contact_no.place(x=20, y=120)

    e_contact_no = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_contact_no.place(x=250, y=120)


    # Email
    email = Label(app, text='Email:', font=('bold', 15))
    email.place(x=20, y=160)

    e_email = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_email.place(x=250, y=160)


    # Address
    address = Label(app, text='Address:', font=('bold', 18))
    address.place(x=20, y=200)

    e_address = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_address.place(x=250, y=200)


    # Total Room
    total_room = Label(app, text='Total Room:', font=('bold', 15))
    total_room.place(x=20, y=240)

    e_total_room = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_total_room.place(x=250, y=240)


    # Price
    price = Label(app, text='Price:', font=('bold', 15))
    price.place(x=20, y=280)

    e_price = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_price.place(x=250, y=280)


    # Payment Type
    payment_type = Label(app, text='Payment Type:', font=('bold', 15))
    payment_type.place(x=20, y=320)

    pt = ['Card', 'Pay Pal', 'Cash']

    e_payment_type = ttk.Combobox(app, values=pt, width=17, font=('Modern No. 20', 25, 'bold'))
    e_payment_type.place(x=250, y=320)

    # Payment Type
    gender = Label(app, text='Gender:', font=('bold', 15))
    gender.place(x=20, y=360)

    gd = ['Male', 'Female']

    e_gender = ttk.Combobox(app, values=gd, width=17, font=('Modern No. 20', 25, 'bold'))
    e_gender.place(x=250, y=360)



    clear = Button(app, text="Reset", font="italic, 15", bg="white", command=clears)
    clear.place(x=20, y=400)

    insert = Button(app, text="Insert", font="italic, 15", bg="white", command=checks)
    insert.place(x=100, y=400)

    delete = Button(app, text="Delete", font="italic, 15", bg="white", command=delete)
    delete.place(x=180, y=400)

    update = Button(app, text="Update", font="italic, 15", bg="white", command=update)
    update.place(x=260, y=400)

    get = Button(app, text="Search", font="italic, 15", bg="white", command=get)
    get.place(x=360, y=400)

    app.title('Hall Booking Management System')
    app.geometry('700x450')
    app.configure(bg="gray")

    # Start program
    app.mainloop()

def add_rooms():
    def insert_room():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()

        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("INSERT INTO `rooms`(`Building`, `Room_No`, `Total_Bed`) VALUES ('" + buildingss + "','" + room_nos + "','" + total_beds + "')")
            cursor.execute("commit")

            e_buildings.delete(0, 'end')
            e_room_no.delete(0, 'end')
            e_total_bed.delete(0, 'end')

            messagebox.showinfo("Insert Status", "Inserted Successfully")
            con.close()

    def checks():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        if (buildingss == "" or room_nos == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Building and Room No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `rooms` WHERE `Building`='" + buildingss + "' AND `Room_No`='" + room_nos + "'")
            # SELECT `ID`, `Building`, `Room_No`, `Total_Bed`, `Status` FROM `rooms` WHERE 1
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Insert Status", "Building already exist")
            else:
                insert_room()

                con.close()


    def delete():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        if (buildingss == "" or room_nos == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Building and Room No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("DELETE FROM `rooms` WHERE Building='" + buildingss + "' AND Room_No='" + room_nos + "' ")
            cursor.execute("commit")

            e_buildings.delete(0, 'end')
            e_room_no.delete(0, 'end')
            e_total_bed.delete(0, 'end')

            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()


    def update():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()

        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("UPDATE `rooms` SET `Total_Bed`='" + total_beds + "' WHERE `Building`='" + buildingss + "' AND `Room_No`='" + room_nos + "'")
            cursor.execute("commit")

            messagebox.showinfo("Update Status", "Updated Successfully")
            con.close()


    def get():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        if (buildingss == "" or room_nos == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Building and Room No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `rooms` WHERE Building='" + buildingss + "' AND Room_No='" + room_nos + "' ")
            # SELECT `ID`, `Building`, `Room_No`, `Total_Bed`, `Status` FROM `rooms` WHERE 1
            rows = curses.fetchall()

            for row in rows:
                # Clear
                e_buildings.delete(0, 'end')
                e_room_no.delete(0, 'end')
                e_total_bed.delete(0, 'end')
                #  Fetch
                e_buildings.insert(0, row[1])
                e_room_no.insert(0, row[2])
                e_total_bed.insert(0, row[3])

                con.close()

    def clears():
        e_buildings.delete(0, 'end')
        e_room_no.delete(0, 'end')
        e_total_bed.delete(0, 'end')
    def closes():
        ars.withdraw()
        dashboard()


    # Create window object
    ars = Tk()
    tittle = Label(ars, text="Add a new Room", font=('bold', 15))
    tittle.place(x=290, y=5)
    closef = Button(ars, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=550, y=2)
    # Room Number

    buildings = Label(ars, text='Reg. No.:', font=('bold', 15))
    buildings.place(x=20, y=50)

    buildin = []
    con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
    #  telephone_diary »Table: diary_records
    curses = con.cursor()
    curses.execute("SELECT * FROM `buildings` WHERE Status=0 ")
    rows = curses.fetchall()

    for row in rows:
        #  Fetch
        buildin.append(row[1])

    con.close()

    e_buildings = ttk.Combobox(ars, values=buildin, width=17, font=('Modern No. 20', 25, 'bold'))
    e_buildings.place(x=250, y=50)


    # Room Number
    room_no = Label(ars, text="Room No.:", font=('bold', 15))
    room_no.place(x=20, y=120)

    e_room_no = Entry(ars, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_room_no.place(x=250, y=120)


    # Total Bed
    total_bed = Label(ars, text='Total Bed:', font=('bold', 15))
    total_bed.place(x=20, y=190)

    e_total_bed = Entry(ars, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_total_bed.place(x=250, y=190)



    clear = Button(ars, text="Reset", font="italic, 15", bg="white", command=clears)
    clear.place(x=20, y=260)

    insert = Button(ars, text="Insert", font="italic, 15", bg="white", command=checks)
    insert.place(x=100, y=260)

    delete = Button(ars, text="Delete", font="italic, 15", bg="white", command=delete)
    delete.place(x=180, y=260)

    update = Button(ars, text="Update", font="italic, 15", bg="white", command=update)
    update.place(x=260, y=260)

    get = Button(ars, text="Fetch", font="italic, 15", bg="white", command=get)
    get.place(x=360, y=260)

    ars.title('Hall Booking Management System')
    ars.geometry('600x350')

    # Start program
    ars.mainloop()
def add_bed11():
    def insert_room():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()

        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("INSERT INTO `beds`(`Buildings`, `Room_No`, `Bed_No`) VALUES ('" + buildingss + "','" + room_nos + "','" + total_beds + "')")
            cursor.execute("commit")

            e_buildings.delete(0, 'end')
            e_room_no.delete(0, 'end')
            e_total_bed.delete(0, 'end')

            messagebox.showinfo("Insert Status", "Inserted Successfully")
            con.close()

    def checks():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()
        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the empty space ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `beds` WHERE `Buildings`='" + buildingss + "' AND `Room_No`='" + room_nos + "' AND `Bed_No`='" + total_beds + "' ")
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Insert Status", "Bed already exist")
            else:
                insert_room()

                con.close()


    def delete():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()
        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the empty space ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("DELETE FROM `beds` WHERE `Buildings`='" + buildingss + "' AND `Room_No`='" + room_nos + "' AND `Bed_No`='" + total_beds + "' ")
            # DELETE FROM `beds` WHERE 0
            cursor.execute("commit")

            e_buildings.delete(0, 'end')
            e_room_no.delete(0, 'end')
            e_total_bed.delete(0, 'end')

            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()



    def get():
        buildingss = e_buildings.get()
        room_nos = e_room_no.get()
        total_beds = e_total_bed.get()
        if (buildingss == "" or room_nos == "" or total_beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the empty space ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `beds` WHERE Buildings='" + buildingss + "' AND Room_No='" + room_nos + "' AND Bed_No='" + total_beds + "' ")
            # SELECT `ID`, `Buildings`, `Room_No`, `Bed_No`, `Status` FROM `beds` WHERE 1
            rows = curses.fetchall()

            for row in rows:
                # Clear
                e_buildings.delete(0, 'end')
                e_room_no.delete(0, 'end')
                e_total_bed.delete(0, 'end')
                #  Fetch
                e_buildings.insert(0, row[1])
                e_room_no.insert(0, row[2])
                e_total_bed.insert(0, row[3])

                con.close()

    def clears():
        e_buildings.delete(0, 'end')
        e_room_no.delete(0, 'end')
        e_total_bed.delete(0, 'end')
    def closes():
        asb.withdraw()
        dashboard()


    # Create window object
    asb = Tk()
    tittle = Label(asb, text="Add a new Bed", font=('bold', 15))
    tittle.place(x=250, y=5)
    closef = Button(asb, text="X", font="italic, 13",fg="red", bg="white", command=closes)
    closef.place(x=500, y=2)

    # Room Number

    buildings = Label(asb, text='Building Reg. No.:', font=('bold', 15))
    buildings.place(x=20, y=50)

    buildin = []
    con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
    #  telephone_diary »Table: diary_records
    curses = con.cursor()
    curses.execute("SELECT * FROM `buildings` WHERE Status=0 ")
    rows = curses.fetchall()

    for row in rows:
        #  Fetch
        buildin.append(row[1])

    con.close()

    e_buildings = ttk.Combobox(asb, values=buildin, width=18, font=('Modern No. 20', 25, 'bold'))
    e_buildings.place(x=200, y=50)


    # Room Number
    room_no = Label(asb, text="Room No.:", font=('bold', 15))
    room_no.place(x=20, y=100)

    room_no = []
    con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
    #  telephone_diary »Table: diary_records
    curses = con.cursor()
    curses.execute("SELECT * FROM `rooms` WHERE Status=0 ")
    # INSERT INTO `rooms`(`ID`, `Building`, `Room_No`, `Total_Bed`, `Status`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])
    results = curses.fetchall()

    for result in results:
        #  Fetch
        room_no.append(result[2])

    con.close()

    e_room_no = ttk.Combobox(asb, values=room_no, width=18, font=('Modern No. 20', 25, 'bold'))
    e_room_no.place(x=200, y=100)


    # Total Bed
    total_bed = Label(asb, text='Total Bed:', font=('bold', 15))
    total_bed.place(x=20, y=150)

    e_total_bed = Entry(asb, width=19, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_total_bed.place(x=200, y=150)



    clear = Button(asb, text="Reset", font="italic, 15", bg="white", command=clears)
    clear.place(x=80, y=200)

    insert = Button(asb, text="Insert", font="italic, 15", bg="white", command=checks)
    insert.place(x=160, y=200)

    delete = Button(asb, text="Delete", font="italic, 15", bg="white", command=delete)
    delete.place(x=240, y=200)

    """update = Button(ars, text="Update", font="italic, 15", bg="white", command=update)
    update.place(x=320, y=200) """

    get = Button(asb, text="Search", font="italic, 15", bg="white", command=get)
    get.place(x=320, y=200)

    asb.title('Hall Booking Management System')
    asb.geometry('550x290')

    # Start program
    asb.mainloop()

def add_student11():
    def update_beds():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
        cursor = con.cursor()
        cursor.execute(
            "UPDATE `beds` SET `Status`=1 WHERE   `Buildings`='" + buildingsss + "' AND  `Room_No`='" + room_nos + "' AND `Bed_No`='" + beds + "' ")
        # UPDATE `beds` SET `ID`=[value-1],`Buildings`=[value-2],`Room_No`=[value-3],`Bed_No`=[value-4],`Status`=[value-5] WHERE 1
        # UPDATE `beds` SET `ID`=[value-1],`Buildings`=[value-2],`Room_No`=[value-3],`Bed_No`=[value-4],`Status`=[value-5] WHERE 1
        cursor.execute("commit");

        # messagebox.showinfo("Update Status", "Updated Successfully")
        con.close()

    def insert_student():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        if (
                reg_nos == "" or full_names == "" or contact_nos == "" or departments == "" or levels == "" or addresss == "" or genders == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute(
                "INSERT INTO `students_allocation_records`(`Matric_No`, `Full_name`, `Contact_No`, `Department`, `Level`, `Address`, `Gender`, `Building`, `Room_No`, `Bed_No`) VALUES ('" + reg_nos + "', '" + full_names + "', '" + contact_nos + "', '" + departments + "', '" + levels + "', '" + addresss + "', '" + genders + "', '" + buildingsss + "', '" + room_nos + "', '" + beds + "') ")
            cursor.execute("commit")

            e_reg_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_contact_no.delete(0, 'end')
            e_department.delete(0, 'end')
            e_level.delete(0, 'end')
            e_address.delete(0, 'end')
            e_gender.delete(0, 'end')
            e_buildings.delete(0, 'end')
            e_room_no.delete(0, 'end')
            e_bed.delete(0, 'end')

            messagebox.showinfo("Insert Status", "Inserted Successfully")
            update_beds()
            con.close()

    def check_vacant():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        if (reg_nos == "" or contact_nos == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `students_allocation_records` WHERE `Building`='" + buildingsss + "' AND  `Room_No`='" + room_nos + "' AND `Bed_No`='" + beds + "' AND `Status`=1 ")
            # SELECT `S_N`, `Matric_No`, `Full_name`, `Contact_No`, `Department`, `Level`, `Address`, `Gender`, `Building`, `Room_No`, `Bed_No`, `Price` FROM `students_allocation_records` WHERE 1
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Insert Status",
                                    f"Bed No. {buildingsss} has been occupied in Room No. {room_nos} and in Building No. {beds}")
            else:
                insert_student()

                con.close()

    def check_aval_vacant():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        if (reg_nos == "" or contact_nos == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `beds` WHERE `Buildings`='" + buildingsss + "' AND  `Room_No`='" + room_nos + "' AND `Bed_No`='" + beds + "' AND `Status`=0 ")
            # SELECT `ID`, `Buildings`, `Room_No`, `Bed_No`, `Status` FROM `beds` WHERE 1
            rows = curses.fetchall()

            if (rows):
                check_vacant()
            else:
                messagebox.showinfo("Insert Status",
                                    f"Bed No. {buildingsss} available in Room No. {room_nos} and in Building No. {beds}")

                con.close()

    def checks():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        if (reg_nos == "" or contact_nos == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `students_allocation_records` WHERE `Matric_No`='" + reg_nos + "'")
            # SELECT `S_N`, `Matric_No`, `Full_name`, `Contact_No`, `Department`, `Level`, `Address`, `Gender`, `Building`, `Room_No`, `Bed_No`, `Price` FROM `students_allocation_records` WHERE 1
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Insert Status", "Student already exist")
            else:
                check_aval_vacant()

                con.close()

    def delete():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()
        if (reg_nos == "" or contact_nos == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Delete Status", "Please, fill up the field of registration No.")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute("DELETE FROM `students_allocation_records` WHERE Matric_No='" + reg_nos + "' ")
            # SELECT `ID`, `Reference_No`, `Full_Name`, `Phone_No`, `Email`, `Address`, `Event_Type`, `Date_Start`, `Date_End`, `Created_Date`, `Last_Update` FROM `event_records` WHERE 1
            #
            # DELETE FROM `event_records` WHERE 0
            cursor.execute("commit");

            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()

    def update():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()

        if (
                reg_nos == "" or full_names == "" or contact_nos == "" or departments == "" or levels == "" or addresss == "" or genders == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            cursor = con.cursor()
            cursor.execute(
                "UPDATE `students_allocation_records` SET `Full_name`='" + full_names + "',`Contact_No`='" + contact_nos + "',`Department`='" + departments + "',`Level`='" + levels + "',`Address`='" + addresss + "',`Gender`='" + genders + "',`Building`='" + buildingsss + "',`Room_No`='" + room_nos + "',`Bed_No`='" + beds + "' WHERE  Matric_No='" + reg_nos + "' ")
            cursor.execute("commit");

            messagebox.showinfo("Update Status", "Updated Successfully")
            con.close()

    def get():
        reg_nos = e_reg_no.get()
        full_names = e_full_name.get()
        contact_nos = e_contact_no.get()
        departments = e_department.get()
        levels = e_level.get()
        addresss = e_address.get()
        genders = e_gender.get()
        buildingsss = e_buildings.get()
        room_nos = e_room_no.get()
        beds = e_bed.get()
        if (reg_nos == "" or contact_nos == "" or buildingsss == "" or room_nos == "" or beds == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
            #  telephone_diary »Table: diary_records
            curses = con.cursor()
            curses.execute("SELECT * FROM `students_allocation_records` WHERE Matric_No='" + reg_nos + "' ")
            # SELECT `S_N`, `Matric_No`, `Full_name`, `Contact_No`, `Department`, `Level`, `Address`, `Gender`, `Building`, `Room_No`, `Bed_No`, `Price` FROM `students_allocation_records` WHERE 1
            rows = curses.fetchall()

            for row in rows:
                # Clear
                e_reg_no.delete(0, 'end')
                e_full_name.delete(0, 'end')
                e_contact_no.delete(0, 'end')
                e_department.delete(0, 'end')
                e_level.delete(0, 'end')
                e_address.delete(0, 'end')
                e_gender.delete(0, 'end')
                e_buildings.delete(0, 'end')
                e_room_no.delete(0, 'end')
                e_bed.delete(0, 'end')
                #  Fetch
                e_reg_no.insert(0, row[1])
                e_full_name.insert(0, row[2])
                e_contact_no.insert(0, row[3])
                e_department.insert(0, row[4])
                e_level.insert(0, row[5])
                e_address.insert(0, row[6])
                e_gender.insert(0, row[7])
                e_buildings.insert(0, row[8])
                e_room_no.insert(0, row[9])
                e_bed.insert(0, row[10])

                con.close()

    def clears():
        e_reg_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_contact_no.delete(0, 'end')
        e_department.delete(0, 'end')
        e_level.delete(0, 'end')
        e_address.delete(0, 'end')
        e_gender.delete(0, 'end')
        e_buildings.delete(0, 'end')
        e_room_no.delete(0, 'end')
        e_bed.delete(0, 'end')

    """def check():
        genders = e_gender.get()
        if (genders == ""):
            messagebox.showwarning("Info Status", "Please, fill up the gender field")
        else:
            def buildss():
                con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
                curses = con.cursor()
                curses.execute("SELECT * FROM `buildings` WHERE Status=0 AND Gender='" + genders + "' LIMIT 1")
                rows = curses.fetchall()

                for row in rows:
                    #  Fetch
                    e_buildings.delete(0, 'end')
                    e_buildings.insert(0, row[1])

                    roomss()
                    con.close()

            def roomss():
                builddd = e_buildings.get()
                if (builddd != ""):
                    con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
                    #  telephone_diary »Table: diary_records
                    curses = con.cursor()
                    curses.execute("SELECT * FROM `rooms` WHERE Building='" + builddd + "' AND Status=0 LIMIT 1")
                    # INSERT INTO `rooms`(`ID`, `Building`, `Room_No`, `Total_Bed`, `Status`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])
                    results = curses.fetchall()

                    for result in results:
                        #  Fetch
                        e_room_no.delete(0, 'end')
                        e_room_no.insert(0, result[2])

                        beds()
                        con.close()


            def beds():
                builddd = e_buildings.get()
                roomss = e_room_no.get()
                if (builddd != "" and roomss != ""):

                    con = mysql.connect(host="localhost", user="root", password="", database="arichostelm")
                    #  telephone_diary »Table: diary_records
                    curses = con.cursor()
                    curses.execute(
                        "SELECT * FROM `beds` WHERE Status=0 AND `Buildings`='" + builddd + "' AND Room_No='" + roomss + "' LIMIT 1")
                    rows = curses.fetchall()

                    for row in rows:
                        #  Fetch
                        e_bed.delete(0, 'end')
                        e_bed.insert(0, row[3])

                    con.close()

            buildss() """
    def closes():
        har.withdraw()
        dashboard()

    # Create window object
    har = Tk()
    tittle = Label(har, text="Allocating an Hostel", font=('bold', 15))
    tittle.place(x=290, y=5)
    closef = Button(har, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=950, y=2)

    # Registration Number
    reg_no = Label(har, text='Reg/Matric. No.:', font=('bold', 15))
    reg_no.place(x=20, y=50)

    e_reg_no = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_reg_no.place(x=200, y=50)

    # Name of Owner
    full_name = Label(har, text="Full Name:", font=('bold', 15))
    full_name.place(x=20, y=120)

    e_full_name = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_full_name.place(x=200, y=120)

    # Contact
    contact_no = Label(har, text='Phone No.:', font=('bold', 15))
    contact_no.place(x=20, y=190)

    e_contact_no = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_contact_no.place(x=200, y=190)

    # Department
    department = Label(har, text='Department:', font=('bold', 15))
    department.place(x=20, y=260)

    e_department = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_department.place(x=200, y=260)

    # Level
    level = Label(har, text='Level:', font=('bold', 15))
    level.place(x=20, y=330)

    e_level = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_level.place(x=200, y=330)

    # Address
    address = Label(har, text='Address:', font=('bold', 15))
    address.place(x=20, y=400)

    e_address = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_address.place(x=200, y=400)

    # Address
    gender = Label(har, text='Gender:', font=('bold', 15))
    gender.place(x=20, y=470)
    gl = ['Male', 'Female']
    e_gender = ttk.Combobox(har, values=gl, width=18, font=('Modern No. 20', 23, 'bold'))
    e_gender.place(x=200, y=470)

    buildings = Label(har, text='Building No.:', font=('bold', 15))
    buildings.place(x=550, y=50)

    e_buildings = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_buildings.place(x=730, y=50)

    # Room Number
    room_no = Label(har, text="Room No.:", font=('bold', 15))
    room_no.place(x=550, y=120)

    e_room_no = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_room_no.place(x=730, y=120)

    bed = Label(har, text='Bed No.:', font=('bold', 15))
    bed.place(x=550, y=190)

    e_bed = Entry(har, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_bed.place(x=730, y=190)

    clear = Button(har, text="Reset", font="italic, 15", bg="white", command=clears)
    clear.place(x=500, y=400)

    insert = Button(har, text="Insert", font="italic, 15", bg="white", command=checks)
    insert.place(x=600, y=400)

    delete = Button(har, text="Delete", font="italic, 15", bg="white", command=delete)
    delete.place(x=700, y=400)

    update = Button(har, text="Update", font="italic, 15", bg="white", command=update)
    update.place(x=800, y=400)

    get = Button(har, text="Search", font="italic, 15", bg="white", command=get)
    get.place(x=900, y=400)
    # get.geometry('1500x30')

    """check = Button(har, text="Check", font="italic, 15", bg="white", command=check)
    check.place(x=900, y=350)"""

    har.title('Aric Hostel Allocating Management System')
    har.geometry('1200x550')

    # Start program
    har.mainloop()

admin_login()