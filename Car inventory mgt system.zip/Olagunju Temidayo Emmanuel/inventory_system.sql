-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 11:15 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `carserialnumber` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phoneno` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `nameofcar` varchar(100) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `carmodel` varchar(50) NOT NULL,
  `caryear` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`carserialnumber`, `name`, `phoneno`, `address`, `nameofcar`, `quantity`, `carmodel`, `caryear`, `price`) VALUES
('utiutiuuti', 'jg', 'iiu', 'yiuyi', 'uyiu', 'iyi', 'yiuy', 'uyiu', 'yiu'),
('uyo', 'dami', '0809090900', 'odolo street, ile-oluji', 'lambo', 's40', '2', '2022', '700000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`carserialnumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
