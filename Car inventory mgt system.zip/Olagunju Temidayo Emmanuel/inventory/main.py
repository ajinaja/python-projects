from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql

import datetime

app = Tk()


# insect to database
def save():
    carserialnumber = car_serial_number.get();
    name = name_of_rental.get();
    phoneno = phone_number.get();
    address = home_address.get();
    nameofcar = name_of_car.get();
    quantity = Quantity.get();
    carmodel = car_model.get();
    caryear = car_year.get();
    price = Price.get();

    if (
            carserialnumber == "" or carserialnumber == "Car Serial Number" or
            name == "" or name == "Name of Rental" or
            phoneno == "" or phoneno == "Phone Number" or
            address == "" or address == "Home Address" or
            nameofcar == "" or nameofcar == "Name of Car" or
            carmodel == "" or carmodel == "Car Model" or
            quantity == "" or quantity == "Quantity" or
            caryear == "" or caryear == "Car Year" or
            price == "" or price == "Amount"):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="inventory_system")
        cursor = con.cursor()
        cursor.execute(
            "insert into inventory values('" + carserialnumber + "','" + name + "', '" + phoneno + "', '" + address + "', '" + nameofcar + "', '" + quantity + "', '" + carmodel + "', '" + caryear + "', '" + price + "')")
        cursor.execute("commit");

        car_serial_number.delete(0, 'end')
        name_of_rental.delete(0, 'end')
        phone_number.delete(0, 'end')
        home_address.delete(0, 'end')
        name_of_car.delete(0, 'end')
        car_model.delete(0, 'end')
        Quantity.delete(0, 'end')
        car_year.delete(0, 'end')
        Price.delete(0, 'end')

        car_serial_number.insert(0, 'Car Serial Number')
        name_of_rental.insert(0, 'Name of Rental')
        phone_number.insert(0, 'Phone Number')
        home_address.insert(0, 'Home Address')
        name_of_car.insert(0, 'Name of Car')
        car_model.insert(0, 'Car Model')
        Quantity.insert(0, 'Quantity')
        car_year.insert(0, 'Car Year')
        Price.insert(0, 'Amount')
        # show()
        MessageBox.showinfo("Insert Status", "Saved Successfully")
        con.close();


# delete from database
def delete():
    if (car_serial_number.get() == "Car Serial Number"):
        MessageBox.showerror("Delete  Status", "Car serial number feild is compuqsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="inventory_system")
        cursor = con.cursor()
        cursor.execute("delete from inventory where carserialnumber='" + car_serial_number.get() + "'")
        cursor.execute("commit");

        car_serial_number.delete(0, 'end')
        name_of_rental.delete(0, 'end')
        phone_number.delete(0, 'end')
        home_address.delete(0, 'end')
        name_of_car.delete(0, 'end')
        car_model.delete(0, 'end')
        Quantity.delete(0, 'end')
        car_year.delete(0, 'end')
        Price.delete(0, 'end')

        car_serial_number.insert(0, 'Car Serial Number')
        name_of_rental.insert(0, 'Name of Rental')
        phone_number.insert(0, 'Phone Number')
        home_address.insert(0, 'Home Address')
        name_of_car.insert(0, 'Name of Car')
        car_model.insert(0, 'Car Model')
        Quantity.insert(0, 'Quantity')
        car_year.insert(0, 'Car Year')
        Price.insert(0, 'Amount')
        # show()
        MessageBox.showinfo("Delete Status", "Deleted Successfully")
        con.close();


# update database
def update():
    carserialnumber = car_serial_number.get();
    name = name_of_rental.get();
    phoneno = phone_number.get();
    address = home_address.get();
    nameofcar = name_of_car.get();
    quantity = Quantity.get();
    carmodel = car_model.get();
    caryear = car_year.get();
    price = Price.get();

    if (
            carserialnumber == "" or carserialnumber == "Car Serial Number" or
            name == "" or name == "Name of Rental" or
            phoneno == "" or phoneno == "Phone Number" or
            address == "" or address == "Home Address" or
            nameofcar == "" or nameofcar == "Name of Car" or
            carmodel == "" or carmodel == "Car Model" or
            quantity == "" or quantity == "Quantity" or
            caryear == "" or caryear == "Car Year" or
            price == "" or price == "Amount"):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="inventory_system")
        cursor = con.cursor()
        cursor.execute(
            "Update inventory set carserialnumber='" + carserialnumber + "', name='" + name + "', phoneno='" + phoneno + "', address='" + address + "', nameofcar='" + nameofcar + "', carmodel='" + carmodel + "', quantity='" + quantity + "', caryear='" + caryear + "', price='" + price + "' where carserialnumber='" + carserialnumber + "'")
        cursor.execute("commit");

        car_serial_number.delete(0, 'end')
        name_of_rental.delete(0, 'end')
        phone_number.delete(0, 'end')
        home_address.delete(0, 'end')
        name_of_car.delete(0, 'end')
        car_model.delete(0, 'end')
        Quantity.delete(0, 'end')
        car_year.delete(0, 'end')
        Price.delete(0, 'end')

        car_serial_number.insert(0, 'Car Serial Number')
        name_of_rental.insert(0, 'Name of Rental')
        phone_number.insert(0, 'Phone Number')
        home_address.insert(0, 'Home Address')
        name_of_car.insert(0, 'Name of Car')
        car_model.insert(0, 'Car Model')
        Quantity.insert(0, 'Quantity')
        car_year.insert(0, 'Car Year')
        Price.insert(0, 'Amount')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();


# get from database
def get():
    if (car_serial_number.get() == "Car Serial Number" or car_serial_number.get() == ""):
        MessageBox.showerror("Fetch  Status", "car serial number field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="inventory_system")
        cursor = con.cursor()
        cursor.execute("select * from inventory where carserialnumber='" + car_serial_number.get() + "'")
        rows = cursor.fetchall()


        name_of_rental.delete(0, 'end')
        phone_number.delete(0, 'end')
        home_address.delete(0, 'end')
        name_of_car.delete(0, 'end')
        car_model.delete(0, 'end')
        Quantity.delete(0, 'end')
        car_year.delete(0, 'end')
        Price.delete(0, 'end')

        for row in rows:
            name_of_rental.insert(0, row[1])
            phone_number.insert(0, row[2])
            home_address.insert(0, row[3])
            name_of_car.insert(0, row[4])
            car_model.insert(0, row[5])
            Quantity.insert(0, row[6])
            car_year.insert(0, row[7])
            Price.insert(0, row[8])

        con.close();

def refresh():
    car_serial_number.delete(0, 'end')
    name_of_rental.delete(0, 'end')
    phone_number.delete(0, 'end')
    home_address.delete(0, 'end')
    name_of_car.delete(0, 'end')
    car_model.delete(0, 'end')
    Quantity.delete(0, 'end')
    car_year.delete(0, 'end')
    Price.delete(0, 'end')

    car_serial_number.insert(0, 'Car Serial Number')
    name_of_rental.insert(0, 'Name of Rental')
    phone_number.insert(0, 'Phone Number')
    home_address.insert(0, 'Home Address')
    name_of_car.insert(0, 'Name of Car')
    car_model.insert(0, 'Car Model')
    Quantity.insert(0, 'Quantity')
    car_year.insert(0, 'Car Year')
    Price.insert(0, 'Amount')


date = datetime.datetime.now().date()

frame = Frame(app, width=450, height=500, bg='#fff')
frame.place(x=8, y=50)

rightframe = Frame(app, width=200, height=500, bg='black')
rightframe.place(x=470, y=50)

# components
heading = Label(app, text="Inventory Rental Management System (Car Rental)", font=('Pristina 25 bold'), fg='white',
                bg="gray")
heading.place(x=30, y=0)

date_l = Label(rightframe, text="Today's Date: " + str(date), font=('papyrus 12 '), fg='white', bg="black")
date_l.place(x=5, y=460)


# car_serial_number
def on_enter(e):
    car_serial_number.delete(0, 'end')


def on_leave(e):
    if car_serial_number.get() == "":
        car_serial_number.insert(0, 'Car Serial Number')


heading = Label(frame, text='Car Rental Details', fg="#57a1f8", bg='white',
                font=('Microsoft Yahei Ui Light', 20, 'bold'))
heading.place(x=100, y=10)

car_serial_number = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
car_serial_number.place(x=10, y=60)
car_serial_number.insert(0, 'Car Serial Number')
car_serial_number.bind("<FocusIn>", on_enter)
car_serial_number.bind("<FocusOut>", on_leave)

Frame(frame, width=400, height=2, bg='black').place(x=10, y=85)


# name_of_rental
def on_enter(e):
    name_of_rental.delete(0, 'end')


def on_leave(e):
    if name_of_rental.get() == '':
        name_of_rental.insert(0, 'Name of Rental')


name_of_rental = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
name_of_rental.place(x=10, y=100)
name_of_rental.insert(0, 'Name of Rental')
name_of_rental.bind("<FocusIn>", on_enter)
name_of_rental.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=125)


# Phone
def on_enter(e):
    phone_number.delete(0, 'end')


def on_leave(e):
    if phone_number.get() == '':
        phone_number.insert(0, 'Phone Number')


phone_number = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
phone_number.place(x=10, y=140)
phone_number.insert(0, 'Phone Number')
phone_number.bind("<FocusIn>", on_enter)
phone_number.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=165)


# Home Address
def on_enter(e):
    home_address.delete(0, 'end')


def on_leave(e):
    if home_address.get() == '':
        home_address.insert(0, 'Home Address')


home_address = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
home_address.place(x=10, y=180)
home_address.insert(0, 'Home Address')
home_address.bind("<FocusIn>", on_enter)
home_address.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=205)


# name_of_car
def on_enter(e):
    name_of_car.delete(0, 'end')


def on_leave(e):
    if name_of_car.get() == '':
        name_of_car.insert(0, 'Name of Car')


name_of_car = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
name_of_car.place(x=10, y=220)
name_of_car.insert(0, 'Name of Car')
name_of_car.bind("<FocusIn>", on_enter)
name_of_car.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=245)


# Car model
def on_enter(e):
    car_model.delete(0, 'end')


def on_leave(e):
    if car_model.get() == '':
        car_model.insert(0, 'Car Model')


car_model = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
car_model.place(x=10, y=260)
car_model.insert(0, 'Car Model')
car_model.bind("<FocusIn>", on_enter)
car_model.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=285)


# quantity
def on_enter(e):
    Quantity.delete(0, 'end')


def on_leave(e):
    if Quantity.get() == '':
        Quantity.insert(0, 'Quantity')


Quantity = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
Quantity.place(x=10, y=300)
Quantity.insert(0, 'Quantity')
Quantity.bind("<FocusIn>", on_enter)
Quantity.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=325)


# Car Year
def on_enter(e):
    car_year.delete(0, 'end')


def on_leave(e):
    if car_year.get() == '':
        car_year.insert(0, 'Car Year')


car_year = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
car_year.place(x=10, y=340)
car_year.insert(0, 'Car Year')
car_year.bind("<FocusIn>", on_enter)
car_year.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=365)


# price
def on_enter(e):
    Price.delete(0, 'end')


def on_leave(e):
    if Price.get() == '':
        Price.insert(0, 'Amount')


Price = Entry(frame, width=50, fg="black", border=0, bg='white', font=('Microsoft Yahei Ui Light', 11))
Price.place(x=10, y=380)
Price.insert(0, 'Amount')
Price.bind("<FocusIn>", on_enter)
Price.bind("<FocusOut>", on_leave)
Frame(frame, width=400, height=2, bg='black').place(x=10, y=405)

# button
save = Button(frame, text="SAVE", width=15, pady=5, font="Forte",
              height=2, bg='#57a1f8', fg="white", command=save, cursor="hand2")
save.place(x=30, y=430)

update = Button(frame, text="UPDATE", width=15, height=2, bg='#57a1f8', font="Forte",
                pady=5, fg="white", command=update, cursor="hand2")
update.place(x=250, y=430)

heading = Label(rightframe, text='Other Actions', fg="white", bg='black',
                font=('Microsoft Yahei Ui Light', 15, 'bold'))
heading.place(x=30, y=40)

delete = Button(rightframe, text="DELETE", width=15, height=2, bg='black', pady=5,
                fg="white", font="Forte", command=delete, cursor="hand2")
delete.place(x=30, y=130)

get = Button(rightframe, text="GET", width=15, height=2, bg='black', pady=5,
             fg="white", font="Forte", command=get, cursor="hand2")
get.place(x=30, y=210)

refresh = Button(rightframe, text="REFRESH", width=15, height=2, bg='black', pady=5,
             fg="white", font="Forte", command=refresh, cursor="hand2")
refresh.place(x=30, y=300)


app.title("Inventory Rental Management System (Car Rental)")
app.geometry('700x600')
app.configure(border="3", bg="gray")

app.mainloop()
