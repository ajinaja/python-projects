from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql
def save():
    Surname=entry1.get()
    Othername = entry2.get()
    DOB = entry3.get()
    Gender = entry4.get()
    MatricNo = entry5.get()
    MaritalStatus = entry6.get()
    LocalGov = entry7.get()
    Address = entry8.get()
    State = entry9.get()
    Nationality = entry10.get()
    Year = entry11.get()
    School = entry12.get()
    PhoneNo = entry13.get()
    SponsorName = entry14.get()
    SponsorPhone = entry15.get()
    NameofNextKin = entry16.get()
    NextofKinPhone =entry17.get()
    Relationship = entry18.get()

    if(Surname=="" or
            Othername=="" or
            DOB=="" or
            Gender=="" or
            MatricNo=="" or
            MaritalStatus=="" or
            LocalGov=="" or
            Address=="" or
            State=="" or
            Nationality=="" or
            Year=="" or
            School=="" or
            PhoneNo=="" or
            SponsorName=="" or
            SponsorPhone=="" or
            NameofNextKin=="" or
            NextofKinPhone=="" or
            Relationship==""):
        MessageBox.showerror("Insert Field","All Field Are Require ")
    else:
        con = mysql.connect(host="localhost",user="root", password="", database="student_python" )
        cursor = con.cursor()
        cursor.execute(
            "insert into studentpy value('"+Surname+"','"+Othername+"','"+DOB+"','"+Gender+"','"+MatricNo+"','"+MaritalStatus+"','"+LocalGov+"','"+Address+"','"+State+"','"+Nationality+"','"+Year+"','"+School+"','"+PhoneNo+"','"+SponsorName+"','"+SponsorPhone+"','"+NameofNextKin+"','"+NextofKinPhone+"','"+Relationship+"' )"
        )
        cursor.execute("commit")
        entry1.delete(0, 'end')
        entry2.delete(0, 'end')
        entry3.delete(0, 'end')
        entry4.delete(0, 'end')
        entry5.delete(0, 'end')
        entry6.delete(0, 'end')
        entry7.delete(0, 'end')
        entry8.delete(0, 'end')
        entry9.delete(0, 'end')
        entry10.delete(0, 'end')
        entry11.delete(0, 'end')
        entry12.delete(0, 'end')
        entry13.delete(0, 'end')
        entry14.delete(0, 'end')
        entry15.delete(0, 'end')
        entry16.delete(0, 'end')
        entry17.delete(0, 'end')
        entry18.delete(0, 'end')
        MessageBox.showinfo("Insert Field", "SUCCESSFUL ")

def search():
    MatricNo= entry5.get()
    if (MatricNo == ""):
        MessageBox.showerror("Insert Field","All Field Are Require ")
    else:
        con = mysql.connect(host="localhost",user="root", password="", database="student_python" )
        cursor = con.cursor()
        cursor.execute(
            "select* from studentpy where MatricNo='"+entry5.get()+ " '"
        )
        rows= cursor.fetchall()

        for row in rows:
            entry1.insert(0, row[0])
            entry2.insert(0, row[1])
            entry3.insert(0, row[2])
            entry4.insert(0, row[3])
            entry6.insert(0, row[4])
            entry7.insert(0, row[5])
            entry8.insert(0, row[6])
            entry9.insert(0, row[7])
            entry10.insert(0, row[8])
            entry11.insert(0, row[9])
            entry12.insert(0, row[10])
            entry13.insert(0, row[10])
            entry14.insert(0, row[11])
            entry15.insert(0, row[12])
            entry16.insert(0, row[13])
            entry17.insert(0, row[14])
            entry18.insert(0, row[15])
        con.close();
def update():
    Surname = entry1.get()
    Othername = entry2.get()
    DOB = entry3.get()
    Gender = entry4.get()
    MatricNo = entry5.get()
    MaritalStatus = entry6.get()
    LocalGov = entry7.get()
    Address = entry8.get()
    State = entry9.get()
    Nationality = entry10.get()
    Year = entry11.get()
    School = entry12.get()
    PhoneNo = entry13.get()
    SponsorName = entry14.get()
    SponsorPhone = entry15.get()
    NameofNextKin = entry16.get()
    NextofKinPhone = entry17.get()
    Relationship = entry18.get()

    if (Surname == "" or
            Othername == "" or
            DOB == "" or
            Gender == "" or
            MatricNo == "" or
            MaritalStatus == "" or
            LocalGov == "" or
            Address == "" or
            State == "" or
            Nationality == "" or
            Year == "" or
            School == "" or
            PhoneNo == "" or
            SponsorName == "" or
            SponsorPhone == "" or
            NameofNextKin == "" or
            NextofKinPhone == "" or
            Relationship == ""):
        MessageBox.showerror("Update Status", "Please, fill up the empty space....?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="student_python")
        cursor = con.cursor()
        cursor.execute("UPDATE 'studentpy' SET 'Surname'='"+Surname+"','Othername'='"+Othername+"','DOB='"+DOB+"','Gender'='"+Gender+"','MatricNo'='"+MatricNo+"','MaritalStatus'='"+MaritalStatus +"','LocalGov'='"+LocalGov +"','Address'='"+Address +"','State'='"+State +"','Nationality'='"+Nationality +"','Year'='"+Year +"','School'='"+School +"','PhoneNo'='"+PhoneNo +"','SponsorName'='"+SponsorName +"','Sponsorphone'='"+SponsorPhone +"','NameofNextKin'='"+NameofNextKin +"','NextofKinPhone'='"+NextofKinPhone +"','Relationship'='"+Relationship +"','where MatricNo='"+MatricNo+"")
        cursor.execute("commit");
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close()


root = Tk()
root.geometry("650x650")
root.title("REGISTRATION PAGE")
root.configure(bg="blue")
label = Label(root, text="Welcome to Student Portal", font=("impact 25"))
label.place(x=120, y=10)
label = Label(root, text="STUDENT'S BIO DATA", font=("century 15  bold"))
label.place(x=20, y=70)
label = Label(root, text="Surname:", font=("bold", 12))
label.place(x=20, y=120)
entry1 = Entry()
entry1.place(x=120, y=120)

label = Label(root, text="Other Name:", font=("bold", 12))
label.place(x=20, y=160)
entry2 = Entry()
entry2.place(x=120, y=160)

label = Label(root, text="Date of Birth:", font=("bold", 12))
label.place(x=20, y=200)
entry3 = Entry()
entry3.place(x=120, y=200)

label = Label(root, text="Gender:", font=("bold", 12))
label.place(x=20, y=240)
entry4 = Entry()
entry4.place(x=120, y=240)

label = Label(root, text="Matric No:", font=("bold", 12))
label.place(x=20, y=280)
entry5 = Entry()
entry5.place(x=120, y=280)

label = Label(root, text="Marital Status:", font=("bold", 12))
label.place(x=20, y=320)
entry6 = Entry()
entry6.place(x=120, y=320)

label = Label(root, text="Local Gov:", font=("bold", 12))
label.place(x=20, y=360)
entry7= Entry()
entry7.place(x=120, y=360)

label = Label(root, text="Address:", font=("bold", 12))
label.place(x=20, y=400)
entry8 = Entry()
entry8.place(x=120, y=400)

label = Label(root, text="State:", font=("bold", 12))
label.place(x=20, y=440)
entry9 = Entry()
entry9.place(x=120, y=440)


label = Label(root, text="Nationality:", font=("bold", 12))
label.place(x=300, y=120)
entry10 = Entry()
entry10.place(x=430, y=120)

label = Label(root, text="Year:", font=("bold", 12))
label.place(x=300, y=160)
entry11 = Entry()
entry11.place(x=430, y=160)

label = Label(root, text="School:", font=("bold", 12))
label.place(x=300, y=200)
entry12 = Entry()
entry12.place(x=430, y=200)

label = Label(root, text="phone No:", font=("bold", 12))
label.place(x=300, y=240)
entry13 = Entry()
entry13.place(x=430, y=240)

label = Label(root, text="Sponsor Name:", font=("bold", 12))
label.place(x=300, y=280)
entry14 = Entry()
entry14.place(x=430, y=280)

label = Label(root, text="Sponsor phone:", font=("bold", 12))
label.place(x=300, y=320)
entry15 = Entry()
entry15.place(x=430, y=320)

label = Label(root, text="Name of Next kin:", font=("bold", 12))
label.place(x=300, y=360)
entry16= Entry()
entry16.place(x=430, y=360)

label = Label(root, text="Next of kin phone:", font=("bold", 12))
label.place(x=300, y=400)
entry17 = Entry()
entry17.place(x=430, y=400)

label = Label(root, text="Relationship:", font=("bold", 12))
label.place(x=300, y=440)
entry18 = Entry()
entry18.place(x=430, y=440)







save = Button(root,text="Save", width=15, height=2,font=("century 10  bold"),command=save)
save.place(x=50  , y=520)
search = Button(root,text="Search", width=15, height=2,font=("century 10  bold"),command=search)
search.place(x=200, y=520)
update = Button(root,text="Upadate", width=15, height=2,font=("century 10  bold"),command=update)
update.place(x=350  , y=520)
delete = Button(root,text="Delete",width=15, height=2,font=("century 10  bold"))
delete.place(x=500 , y=520)





root.mainloop()