-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 02:26 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_python`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentpy`
--

CREATE TABLE `studentpy` (
  `Surname` varchar(25) NOT NULL,
  `Othername` varchar(25) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `MatricNo` varchar(50) NOT NULL,
  `MaritalStatus` varchar(50) NOT NULL,
  `LocalGov` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Nationality` varchar(50) NOT NULL,
  `Year` varchar(50) NOT NULL,
  `School` varchar(50) NOT NULL,
  `PhoneNo` varchar(50) NOT NULL,
  `SponsorName` varchar(50) NOT NULL,
  `SponsorPhone` varchar(50) NOT NULL,
  `NameofNextkin` varchar(50) NOT NULL,
  `NextofKinphone` varchar(50) NOT NULL,
  `Relationship` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentpy`
--

INSERT INTO `studentpy` (`Surname`, `Othername`, `DOB`, `Gender`, `MatricNo`, `MaritalStatus`, `LocalGov`, `Address`, `State`, `Nationality`, `Year`, `School`, `PhoneNo`, `SponsorName`, `SponsorPhone`, `NameofNextkin`, `NextofKinphone`, `Relationship`) VALUES
('ML;', 'ML;', 'ML;', 'HJ', 'HINIO', 'IN', 'NN', 'HIO', 'N', 'NH', 'KN', 'KNK', 'NI', 'NNHI', 'NN', 'NN', 'NKN', 'NKL'),
('jadjndfkiohweh', 'kjfokgfjjd', '12/02/20000', 'male', 'fpi/hnd/csc21/001', 'single', 'oriade', 'osun', 'osun', 'nigeria', '2021', 'applied science', '5162632656', 'dee', '2168478945', 'ojo', '35189789', 'brother');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
