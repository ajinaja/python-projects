import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql

def insert_staff():
    questions = e_question.get()
    option_as = e_option_a.get()
    option_bs = e_option_b.get()
    option_cs = e_option_c.get()
    option_ds = e_option_d.get()
    answers1 = e_answer.get()

    if (answers1 == 'A'):
        answers_c = option_as
    elif (answers1 == 'B'):
        answers_c = option_bs
    elif (answers1 == 'C'):
        answers_c = option_cs
    elif (answers1 == 'D'):
        answers_c = option_ds

    if (questions == "" or option_as == "" or option_bs == "" or option_cs == "" or option_ds == "" or answers1 == ""):
        messagebox.showinfo("Insert Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="quiz_game")
    cursor = con.cursor()
    cursor.execute("INSERT INTO `quiz_questions`(`Questions`, `Option_A`, `Option_B`, `Option_C`, `Option_D`, `Answer`) VALUES ('" + questions + "', '" + option_as + "', '" + option_bs + "', '" + option_cs + "', '" + option_ds + "', '" + answers_c + "')")
    cursor.execute("commit")

    e_question.delete(0, 'end')
    e_option_a.delete(0, 'end')
    e_option_b.delete(0, 'end')
    e_option_c.delete(0, 'end')
    e_option_d.delete(0, 'end')
    e_answer.delete(0, 'end')

    messagebox.showinfo("Insert Status", "Inserted Successfully")
    con.close()

def check_input():
    questions = e_question.get()
    if (questions == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of questions ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="quiz_game")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute("SELECT * FROM `quiz_questions` WHERE `Questions`='" + questions + "'")
        # SELECT `ID`, `Questions`, `Option_A`, `Option_B`, `Option_C`, `Option_D`, `Answer` FROM `quiz_questions` WHERE 1
        rows = curses.fetchall()

        if (rows):
            messagebox.showwarning("Info Status", "Question. already exist")
        else:
            insert_staff()

            con.close()


def delete():
    questions = e_question.get()
    if (questions == ""):
        messagebox.showinfo("Delete Status", "Please, fill up the field of question")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="quiz_game")
        cursor = con.cursor()
        cursor.execute("DELETE FROM `quiz_questions` WHERE Questions='" + questions + "' ")
        # DELETE FROM `quiz_questions` WHERE 0
        cursor.execute("commit");

        e_question.delete(0, 'end')
        e_option_a.delete(0, 'end')
        e_option_b.delete(0, 'end')
        e_option_c.delete(0, 'end')
        e_option_d.delete(0, 'end')
        e_answer.delete(0, 'end')

        messagebox.showinfo("Delete Status", "Deleted Successfully")
        con.close()


def update():
    questions = e_question.get()
    option_as = e_option_a.get()
    option_bs = e_option_b.get()
    option_cs = e_option_c.get()
    option_ds = e_option_d.get()
    answers = e_answer.get()

    if (questions == "" or option_as == "" or option_bs == "" or option_cs == "" or option_ds == "" or answers == ""):
        messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="quiz_game")
        cursor = con.cursor()
        cursor.execute("UPDATE `quiz_questions` SET `Option_A`='" + option_as + "',`Option_B`='" + option_bs + "',`Option_C`='" + option_cs + "',`Option_D`='" + option_ds + "',`Answer`='" + answers + "'  WHERE Questions='" + questions + "' ")
        cursor.execute("commit");

        messagebox.showinfo("Update Status", "Updated Successfully")
        con.close()


def get():
    questions = e_question.get()
    if (questions == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Registration No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="quiz_game")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute(
            "SELECT * FROM `quiz_questions` WHERE `Questions`='" + questions + "'")
        # SELECT `ID`, `Questions`, `Option_A`, `Option_B`, `Option_C`, `Option_D`, `Answer` FROM `quiz_questions` WHERE 1
        #  quiz_game »Table: quiz_questions
        rows = curses.fetchall()

        if (rows):
            for row in rows:
                # Clear

                e_question.delete(0, 'end')
                e_option_a.delete(0, 'end')
                e_option_b.delete(0, 'end')
                e_option_c.delete(0, 'end')
                e_option_d.delete(0, 'end')
                e_answer.delete(0, 'end')
                #  Fetch

                e_question.insert(0, row[1])
                e_option_a.insert(0, row[2])
                e_option_b.insert(0, row[3])
                e_option_c.insert(0, row[4])
                e_option_d.insert(0, row[5])
                e_answer.insert(0, row[6])

                con.close()
        else:
            messagebox.showwarning("Status Info", "There in no Staff with Reg. No. of '" + questions + "'")
def clear():
    e_question.delete(0, 'end')
    e_option_a.delete(0, 'end')
    e_option_b.delete(0, 'end')
    e_option_c.delete(0, 'end')
    e_option_d.delete(0, 'end')
    e_answer.delete(0, 'end')

# Create window object
# app = tkinter.Tk()
app = Tk()

app.configure(bg="dark slate blue")

# Heading
heading = Label(app, text='Quiz Questions', bg='green', font=('bold', 20))
heading.place(x=500, y=2)

# Name
question = Label(app, text='Question:', font=('bold', 18))
question.place(x=20, y=50)

e_question = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_question.place(x=250, y=50)


option_a = Label(app, text='Option A:', font=('bold', 18))
option_a.place(x=20, y=120)

e_option_a = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_option_a.place(x=250, y=120)

option_b = Label(app, text='Option B:', font=('bold', 18))
option_b.place(x=20, y=190)

e_option_b = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_option_b.place(x=250, y=190)

option_c = Label(app, text='Option C:', font=('bold', 18))
option_c.place(x=20, y=260)

e_option_c = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_option_c.place(x=250, y=260)

# Contact
option_d = Label(app, text='Option D:', font=('bold', 18))
option_d.place(x=20, y=330)

e_option_d = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_option_d.place(x=250, y=330)


answer = Label(app, text='Answer:', font=('bold', 18))
answer.place(x=20, y=400)
gdr = ['A', 'B', 'C', 'D']
e_answer = ttk.Combobox(app, values=gdr, width=15, font=('bold', 25))
e_answer.place(x=250, y=400)


clear = Button(app, text="Reset", font="italic, 18", bg="gray", command=clear)
clear.place(x=1000, y=480)

insert = Button(app, text="Save", font="italic, 18", bg="gold", command=check_input)
insert.place(x=880, y=480)

delete = Button(app, text="Delete", font="italic, 18", bg="red", command=delete)
delete.place(x=1000, y=550)

update = Button(app, text="Update", font="italic, 18", bg="green", command=update)
update.place(x=880, y=550)

get = Button(app, text="Search", font="italic, 18", bg="blue", fg="white", command=get)
get.place(x=760, y=480)

app.title('Staff Record Management System')
app.geometry('1200x650')

# Start program
app.mainloop()
