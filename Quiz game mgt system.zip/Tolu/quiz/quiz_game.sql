-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 06:53 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz_game`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `Username`, `Password`) VALUES
(1, 'Admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `ID` int(255) NOT NULL,
  `Question_ID` int(255) NOT NULL,
  `Answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `ID` int(255) NOT NULL,
  `Question_ID` int(255) NOT NULL,
  `A` text NOT NULL,
  `B` text NOT NULL,
  `C` text NOT NULL,
  `D` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `ID` int(255) NOT NULL,
  `Question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `ID` int(255) NOT NULL,
  `Questions` text NOT NULL,
  `Option_A` text NOT NULL,
  `Option_B` text NOT NULL,
  `Option_C` text NOT NULL,
  `Option_D` text NOT NULL,
  `Answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quiz_questions`
--

INSERT INTO `quiz_questions` (`ID`, `Questions`, `Option_A`, `Option_B`, `Option_C`, `Option_D`, `Answer`) VALUES
(1, 'What is the full meaning of CPU?', 'Computer Processing Unit.', 'Central Processing Unit.', 'Computer Programming Unit.', 'Computer Processing Usage.', 'Central Processing Unit.'),
(2, 'The following are the components of computer except?', 'Motherboard', 'HDD', 'Socket', 'DVD Drive', 'Socket'),
(3, 'The following are the components of Motherboard except?', 'Processor', 'HDD', 'BIOS', 'Flash Drive', 'Flash Drive'),
(4, 'Which of the following is an example of Computer System Port?', 'USB Port', 'RAM Port', 'BIOS Port', 'Drive Port', 'USB Port'),
(5, 'Which of the following is an example of  slot on Computer Motherboard Port?', 'USB', 'RAM Slot', 'Battary Slot', 'UPS Slot', 'RAM Slot'),
(6, 'What is the full meaning of POST?', 'Power On Self Test', 'Put On System Terminal', 'Program Of Software Testing ', 'Processing On Self Test', 'Power On Self Test'),
(7, '2 + 2 * 30 - 50 ?', '100', '75', '70', '10', '70'),
(8, 'Nigeria get their independent on ___________?', '1st of October 1960', '1st of October 1996', '31st of September 1960', '1st of May 1956', '1st of October 1960'),
(9, 'Nigeria comprises of how many state?', '90', '35', '36', '45', '36'),
(10, 'Which of the following act as the brain of the Computer?', 'CPU', 'HDD', 'RAM', 'BIOS', 'CPU'),
(11, 'Full meaning of CSC ?', 'Counter Sequence', 'Computer Studies', 'Computer System', 'Computer Science', 'Computer Science');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
