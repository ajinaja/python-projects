-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2022 at 10:27 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pycomputer`
--

-- --------------------------------------------------------

--
-- Table structure for table `storeitems`
--

CREATE TABLE `storeitems` (
  `id` int(11) NOT NULL,
  `itemname` text NOT NULL,
  `itemcolor` text NOT NULL,
  `itembrand` text NOT NULL,
  `itemqty` int(11) NOT NULL,
  `itemprice` int(11) NOT NULL,
  `totalprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `storeitems`
--

INSERT INTO `storeitems` (`id`, `itemname`, `itemcolor`, `itembrand`, `itemqty`, `itemprice`, `totalprice`) VALUES
(1, 'Laptop', 'GREEN', 'COMPAQ', 1, 80000, 80000),
(2, 'Charger', 'BLACK', 'APPLE', 2, 8000, 16000),
(3, 'Charger', 'BLACK', 'APPLE', 3, 8000, 24000),
(4, 'CPU', 'GRAY', ' DELL', 1, 30000, 30000),
(5, 'Laptop casen', 'BLUE', 'LENOVO', 2, 19000, 38000),
(6, 'Keyboard', 'SILVER', 'APPLE', 2, 13000, 26000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `storeitems`
--
ALTER TABLE `storeitems`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
