import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql


def insert():
    id = e_id.get()
    comParts = e_comParts.get()
    itemcolor = e_itemcolor.get()
    brand = e_brand.get()
    qty = e_qty.get()
    price = e_price.get()
    Tprice = e_Tprice.get()

    if id == "" or comParts == "" or itemcolor == "" or brand == "" or qty == "" or price == "" or Tprice == "":
        messagebox.showinfo("Insert Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="pycomputer")
    cursor = con.cursor()
    cursor.execute("insert into storeitems values('" + id + "','" + comParts + "','" + itemcolor + "','" + brand + "','" + qty + "','" + price + "','" + Tprice + "')")
    cursor.execute("commit")

    e_id.delete(0, 'end')
    e_comParts.delete(0, 'end')
    e_itemcolor.set("")
    e_brand.set("")
    e_qty.delete(0, 'end')
    e_price.delete(0, 'end')
    e_Tprice.delete(0, 'end')
    messagebox.showinfo("Insert Status", "Inserted Successfully")
    con.close()


def delete():
    if e_id.get() == "":
        messagebox.showinfo("Delete Status", "ID is needed for deletion")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="pycomputer")
    cursor = con.cursor()
    cursor.execute("delete from storeitems where id='" + e_id.get() + "'")
    cursor.execute("commit")

    e_id.delete(0, 'end')
    e_comParts.delete(0, 'end')
    e_itemcolor.set("")
    e_brand.set("")
    e_qty.delete(0, 'end')
    e_price.delete(0, 'end')
    e_Tprice.delete(0, 'end')
    messagebox.showinfo("Delete Status", "Item Deleted Successfully")
    con.close()


def update():
    id = e_id.get()
    comParts = e_comParts.get()
    itemcolor = e_itemcolor.get()
    brand = e_brand.get()
    qty = e_qty.get()
    price = e_price.get()
    Tprice = e_Tprice.get()

    if id == "" or comParts == "" or itemcolor == "" or brand == "" or qty == "" or price == "" or Tprice == "":
        messagebox.showinfo("Update Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="pycomputer")
    cursor = con.cursor()
    cursor.execute(
        "update storeitems set itemname='" + comParts + "', itemcolor='" + itemcolor + "', itembrand='" + brand + "',itemqty='" + qty + "', itemprice='" + price + "', totalprice='" + Tprice + "' where id='" + id + "'")
    cursor.execute("commit")

    e_id.delete(0, 'end')
    e_comParts.delete(0, 'end')
    e_itemcolor.set("")
    e_brand.set("")
    e_qty.delete(0, 'end')
    e_price.delete(0, 'end')
    e_Tprice.delete(0, 'end')
    messagebox.showinfo("Update Status", "Updated Successfully")
    con.close()


def get():
    if e_id.get() == "":
        messagebox.showinfo("Fetch Status", "ID is needed to fetch")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="pycomputer")
        curses = con.cursor()
        curses.execute("select * from storeitems where id='" + e_id.get() + "'")
        rows = curses.fetchall()

        for row in rows:
            e_comParts.insert(0, row[1])
            e_itemcolor.set(row[2])
            e_brand.set(row[3])
            e_qty.insert(0, row[4])
            e_price.insert(0, row[5])
            e_Tprice.insert(0, row[6])

            con.close()


def clear():
    e_id.delete(0, 'end')
    e_comParts.delete(0, 'end')
    e_itemcolor.set('')
    e_brand.set('')
    e_qty.delete(0, 'end')
    e_price.delete(0, 'end')
    e_Tprice.delete(0, 'end')


# Create window object
app = Tk()
# ID
id = Label(app, text='Enter ID', font=('bold', 14), bg='#FF7F4F')
id.place(x=20, y=30)

# ComParts
comParts = Label(app, text='Item Name', font=('bold', 14), bg='#FF7F4F')
comParts.place(x=20, y=60)

# ItemDescription
itemcolor = Label(app, text='Enter Color', font=('bold', 14), bg='#FF7F4F')
itemcolor.place(x=20, y=90)

# ItemBrand
brand = Label(app, text='Item Brand', font=('bold', 14), bg='#FF7F4F')
brand.place(x=20, y=120)

# Quantity
qty = Label(app, text='Item Quantity', font=('bold', 14), bg='#FF7F4F')
qty.place(x=20, y=150)

# Price
price = Label(app, text='Item Price', font=('bold', 14), bg='#FF7F4F')
price.place(x=20, y=180)

# TPrice
Tprice = Label(app, text='Total Price', font=('bold', 14), bg='#FF7F4F')
Tprice.place(x=20, y=213)

e_id = Entry()
e_id.place(x=150, y=30)
e_id.focus()

e_comParts = Entry()
e_comParts.place(x=150, y=60)
e_comParts.focus()

e_itemcolor = tk.StringVar()
itemcolor = ttk.Combobox(app, width=17, textvariable=e_itemcolor)
# Adding combobox drop down list
itemcolor['values'] = ('AMBER',
                       'BLACK',
                       'BLUE',
                       'BROWN',
                       'CHOCOLATE',
                       'COFFEE',
                       'GOLD',
                       'GRAY',
                       'GREEN',
                       'INDIGO',
                       'IVORY',
                       'LEMON',
                       'ORANGE',
                       'PEACH',
                       'PINK',
                       'PURPLE',
                       'RED',
                       'SILVER',
                       'WHITE',
                       'YELLOW',)
itemcolor.place(x=150, y=90)
itemcolor.focus()

e_brand = tk.StringVar()
brand = ttk.Combobox(app, width=17, textvariable=e_brand)

# Adding combobox drop down list
brand['values'] = (' DELL',
                   'HP',
                   'APPLE',
                   'EMachine',
                   'TOSHIBA',
                   'SAMSUNG',
                   'LENOVO',
                   'ACER',
                   'ASUS',
                   'MICROSOFT',
                   'SONY',
                   'COMPAQ',
                   'IBM',
                   'IBALL')

brand.place(x=150, y=120)
brand.focus()

e_qty = Entry()
e_qty.place(x=150, y=150)
e_qty.focus()

e_price = Entry()
e_price.place(x=150, y=180)
e_price.focus()

e_Tprice = Entry()
e_Tprice.place(x=150, y=213)
e_Tprice.focus()

insert = Button(app, text="Insert", font="italic, 10", bg="green", command=insert)
insert.place(x=20, y=250)

delete = Button(app, text="Delete", font="italic, 10", bg="red", command=delete)
delete.place(x=70, y=250)

update = Button(app, text="Update", font="italic, 10", bg="yellow", command=update)
update.place(x=130, y=250)

get = Button(app, text="Fetch", font="italic, 10", bg="grey", command=get)
get.place(x=190, y=250)

clear = Button(app, text="Clear", font="italic, 10", bg="grey", command=clear)
clear.place(x=250, y=250)

app.title('Computer Parts Management System')
app.geometry('700x350')
app.configure(bg='#FF7F4F')
app.resizable(False, False)
# Start program
app.mainloop()
