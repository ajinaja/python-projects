from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql
from tkinter import ttk

import datetime

app = Tk()


# insect to database
def save():
    customerid = customer_id.get();
    firstname = first_name.get();
    lastname = last_name.get();
    homeaddress = home_address.get();
    phonenumber = phone_number.get();
    gender = e_gender.get();
    agerange = age_range.get();
    item = e_item.get();
    price = e_price.get();

    if (
            customerid == "" or firstname == "" or lastname == "" or homeaddress == "" or phonenumber == "" or gender == ""or agerange == "" or item == "" or price == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="customer_table")
        cursor = con.cursor()
        cursor.execute(
            "insert into customer values('" + customerid + "','" + firstname + "', '" + lastname + "', '" + homeaddress + "','" + phonenumber + "', '" + gender + "', '" + agerange + "','" + item + "', '" + price + "')")
        cursor.execute("commit");

        customer_id.delete(0, 'end')
        first_name.delete(0, 'end')
        last_name.delete(0, 'end')
        home_address.delete(0, 'end')
        phone_number.delete(0, 'end')
        e_gender.delete(0, 'end')
        age_range.delete(0, 'end')
        e_item.delete(0, 'end')
        e_price.delete(0, 'end')

        # show()
        MessageBox.showinfo("Insert Status", "Customer Details saved Successfully")
        con.close();


# delete from database
def delete():
    if (customer_id.get() == ""):
        MessageBox.showinfo("Delete  Status", "Customer ID feild is compulsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="customer_table")
        cursor = con.cursor()
        cursor.execute("delete from customer where customerid='" + customer_id.get() + "'")
        cursor.execute("commit");

        customer_id.delete(0, 'end')
        first_name.delete(0, 'end')
        last_name.delete(0, 'end')
        home_address.delete(0, 'end')
        phone_number.delete(0, 'end')
        e_gender.delete(0, 'end')
        age_range.delete(0, 'end')
        e_item.delete(0, 'end')
        e_price.delete(0, 'end')
        # show()
        MessageBox.showinfo("Delete Status", "Customer details has been deleted successfully")
        con.close();


# update database
def update():
    customerid = customer_id.get();
    firstname = first_name.get();
    lastname = last_name.get();
    homeaddress = home_address.get();
    phonenumber = phone_number.get();
    gender = e_gender.get();
    agerange = age_range.get();
    item = e_item.get();
    price = e_price.get();

    if (
            customerid == "" or firstname == "" or lastname == "" or homeaddress == "" or phonenumber == "" or gender == "" or agerange == "" or item == "" or price == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="customer_table")
        cursor = con.cursor()
        cursor.execute(
            "Update customer set customerid='" + customerid + "', firstname='" + firstname + "', lastname='" + lastname + "', homeaddress='" + homeaddress + "', phonenumber='" + phonenumber + "', gender='" + gender + "', agerange='" + agerange + "', item='" + item + "', price='" + price + "' where customerid='" + customer_id.get() + "'")
        cursor.execute("commit");

        customer_id.delete(0, 'end')
        first_name.delete(0, 'end')
        last_name.delete(0, 'end')
        home_address.delete(0, 'end')
        phone_number.delete(0, 'end')
        e_gender.delete(0, 'end')
        age_range.delete(0, 'end')
        e_item.delete(0, 'end')
        e_price.delete(0, 'end')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();


# get from database
def get():
    if (customer_id.get() == ""):
        MessageBox.showinfo("Fetch  Status", "Customer ID field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="customer_table")
        cursor = con.cursor()
        cursor.execute("select * from customer where customerid='" + customer_id.get() + "'")
        rows = cursor.fetchall()

        for row in rows:
            first_name.insert(0, row[1])
            last_name.insert(0, row[2])
            home_address.insert(0, row[3])
            phone_number.insert(0, row[4])
            e_gender.insert(0, row[5])
            age_range.insert(0, row[6])
            e_item.insert(0, row[7])
            e_price.insert(0, row[8])

        con.close();


# components
heading = Label(app, text="Customer Billing System", font=('Goudy 30 bold'), fg='black')
heading.place(x=200, y=0)

# customer ID
customer_id = Label(app, text="Customer ID", font=('Goudy 12'), fg='black')
customer_id.place(x=30, y=70)
customer_id = Entry(width=25, font=('arial 12'), bg='white')
customer_id.place(x=30, y=100, height=35, width=400)

# firstname
first_name = Label(app, text="Firstname", font=('Goudy 12'), fg='black')
first_name.place(x=30, y=150)
first_name = Entry(width=25, font=('arial 12 '), bg='white')
first_name.place(x=30, y=180, height=35, width=400)

# lastname
last_name = Label(app, text="Lastname", font=('Goudy 12'), fg='black')
last_name.place(x=30, y=230)
last_name = Entry(width=25, font=('arial 12'), bg='white')
last_name.place(x=30, y=260, height=35, width=400)

# item
e_item = Label(app, text="Item", font=('Goudy 12'), fg='black')
e_item.place(x=30, y=310)
e_item = ttk.Combobox(app, width=25, font=('arial 12'))
e_item["values"] = ("Phone", "Personal Computer (PC)", "Desktop Computer", "Printer", "Scanner")
e_item.place(x=30, y=340, height=35, width=400)

# Home Address
home_address = Label(app, text="Home Address", font=('Goudy 12'), fg='black')
home_address.place(x=500, y=70)
home_address = Entry(width=25, font=('arial 12'), bg='white')
home_address.place(x=500, y=100, height=35, width=400)

# phone number
phone_number = Label(app, text="Phone Number", font=('Goudy 12'), fg='black')
phone_number.place(x=500, y=150)
phone_number = Entry(width=25, font=('arial 12'), bg='white')
phone_number.place(x=500, y=180, height=35, width=400)

# gender
e_gender = Label(app, text="Gender", font=('Goudy 12'), fg='black')
e_gender.place(x=500, y=230)
e_gender = ttk.Combobox(app, width=25, font=('arial 12'))
e_gender["values"] = ("Male", "Female")
e_gender.place(x=500, y=260, height=35, width=400)

# age range
age_range = Label(app, text="Age Range", font=('Goudy 12'), fg='black')
age_range.place(x=500, y=310)
age_range = ttk.Combobox(app, width=25, font=('arial 12'))
age_range["values"] = ("Below 15", "15 to 18", "19 to 30", "31 to 50", "51 and above")
age_range.place(x=500, y=340, height=35, width=400)

# price
e_price = Label(app, text="Price", font=('Goudy 12'), fg='black')
e_price.place(x=250, y=390)
e_price = Entry(width=25, font=('arial 12'), bg='white')
e_price.place(x=250, y=420, height=35, width=400)

# button
save = Button(app, text="SAVE", width=15, height=2, bg='royalblue', command=save, cursor="hand2", fg='yellow')
save.place(x=70, y=400)

delete = Button(app, text="DELETE", width=15, height=2, bg='royalblue', command=delete, cursor="hand2", fg='yellow')
delete.place(x=200, y=480)

update = Button(app, text="UPDATE", width=15, height=2, bg='royalblue', command=update, cursor="hand2", fg='yellow')
update.place(x=580, y=480)

get = Button(app, text="GET", width=15, height=2, bg='royalblue', command=get, cursor="hand2", fg='yellow')
get.place(x=750, y=400)

app.title("Customer Billing System")
app.geometry('950x600')

app.mainloop()
