from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql

import datetime

app = Tk()


# insect to database
def save():
    time = e_time.get();
    coffee = e_coffee.get();
    coffeenumber = e_coffee_number.get();
    cake = e_cake.get();
    cakenumber = e_cake_number.get();
    totalprice = e_total_price.get();

    if (
            time == "" or coffee == "" or coffeenumber == "" or cake == "" or cakenumber == "" or totalprice == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="cafe_management")
        cursor = con.cursor()
        cursor.execute(
            "insert into cafe_table values('" + time + "','" + coffee + "', '" + coffeenumber + "', '" + cake + "','" + cakenumber + "', '" + totalprice + "')")
        cursor.execute("commit");

        e_time.delete(0, 'end')
        e_coffee.delete(0, 'end')
        e_coffee_number.delete(0, 'end')
        e_cake.delete(0, 'end')
        e_cake_number.delete(0, 'end')
        e_total_price.delete(0, 'end')

        # show()
        MessageBox.showinfo("Insert Status", "Item saved Successfully")
        con.close();


# delete from database
def delete():
    if (e_time.get() == ""):
        MessageBox.showinfo("Delete  Status", "Time feild is compulsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="cafe_management")
        cursor = con.cursor()
        cursor.execute("delete from cafe_table where time='" + e_time.get() + "'")
        cursor.execute("commit");

        e_time.delete(0, 'end')
        e_coffee.delete(0, 'end')
        e_coffee_number.delete(0, 'end')
        e_cake.delete(0, 'end')
        e_cake_number.delete(0, 'end')
        e_total_price.delete(0, 'end')
        # show()
        MessageBox.showinfo("Delete Status", "item has been deleted successfully")
        con.close();

# update database
def update():
    time = e_time.get();
    coffee = e_coffee.get();
    coffeenumber = e_coffee_number.get();
    cake = e_cake.get();
    cakenumber = e_cake_number.get();
    totalprice = e_total_price.get();

    if (
            time == "" or coffee == "" or coffeenumber == "" or cake == "" or cakenumber == "" or totalprice == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="cafe_management")
        cursor = con.cursor()
        cursor.execute(
            "Update cafe_table set time='" + time + "', coffee='" + coffee + "', coffeenumber='" + coffeenumber + "', cake='" + cake + "', cakenumber='" + cakenumber + "', totalprice='" + totalprice + "' where time='" + e_time.get() + "'")
        cursor.execute("commit");

        e_time.delete(0, 'end')
        e_coffee.delete(0, 'end')
        e_coffee_number.delete(0, 'end')
        e_cake.delete(0, 'end')
        e_cake_number.delete(0, 'end')
        e_total_price.delete(0, 'end')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();

# get from database
def get():
    if(e_time.get() == ""):
        MessageBox.showinfo("Fetch  Status", "car serial number field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="cafe_management")
        cursor = con.cursor()
        cursor.execute("select * from cafe_table where time='"+ e_time.get() +"'")
        rows = cursor.fetchall()


        for row in rows:
            e_coffee.insert(0, row[1])
            e_coffee_number.insert(0, row[2])
            e_cake.insert(0, row[3])
            e_cake_number.insert(0, row[4])
            e_total_price.insert(0, row[5])

        con.close();

date = datetime.datetime.now().date()
timee = datetime.datetime.now().time()

# components
heading = Label(app, text="Cafe Management system", font=('Goudy 30 bold'), fg='black')
heading.place(x=200, y=0)

date_l = Label(app, text="Today's Date: " + str(date), font=('arial 12 '), fg='black')
date_l.place(x=550, y=380)

time_l = Label(app, text="Today's Time: " + str(timee), font=('arial 12 '), fg='black')
time_l.place(x=780, y=380)

# Note
e_note = Label(app, text="Note: Time and date as unique number *No space or character", font=('century 12 bold'), fg='black')
e_note.place(x=30, y=50)

# timee
e_time = Label(app, text="Unique Number", font=('Goudy 12'), fg='black')
e_time.place(x=30, y=70)
e_time = Entry(width=25, font=('arial 12'), bg='white')
e_time.place(x=30, y=100, height=35, width=400)

# coffee
e_coffee = Label(app, text="Name of Coffee", font=('Goudy 12'), fg='black')
e_coffee.place(x=30, y=150)
e_coffee = Entry(width=25, font=('arial 12 '), bg='white')
e_coffee.place(x=30, y=180, height=35, width=400)

# coffee number
e_coffee_number = Label(app, text="Number of Coffee Needed", font=('Goudy 12'), fg='black')
e_coffee_number.place(x=30, y=230)
e_coffee_number = Entry(width=25, font=('arial 12'), bg='white')
e_coffee_number.place(x=30, y=260, height=35, width=400)

# cake
e_cake = Label(app, text="Name of Cake", font=('Goudy 12'), fg='black')
e_cake.place(x=500, y=70)
e_cake = Entry(width=25, font=('arial 12'), bg='white')
e_cake.place(x=500, y=100, height=35, width=400)

# cake number
e_cake_number = Label(app, text="Number of Cake Needed", font=('Goudy 12'), fg='black')
e_cake_number.place(x=500, y=150)
e_cake_number = Entry(width=25, font=('arial 12'), bg='white')
e_cake_number.place(x=500, y=180, height=35, width=400)

# total price
e_total_price = Label(app, text="Total Price", font=('Goudy 12'), fg='black')
e_total_price.place(x=500, y=230)
e_total_price = Entry(width=25, font=('arial 12'), bg='white')
e_total_price.place(x=500, y=260, height=35, width=400)

# button
save = Button(app, text="SAVE", width=15, height=2, bg='royalblue', command=save, cursor="hand2")
save.place(x=100, y=330)

delete = Button(app, text="DELETE", width=15, height=2, bg='royalblue', command=delete, cursor="hand2")
delete.place(x=300, y=330)

update = Button(app, text="UPDATE", width=15, height=2, bg='royalblue', command=update, cursor="hand2")
update.place(x=500, y=330)

get = Button(app, text="GET", width=15, height=2, bg='royalblue', command=get, cursor="hand2")
get.place(x=700, y=330)

app.title("Cafe Management System")
app.geometry('950x402')

app.mainloop()

