-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2022 at 12:03 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafe_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafe_table`
--

CREATE TABLE `cafe_table` (
  `time` varchar(50) NOT NULL,
  `coffee` varchar(100) NOT NULL,
  `coffeenumber` varchar(50) NOT NULL,
  `cake` varchar(100) NOT NULL,
  `cakenumber` varchar(50) NOT NULL,
  `totalprice` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cafe_table`
--

INSERT INTO `cafe_table` (`time`, `coffee`, `coffeenumber`, `cake`, `cakenumber`, `totalprice`) VALUES
('2022-06-04 1548', 'latte', '3', 'Black forest cake', '5', '5000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cafe_table`
--
ALTER TABLE `cafe_table`
  ADD UNIQUE KEY `time` (`time`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
