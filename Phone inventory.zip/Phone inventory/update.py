#import all the modules
from tkinter import *
import mysql.connector
from mysql.connector import Error
import tkinter.messagebox

conn=mysql.connector.connect(host='localhost',
                                       database='phonemg',
                                       user='root',
                                       password='')
mycursor = conn.cursor()
mycursor.execute("SELECT Max(id) from inventory")
result = mycursor.fetchall()
for r in result:
    id=r[0]

class Database:
    def __init__(self,master,*args,**kwargs):
         self.master=master
         self.heading=Label(master,text="Search and Update Product",font=('arial 40 bold'),fg='white', bg = '#ff7c44')
         self.heading.place(x=100,y=3)

         #label and entry for id
         self.id_le=Label(master,text="Search with ID",font=('arial 18 bold'),bg='#ff7c44', fg ='white')
         self.id_le.place(x=0,y=80)

         self.id_leb=Entry(master,font=('arial 18 bold'),width=10)
         self.id_leb.place(x=380,y=80)

         self.btn_search=Button(master,text="search",width=10,height=2,bg='#ffbee9',command=self.search)
         self.btn_search.place(x=548,y=75)

         #lables  for the window
         self.name_l=Label(master,text="Enter Product Name",font=('arial 18 bold'),bg='#ff7c44', fg ='white')
         self.name_l.place(x=0,y=125)

         self.stock_l=Label(master,text="Enter Stocks",font=('arial 18 bold'),bg='#ff7c44', fg ='white')
         self.stock_l.place(x=0,y=170)

         self.cp_l = Label(master, text="Enter Cost Price ", font=('arial 18 bold'),bg='#ff7c44', fg ='white')
         self.cp_l.place(x=0, y=220)


        #enteries for window

         self.name_e=Entry(master,width=25,font=('arial 18 bold'))
         self.name_e.place(x=380,y=120)

         self.stock_e = Entry(master, width=25, font=('arial 18 bold'))
         self.stock_e.place(x=380, y=170)

         self.cp_e = Entry(master, width=25, font=('arial 18 bold'))
         self.cp_e.place(x=380, y=220)


         #button to add to the database
         self.btn_add=Button(master,text='Update',width=25,height=2,bg='#ffbee9',fg='#ff7c44',command=self.update)
         self.btn_add.place(x=520,y=260)



          #text box for the log
         # self.tbBox=Text(master,width=60,height=18)
         # self.tbBox.place(x=750,y=70)
         # self.tbBox.insert(END,"ID has reached up to:"+str(id))

    def search(self, *args, **kwargs):
         mycursor.execute("SELECT * FROM inventory WHERE id=%s",[self.id_leb.get()])
         result = mycursor.fetchall()
         for r in result:
              self.n1 = r[1]  # name
              self.n2 = r[2]  # stock
              self.n3 = r[3]  # cp
         conn.commit()

          #inster into the enteries to update
         self.name_e.delete(0,END)
         self.name_e.insert(0, str(self.n1))

         self.stock_e.delete(0, END)
         self.stock_e.insert(0, str(self.n2))

         self.cp_e.delete(0, END)
         self.cp_e.insert(0, str(self.n3))

    def update(self,*args,**kwargs):
          self.u1=self.name_e.get()
          self.u2 = self.stock_e.get()
          self.u3 = self.cp_e.get()


          mycursor.execute("UPDATE  inventory SET name=%s,stock=%s,price=%s WHERE id=%s",[self.u1,self.u2,self.u3,self.id_leb.get()])
          conn.commit()
          tkinter.messagebox.showinfo("Success","Update Database successfully")

root=Tk()
b=Database(root)
root.geometry("900x400+0+0")
root.title("Tee Phone Store")
root.config(background="#ff7c44")
root.mainloop()