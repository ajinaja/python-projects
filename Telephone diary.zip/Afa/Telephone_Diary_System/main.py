import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql

def insert():
    full_names = e_full_name.get()
    contact_nos = e_contact_no.get()
    emails = e_email.get()
    locations = e_location.get()
    zip_codes = e_zip_code.get()
    citys = e_city.get()
    states = e_state.get()
    po_boxs = e_po_box.get()

    if (full_names == "" or contact_nos == "" or emails == "" or locations == "" or zip_codes == "" or citys == "" or states == "" or po_boxs == ""):
        messagebox.showinfo("Insert Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="telephone_diary")
    cursor = con.cursor()
    cursor.execute("INSERT INTO `diary_records`(`Names`, `Contact_No`, `Email`, `Location`, `Zip_Code`, `City`, `State`, `PO_Box`) VALUES ('" + full_names + "','" + contact_nos + "','" + emails + "','" + locations + "','" + zip_codes + "','" + citys + "','" + states + "','" + po_boxs + "')")
    cursor.execute("commit")

    e_full_name.delete(0, 'end')
    e_contact_no.delete(0, 'end')
    e_email.delete(0, 'end')
    e_location.delete(0, 'end')
    e_zip_code.delete(0, 'end')
    e_city.delete(0, 'end')
    e_state.delete(0, 'end')
    e_po_box.delete(0, 'end')

    messagebox.showinfo("Insert Status", "Inserted Successfully")
    con.close()

def check_input():
    contact_nos = e_contact_no.get()
    if (contact_nos == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Contact No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="telephone_diary")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute(
            "SELECT * FROM `diary_records` WHERE `Contact_No`='" + contact_nos + "'")
        # SELECT `ID`, `Names`, `Contact_No`, `Email`, `Location`, `Zip_Code`, `City`, `State`, `PO_Box`, `Created_Date`, `Last_Update` FROM `diary_records` WHERE 1
        # SELECT * FROM `student_score` WHERE 1
        # SELECT `ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Session`, `Course_Code`, `Score`, `GPA`, `Grade`, `Created_Date`, `Last_Update` FROM `student_score` WHERE 1
        rows = curses.fetchall()

        if (rows):
            messagebox.showwarning("Info Status", "Contact No. already exist")
        else:
            insert()

        con.close()


def delete():
    contact_nos = e_contact_no.get()
    if (contact_nos == ""):
        messagebox.showinfo("Delete Status", "Please, fill up the field of Contact No.")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="telephone_diary")
        cursor = con.cursor()
        cursor.execute("DELETE FROM `diary_records` WHERE Contact_No='" + contact_nos + "' ")
        # DELETE FROM `student_score` WHERE 0
        cursor.execute("commit");

        e_full_name.delete(0, 'end')
        e_contact_no.delete(0, 'end')
        e_email.delete(0, 'end')
        e_location.delete(0, 'end')
        e_zip_code.delete(0, 'end')
        e_city.delete(0, 'end')
        e_state.delete(0, 'end')
        e_po_box.delete(0, 'end')

        messagebox.showinfo("Delete Status", "Deleted Successfully")
        con.close()


def update():
    full_names = e_full_name.get()
    contact_nos = e_contact_no.get()
    emails = e_email.get()
    locations = e_location.get()
    zip_codes = e_zip_code.get()
    citys = e_city.get()
    states = e_state.get()
    po_boxs = e_po_box.get()

    if (full_names == "" or contact_nos == "" or emails == "" or locations == "" or zip_codes == "" or citys == "" or states == "" or po_boxs == ""):
        messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="telephone_diary")
        cursor = con.cursor()
        cursor.execute("UPDATE `diary_records` SET `Names`='" + full_names + "',`Email`='" + emails + "',`Location`='" + locations + "',`Zip_Code`='" + zip_codes + "',`City`='" + citys + "',`State`='" + states + "',`PO_Box`='" + po_boxs + "' WHERE Contact_No='" + contact_nos + "' ")
        cursor.execute("commit");

        messagebox.showinfo("Update Status", "Updated Successfully")
        con.close()


def get():
    contact_nos = e_contact_no.get()
    if (contact_nos == ""):
        messagebox.showinfo("Fetch Status", "Please, fill up the field of Contact No. ...?")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="telephone_diary")
        #  telephone_diary »Table: diary_records
        curses = con.cursor()
        curses.execute(
            "SELECT * FROM `diary_records` WHERE `Contact_No`='" + contact_nos + "'")
        # SELECT `ID`, `Names`, `Contact_No`, `Email`, `Location`, `Zip_Code`, `City`, `State`, `PO_Box`, `Created_Date`, `Last_Update` FROM `diary_records` WHERE 1
        # SELECT * FROM `student_score` WHERE 1
        # SELECT `ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Session`, `Course_Code`, `Score`, `GPA`, `Grade`, `Created_Date`, `Last_Update` FROM `student_score` WHERE 1
        rows = curses.fetchall()

        for row in rows:
            # Clear

            e_full_name.delete(0, 'end')
            # e_contact_no.delete(0, 'end')
            e_email.delete(0, 'end')
            e_location.delete(0, 'end')
            e_zip_code.delete(0, 'end')
            e_city.delete(0, 'end')
            e_state.delete(0, 'end')
            e_po_box.delete(0, 'end')
            #  Fetch
            e_full_name.insert(0, row[1])
            # e_contact_no.insert(0, row[2])
            e_email.insert(0, row[3])
            e_location.insert(0, row[4])
            e_zip_code.insert(0, row[5])
            e_city.insert(0, row[6])
            e_state.insert(0, row[7])
            e_po_box.insert(0, row[8])

            con.close()
def clear():
    e_full_name.delete(0, 'end')
    e_contact_no.delete(0, 'end')
    e_email.delete(0, 'end')
    e_location.delete(0, 'end')
    e_zip_code.delete(0, 'end')
    e_city.delete(0, 'end')
    e_state.delete(0, 'end')
    e_po_box.delete(0, 'end')

# Create window object
app = Tk()

# Title
title = Label(app, text='Telephone Diary Management system', bg='black', fg='white', font=('bold', 20))
title.place(x=70, y=2)

# Name
full_name = Label(app, text='Name:', font=('bold', 18))
full_name.place(x=20, y=50)

e_full_name = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_full_name.place(x=250, y=50)


# Contact
contact_no = Label(app, text='Contact No.:', font=('bold', 18))
contact_no.place(x=20, y=100)

e_contact_no = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_contact_no.place(x=250, y=100)


# Email
email = Label(app, text='Email:', font=('bold', 18))
email.place(x=20, y=150)

e_email = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_email.place(x=250, y=150)


# Location
location = Label(app, text='Location:', font=('bold', 18))
location.place(x=20, y=200)

e_location = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_location.place(x=250, y=200)


# Zip Code
zip_code = Label(app, text='Zip Code:', font=('bold', 18))
zip_code.place(x=20, y=250)

e_zip_code = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_zip_code.place(x=250, y=250)


# City
city = Label(app, text='City:', font=('bold', 18))
city.place(x=20, y=300)

e_city = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_city.place(x=250, y=300)


# State
state = Label(app, text='State:', font=('bold', 18))
state.place(x=20, y=350)

e_state = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_state.place(x=250, y=350)


# PO Box
po_box = Label(app, text='PO Box:', font=('bold', 18))
po_box.place(x=20, y=400)

e_po_box = Entry(app, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
e_po_box.place(x=250, y=400)


clear = Button(app, text="Reset", font="italic, 15", bg="gray", command=clear)
clear.place(x=570, y=300)

insert = Button(app, text="Save", font="italic, 15", bg="gold", command=check_input)
insert.place(x=570, y=250)

delete = Button(app, text="Delete", font="italic, 15", bg="red", command=delete)
delete.place(x=570, y=400)

update = Button(app, text="Update", font="italic, 15", bg="green", command=update)
update.place(x=570, y=350)

get = Button(app, text="Search", font="italic, 15", bg="blue", fg="white", command=get)
get.place(x=570, y=200)

app.title('Telephone Diary Management System')
app.geometry('670x500')
app.configure(bg="dark slate gray")

# Start program
app.mainloop()
