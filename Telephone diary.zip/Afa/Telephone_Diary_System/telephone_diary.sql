-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 11:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `telephone_diary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_records`
--

CREATE TABLE `diary_records` (
  `ID` int(11) NOT NULL,
  `Names` varchar(50) NOT NULL,
  `Contact_No` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Location` text NOT NULL,
  `Zip_Code` int(11) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` text NOT NULL,
  `PO_Box` text NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `diary_records`
--

INSERT INTO `diary_records` (`ID`, `Names`, `Contact_No`, `Email`, `Location`, `Zip_Code`, `City`, `State`, `PO_Box`, `Created_Date`, `Last_Update`) VALUES
(2, 'vgjvjhvjh', '068857857757', 'frwt@gmail.com', 'mvj,bjb jkggjl', 6776, 'Akure', 'bnmbk,hbkhb', '6865', '2022-06-04 17:41:43', '2022-06-10 19:13:19'),
(3, 'bldnbklnlbckhz', '068857857753', 'vn  bnzlbz m,vns.,', 'gyfgyujkvjh', 565656, 'gjkvbgjkbjkb', 'nmvb,nvn,', '767', '2022-06-04 17:44:09', '2022-06-04 17:44:09'),
(4, 'hugohuiffhi', '081874656454', 'hohuhui', 'kkghkgh', 565, 'khghgjh', 'bhvhvgj', '56855', '2022-06-04 17:52:17', '2022-06-04 17:52:17'),
(8, 'hjkbkjhb', '08053654256', 'bhbghjkjvk', 'gjhgjhhj', 6556, 'hghghg', 'gygyugvh', '6769', '2022-06-06 19:31:08', '2022-06-06 19:31:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_records`
--
ALTER TABLE `diary_records`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_records`
--
ALTER TABLE `diary_records`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
