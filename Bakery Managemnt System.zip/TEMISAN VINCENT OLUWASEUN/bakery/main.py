from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql

import datetime

app = Tk()


# insect to database
def save():
    customername = Customer_name.get();
    customeradress = Customer_address.get();
    customerphoneno = Customer_phone_no.get();
    breadsize = bread_size.get();
    quantity = q_uantity.get();
    amount = a_mount.get();

    if (
            customername == "" or customeradress == "" or customerphoneno == "" or quantity == "" or amount == "" or breadsize == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="bakery")
        cursor = con.cursor()
        cursor.execute(
            "insert into bread values('" + customername + "','" + customeradress + "', '" + customerphoneno + "', '" + breadsize + "','" + quantity + "', '" + amount + "')")
        cursor.execute("commit");

        Customer_name.delete(0, 'end')
        Customer_address.delete(0, 'end')
        Customer_phone_no.delete(0, 'end')
        bread_size.delete(0, 'end')
        q_uantity.delete(0, 'end')
        a_mount.delete(0, 'end')

        # show()
        MessageBox.showinfo("Insert Status", "Customer Details was saved Successfully")
        con.close();


# delete from database
def delete():
    if (Customer_phone_no.get() == ""):
        MessageBox.showinfo("Delete  Status", "Customer number feild is compuqsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="bakery")
        cursor = con.cursor()
        cursor.execute("delete from bread where Customerphoneno='" + Customer_phone_no.get() + "'")
        cursor.execute("commit");

        Customer_name.delete(0, 'end')
        Customer_address.delete(0, 'end')
        Customer_phone_no.delete(0, 'end')
        bread_size.delete(0, 'end')
        q_uantity.delete(0, 'end')
        a_mount.delete(0, 'end')
        # show()
        MessageBox.showinfo("Delete Status", "Customer deatils has been deleted successfully")
        con.close();

# update database
def update():
    customername = Customer_name.get();
    customeradress = Customer_address.get();
    customerphoneno= Customer_phone_no.get();
    breadsize = bread_size.get();
    quantity = q_uantity.get();
    amount = a_mount.get();

    if (
            customername == "" or customeradress == "" or customerphoneno == "" or quantity == "" or amount == "" or breadsize == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="bakery")
        cursor = con.cursor()
        cursor.execute(
            "Update bread set customername='" + customername + "', customeradress='" + customeradress + "', customerphoneno='" + customerphoneno + "', breadsize='" + breadsize + "', quantity='" + quantity + "', amount='" + amount + "' where customerphoneno='" + Customer_phone_no.get() + "'")
        cursor.execute("commit");

        Customer_name.delete(0, 'end')
        Customer_address.delete(0, 'end')
        Customer_phone_no.delete(0, 'end')
        bread_size.delete(0, 'end')
        q_uantity.delete(0, 'end')
        a_mount.delete(0, 'end')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();

# get from database
def get():
    if(Customer_phone_no.get() == ""):
        MessageBox.showinfo("Fetch  Status", "car serial number field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="bakery")
        cursor = con.cursor()
        cursor.execute("select * from bread where customerphoneno='"+ Customer_phone_no.get() +"'")
        rows = cursor.fetchall()


        for row in rows:
            Customer_name.insert(0, row[0])
            Customer_address.insert(0, row[1])
            bread_size.insert(0, row[3])
            q_uantity.insert(0, row[4])
            a_mount.insert(0, row[5])

        con.close();

date = datetime.datetime.now().date()

# components
heading = Label(app, text="Bakery Management System", font=('impact 30 bold'), fg='white', bg="magenta")
heading.place(x=40, y=0)

date_l = Label(app, text="Today's Date: " + str(date), font=('arial 12 '), fg='black' , bg="magenta")
date_l.place(x=400, y=580)

# Customer_name
Customer_name = Label(app, text="Customer Name", font=('Goudy 12'), fg='black', bg="magenta")
Customer_name.place(x=10, y=70)
Customer_name = Entry(width=25, font=('arial 12'), bg='white')
Customer_name.place(x=10, y=100, height=35, width=400)

# Customer_addres
Customer_address = Label(app, text="Customer Addres", font=('Goudy 12'), fg='black', bg="magenta")
Customer_address.place(x=10, y=150)
Customer_address = Entry(width=25, font=('arial 12 '), bg='white')
Customer_address.place(x=10, y=180, height=35, width=400)

# Customer_phone_no
Customer_phone_no = Label(app, text="Customer Phone No", font=('Goudy 12'), fg='black', bg="magenta")
Customer_phone_no.place(x=10, y=230)
Customer_phone_no = Entry(width=25, font=('arial 12 bold'), bg='white')
Customer_phone_no.place(x=10, y=260, height=35, width=400)

# bread_size
bread_size = Label(app, text="Bread Size", font=('Goudy 12'), fg='black', bg="magenta")
bread_size.place(x=10, y=310)
bread_size = Entry(width=25, font=('arial 12'), bg='white')
bread_size.place(x=10, y=340, height=35, width=400)

# q_uantity
q_uantity = Label(app, text="Quantity", font=('Goudy 12'), fg='black', bg="magenta")
q_uantity.place(x=10, y=390)
q_uantity = Entry(width=25, font=('arial 12 '), bg='white')
q_uantity.place(x=10, y=420, height=35, width=400)

# Customer_phone_no
a_mount = Label(app, text="Amount", font=('Goudy 12'), fg='black', bg="magenta")
a_mount.place(x=10, y=460)
a_mount = Entry(width=25, font=('arial 12 bold'), bg='white')
a_mount.place(x=10, y=490, height=35, width=400)


# button
save = Button(app, text="SAVE", width=15, height=2, bg='lightblue', command=save, cursor="hand2")
save.place(x=450, y=90)

delete = Button(app, text="DELETE", width=15, height=2, bg='lightblue', command=delete, cursor="hand2")
delete.place(x=450, y=190)

update = Button(app, text="UPDATE", width=15, height=2, bg='lightblue', command=update, cursor="hand2")
update.place(x=450, y=310)

get = Button(app, text="GET", width=15, height=2, bg='lightblue', command=get, cursor="hand2")
get.place(x=450, y=440)

app.title("Bakery Management System")
app.geometry('600x600')
app.configure(bg="magenta")

app.mainloop()


