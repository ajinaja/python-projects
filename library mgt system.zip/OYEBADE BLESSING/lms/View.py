from tkinter import *
import tkinter.messagebox as Messagebox
import mysql.connector as mysql


def view():




    root = Tk()
    root.geometry("400x400")
    root.title("Add new book")
    root.configure(bg="green")


    labelFrame = Frame(root, bg='black')
    labelFrame.place(relx=0.1, rely=0.3, relwidth=0.8, relheight=0.5)
    y = 0.25

    Label(labelFrame, text="%-10s%-40s%-30s%-20s" % ('TITLE', 'AUTHOR', 'ISBN', 'DATE'), bg='black', fg='white').place(
        relx=0.07, rely=0.1)

    Label(labelFrame, text="----------------------------------------------------------------------------", bg='black',
          fg='white').place(relx=0.05, rely=0.2)

    try:
        con = mysql.Connect(host="localhost", user="root", password="", database="library")
        cursor = con.cursor()
        cursor.execute("select * from addbook")


        rows = cursor.fetchall()
        for i in rows:
            Label(labelFrame, text="%-10s%-40s%-30s%-20s" % (i[0], i[1], i[2], i[3]), bg='black', fg='white').place(
                relx=0.07, rely=y)
            y += 0.1
    except:
        Messagebox.showinfo("Failed to fetch files from database")


    btn2 = Button(root, text="QUIT", command=root.destroy)
    btn2.place(x=140, y=350)

    root.mainloop()
