from tkinter import *
import tkinter.messagebox as Messagebox
import mysql.connector as mysql


def retur():
    def return1():
        booktitle = entry1.get()


        if booktitle == "":
            Messagebox.showinfo("", "BOOK TITLE IS REQUIRED")

        else:
            con = mysql.Connect(host="localhost", user="root", password="", database="library")
            cursor = con.cursor()
            cursor.execute("delete from issuetable where booktitle = '" + booktitle + "'")
            cursor.execute("commit")
            Messagebox.showinfo("RETURN STATUS", "RETURNED")
            entry1.delete(0, 'end')


            con.close()

    root = Tk()
    root.geometry("400x200")
    root.title("Add new book")
    label = Label(root, text="ENTER BOK TO RETURN")
    label.place(x=100, y=10)
    label = Label(root, text="BOOK TITLE")
    label.place(x=20, y=50)

    entry1 = Entry(root)
    entry1.place(x=100, y=50)

    btn1 = Button(root, text="RETURN", command=return1)
    btn1.place(x=100, y=120)

    btn2 = Button(root, text="QUIT", command=root.destroy)
    btn2.place(x=180, y=120)

    root.mainloop()
