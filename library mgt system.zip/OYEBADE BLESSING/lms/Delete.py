from tkinter import *
import tkinter.messagebox as Messagebox
import mysql.connector as mysql


def delete():
    def dele():
        booktitle = entry1.get()


        if booktitle == "":
            Messagebox.showinfo("", "BOOK TITLE IS REQUIRED TO DELETE")

        else:
            con = mysql.Connect(host="localhost", user="root", password="", database="library")
            cursor = con.cursor()
            cursor.execute("delete from addbook where booktitle = '" + booktitle + "'")
            cursor.execute("commit")
            Messagebox.showinfo("DELETE STATUS", "Deleted Successful")
            entry1.delete(0, 'end')


            con.close()

    root = Tk()
    root.geometry("400x200")
    root.title("Add new book")
    label = Label(root, text="ENTER BOOK TITLE TO DELETE")
    label.place(x=100, y=10)
    label = Label(root, text="BOOK TITLE")
    label.place(x=20, y=50)

    entry1 = Entry(root)
    entry1.place(x=100, y=50)

    btn1 = Button(root, text="DELETE", command=dele)
    btn1.place(x=100, y=120)

    btn2 = Button(root, text="QUIT", command=root.destroy)
    btn2.place(x=180, y=120)

    root.mainloop()
