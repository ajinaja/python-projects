from tkinter import *
import tkinter.messagebox as Messagebox
import mysql.connector as mysql


def add():
    def add1():
        booktitle = entry1.get()
        bookauthor = entry2.get()
        bookisbn = entry3.get()
        bookdate = entry4.get()

        if booktitle == "" or bookauthor == "" or bookisbn == "" or bookdate == "":
            Messagebox.showinfo("", "ALl filed are required")

        else:
            con = mysql.Connect(host="localhost", user="root", password="", database="library")
            cursor = con.cursor()
            cursor.execute("insert into addbook(booktitle, bookauthor, bookisbn,bookdate) values('" + booktitle + "', '" + bookauthor + "', '" + bookisbn + "', '" + bookdate + "')")
            cursor.execute("commit")
            Messagebox.showinfo("INSERT STATUS", "Successful")
            entry1.delete(0, 'end')
            entry2.delete(0, 'end')
            entry3.delete(0, 'end')
            entry4.delete(0, 'end')

            con.close()

    root = Tk()
    root.geometry("400x400")
    root.title("Add new book")
    label = Label(root, text="ADD NEW BOOK")
    label.place(x=20, y=10)
    label = Label(root, text="BOOK TITLE")
    label.place(x=20, y=50)
    label = Label(root, text="AUTHOR")
    label.place(x=20, y=90)
    label = Label(root, text="ISBN")
    label.place(x=20, y=130)
    label = Label(root, text="DATE")
    label.place(x=20, y=170)

    entry1 = Entry(root)
    entry1.place(x=100, y=50)
    entry2 = Entry(root)
    entry2.place(x=100, y=90)
    entry3 = Entry(root)
    entry3.place(x=100, y=130)
    entry4 = Entry(root)
    entry4.place(x=100, y=170)

    btn1 = Button(root, text="ADD", command=add1)
    btn1.place(x=100, y=220)

    btn2 = Button(root, text="QUIT", command=root.destroy)
    btn2.place(x=140, y=220)

    root.mainloop()
