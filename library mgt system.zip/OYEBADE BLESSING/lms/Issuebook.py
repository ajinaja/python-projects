from tkinter import *
import tkinter.messagebox as Messagebox
import mysql.connector as mysql


def issue():
    def booked():
        booktitle = entry1.get()
        studentname = entry2.get()

        if booktitle == "":
            Messagebox.showinfo("", "BOOK TITLE IS REQUIRED TO ISSUE")

        else:

            con = mysql.Connect(host="localhost", user="root", password="", database="library")
            cursor = con.cursor()
            cursor.execute(
                "insert into issuetable (booktitle, studentname) values('" + booktitle + "', '" + studentname + "')")
            cursor.execute("commit")
            Messagebox.showinfo("ISSUE STATUS", "ISSUED  Successful")
            entry1.delete(0, 'end')
            entry2.delete(0, 'end')

            con.close()

    root = Tk()
    root.geometry("400x250")
    root.title("Add new book")
    label = Label(root, text="BOOKS LENDING SECTION")
    label.place(x=100, y=10)
    label = Label(root, text="BOOK TITLE")
    label.place(x=20, y=50)
    label = Label(root, text="STUDENT NAME")
    label.place(x=20, y=100)

    entry1 = Entry(root)
    entry1.place(x=120, y=50)
    entry2 = Entry(root)
    entry2.place(x=120, y=100)

    btn1 = Button(root, text="ISSUES", command=booked)
    btn1.place(x=100, y=140)

    btn2 = Button(root, text="BACK", command=root.destroy)
    btn2.place(x=180, y=140)

    root.mainloop()
