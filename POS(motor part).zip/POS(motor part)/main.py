from tkinter import *
import tkinter.messagebox as MessageBox
from tkinter import ttk
from tkcalendar import DateEntry

import mysql.connector as mysql
from mysql.connector import cursor

dashboard = Tk()
dashboard.geometry("700x400+400+60")
dashboard.title("Dashboard")

title_label = Label(dashboard, text="POS Management System", fg='white', bg='black', width=200, font=('bold', 20)).pack()



# =========================Bg==================================================================

def pro():
    pro = Toplevel()
    pro.geometry("800x300+300+90")
    pro.title("Management Product")
    title = Label(pro, text="Manage Product",  fg='white', bg='black', width=200,
                        font=('bold', 20)).pack()

    def insert_item():
        pro_name = e_pro_name.get()
        pro_qty = e_pro_qty.get()
        pro_price = e_pro_price.get()

        if pro_name == "" or pro_qty == "" or pro_price == "":

            MessageBox.showinfo(pro, "Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute(
                "insert into product_tbl values('" + pro_name + "','" + pro_qty + "','" + pro_price + "')")
            cursor.execute("commit")

            e_pro_qty.delete(0, 'end')
            e_pro_name.delete(0, 'end')
            e_pro_price.delete(0, 'end')

            MessageBox.showinfo("Insert Status", "Product Successfully Added")
            con.close()

    def insert_checker():
        pro_name = e_pro_name.get()
        pro_qty = e_pro_qty.get()
        pro_price = e_pro_price.get()
        if pro_name == "" or pro_qty == "" or pro_price == "":
             MessageBox.showinfo("Insert Status", "All Fields are required")

        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute("select * from product_tbl where pro_name='" + pro_name + "'")
            rows = cursor.fetchall()
            if (rows):
                MessageBox.showinfo("Exist", "Product Record already exist")

                return False

            else:
                insert_item()
                return True
            con.close();

    def get():

        if (e_pro_name.get() == ""):
            MessageBox.showinfo("Fetch  Status", "Product name and Date  is compulsory for search")
        else:

            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute("select * from product_tbl where pro_name='" + e_pro_name.get() + "'")
            rows = cursor.fetchall()

            for row in rows:
                e_pro_qty.insert(0, row[1])
                e_pro_price.insert(0, row[2])

            con.close()

    def update():
        pro_name = e_pro_name.get()
        pro_qty = e_pro_qty.get()
        pro_price = e_pro_price.get()
        if pro_name == "" or pro_qty == "" or pro_price == "":

            MessageBox.showinfo("Update Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute("Update product_tbl set pro_qty='"+ pro_qty +"', pro_price='"+ pro_price +"'")
            cursor.execute("commit");

            e_pro_qty.delete(0, 'end')
            e_pro_name.delete(0, 'end')
            e_pro_price.delete(0, 'end')

            MessageBox.showinfo("Update Status", "Product Updated Successfully")
            con.close()

    def cealrf():
        e_pro_qty.delete(0, 'end')
        e_pro_name.delete(0, 'end')
        e_pro_price.delete(0, 'end')

    def delete():
        if (pro_name.get() == ""):
            MessageBox.showinfo("Delete  Status", "Product name is compulsory for delete")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute(
                "delete from product_tbl where pro_name='" + e_pro_name.get() + "'")
            cursor.execute("commit");

            e_pro_qty.delete(0, 'end')
            e_pro_name.delete(0, 'end')
            e_pro_price.delete(0, 'end')
            MessageBox.showinfo("Delete Status", "Product Record Deleted Successfully")
            con.close()

    pro_name = Label(pro, text="Enter Product Name:",  fg='white', bg='black', font=('bold', 12))
    pro_name.place(x=50, y=90)
    e_pro_name = Entry(pro, width=30, font=('bold', 12))
    e_pro_name.place(x=300, y=90)



    pro_qty = Label(pro, text="Enter Product Quantity:",  fg='white', bg='black', font=('bold', 12))
    pro_qty.place(x=50, y=130)
    e_pro_qty = Entry(pro, width=30, font=('bold', 12))
    e_pro_qty.place(x=300, y=130)

    pro_price = Label(pro, text="Enter Product price:",  fg='white', bg='black', font=('bold', 12))
    pro_price.place(x=50, y=170)
    e_pro_price = Entry(pro, width=30, font=('bold', 12))
    e_pro_price.place(x=300, y=170)



    insert = Button(pro, text="Insert", font=("italic", 10),  fg='white', bg='black', width=10, command=insert_checker)
    insert.place(x=50, y=250)

    update = Button(pro, text="Update", font=("italic", 10),  fg='white', bg='black', width=10, command=update)
    update.place(x=150, y=250)

    delete = Button(pro, text="Delete", font=("italic", 10),  fg='white', bg='black', width=10, command=delete)
    delete.place(x=250, y=250)

    get = Button(pro, text="Search", font=("italic", 10),  fg='white', bg='black', width=10, command=get)
    get.place(x=350, y=250)

    cealrf = Button(pro, text="Reset", font=("italic", 10),  fg='white', bg='black', width=10, command=cealrf)
    cealrf.place(x=450, y=250)





def sales():
    sales = Toplevel()
    sales.geometry("700x500+300+60")
    sales.title("Management Product")


    title = Label(sales, text="Manage Sales",  fg='white', bg='black', width=200,
                        font=('bold', 20)).pack()

    def insert():
        sales_name = e_sales_name.get()
        sales_qty = e_sales_qty.get()
        sales_price = e_sales_price.get()
        cus_name = e_cus_name.get()
        sales_date = e_sales_date.get()



        if sales_name == "" or sales_qty == "" or sales_price == "" or cus_name == "" or sales_date == 0:

            MessageBox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute(
                "insert into sales_tbl values('" + sales_name + "','" + cus_name + "','" + sales_qty + "', '" +  sales_price + "', '" + sales_date + "')")
            cursor.execute("commit")
            update()

            e_sales_qty.delete(0, 'end')
            e_sales_name.delete(0, 'end')
            e_sales_price.delete(0, 'end')
            e_cus_name.delete(0, 'end')
            e_sales_pprice.delete(0, 'end')
            e_sales_pqty.delete(0, 'end')
            e_sales_date.delete(0, 'end')
            MessageBox.showinfo("Insert Status", "sales Successfully Added")
            con.close()


    def get():

        if (e_sales_name.get() == ""):
            MessageBox.showinfo("Fetch  Status", "Product name  is compulsory for search")
        else:

            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute("select * from product_tbl where pro_name='" + e_sales_name.get() + "'")
            rows = cursor.fetchall()
            e_sales_qty.delete(0, 'end')
            e_sales_pqty.delete(0, 'end')
            for row in rows:
                e_sales_pqty.insert(0, row[1])
                e_sales_pprice.insert(0, row[2])

            con.close()

    pqtyz = IntVar()
    qtyz = IntVar()
    final_qty = IntVar()


    def update():
        sales_name = e_sales_pqty.get()
        sales_qty = e_sales_qty.get()
        sales_name = e_sales_name.get()
        sub = pqtyz.get()-qtyz.get()
        e_final_qty.insert(0, str(sub))

        con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
        cursor = con.cursor()
        cursor.execute("Update product_tbl set pro_qty='"+ e_final_qty.get() +"' WHERE pro_name = '" + sales_name + "'")
        cursor.execute("commit");

        MessageBox.showinfo("Update Status", "Product Updated Successfully")
        con.close()

    def cealrf():
        e_sales_qty.delete(0, 'end')
        e_sales_name.delete(0, 'end')
        e_sales_price.delete(0, 'end')
        e_cus_name.delete(0, 'end')
        e_sales_pprice.delete(0, 'end')
        e_sales_pqty.delete(0, 'end')


    cus_name = Label(sales, text="Enter Customer Name:",  fg='white', bg='black', font=('bold', 12))
    cus_name.place(x=50, y=90)
    e_cus_name = Entry(sales, width=30, font=('bold', 12))
    e_cus_name.place(x=300, y=90)

    sales_name = Label(sales, text="Enter Product name:",  fg='white', bg='black', font=('bold', 12))
    sales_name.place(x=50, y=130)
    e_sales_name = Entry(sales, width=30, font=('bold', 12))
    e_sales_name.place(x=300, y=130)

    sales_pprice = Label(sales, text="Selling Price:", fg='white', bg='black', font=('bold', 12))
    sales_pprice.place(x=50, y=170)
    e_sales_pprice = Entry(sales, width=30, font=('bold', 12))
    e_sales_pprice.place(x=300, y=170)

    sales_pqty = Label(sales, text="Previous Quantity:",  fg='white', bg='black', font=('bold', 12))
    sales_pqty.place(x=50, y=210)
    e_sales_pqty = Entry(sales, width=30,  textvariable=pqtyz, font=('bold', 12))
    e_sales_pqty.place(x=300, y=210)

    sales_qty = Label(sales, text="Enter Product qty:",   fg='white', bg='black', font=('bold', 12))
    sales_qty.place(x=50, y=250)
    e_sales_qty = Entry(sales, width=30, textvariable=qtyz, font=('bold', 12))
    e_sales_qty.place(x=300, y=250)

    sales_price = Label(sales, text="Enter Payment price:", fg='white', bg='black', font=('bold', 12))
    sales_price.place(x=50, y=290)
    e_sales_price = Entry(sales, width=30, font=('bold', 12))
    e_sales_price.place(x=300, y=290)

    sales_date = Label(sales, text="Choose Date:", fg='white', bg='black', font=('bold', 12))
    sales_date.place(x=50, y=330)
    e_sales_date = DateEntry(sales, width=30, font=('bold', 12))
    e_sales_date.place(x=300, y=330)

    e_final_qty = Entry(sales, width=1,   font=('bold', 12), state='disabled')
    e_final_qty.place(x=300, y=350)






    insert = Button(sales, text="Sell", font=("italic", 10),  fg='white', bg='black', width=10, command=insert)
    insert.place(x=50, y=380)

    get = Button(sales, text="check", font=("italic", 10),  fg='white', bg='black', width=10, command=get)
    get.place(x=200, y=380)

    cealrf = Button(sales, text="Reset", font=("italic", 10),  fg='white', bg='black', width=10, command=cealrf)
    cealrf.place(x=300, y=380)

def pos():
    pos = Toplevel()
    pos.geometry("700x500+300+60")
    pos.title("POST")

    title = Label(pos, text="POS", fg='white', bg='black', width=200,
                  font=('bold', 20)).pack()

    #===============================Functions================================
    def show():
        pos_name = e_POS_name.get()
        pos_date = e_POS_date.get()

        if pos_name == "" or pos_date == 0:
            MessageBox.showinfo("empty Status", "customer name or sales date is required ")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_pos_db")
            cursor = con.cursor()
            cursor.execute("select * from sales_tbl where cus_name = '" + pos_name + "' AND sales_date = '" + pos_date + "'")
            rows = cursor.fetchall()
            list.delete(0, list.size())

            for row in rows:
                insertData = str(row[0]) + '   ' + row[1] + ' ' + row[2] + ' ' + row[3] + ' ' + row[4]
                list.insert(list.size() + 1, insertData)

            con.close();

    POS_name = Label(pos, text="Enter Customer Name to Search:", fg='white', bg='black', font=('bold', 12))
    POS_name.place(x=50, y=90)
    e_POS_name = Entry(pos, width=30, font=('bold', 12))
    e_POS_name.place(x=300, y=90)

    POS_date = Label(pos, text="Choose Date:", fg='white', bg='black', font=('bold', 12))
    POS_date.place(x=50, y=130)
    e_POS_date = DateEntry(pos, width=30, font=('bold', 12))
    e_POS_date.place(x=300, y=130)


    #=======================================Buttons========================================
    Fetch_pos = Button(pos, text="Fetch", font=("italic", 18), fg='white', bg='black', command=show)
    Fetch_pos.place(x=50, y=200)

    list = Listbox(pos, width=50, font=("italic", 18) )
    list.place(x=50, y=300)
    # list.pack()
   # show()







    #================================================Home=========================================


Manage_Product = Button(dashboard, text="Manage Product", font=("italic",18), fg='white', bg='black', width=40, height=2, command=pro)
Manage_Product.place(x=50, y=50)

Manage_Sales = Button(dashboard,  text="Manage Sales", font=("italic",18),  fg='white', bg='black', width=40, height=2, command=sales)
Manage_Sales.place(x=50, y=200)

get = Button(dashboard, text="POS", font=("italic", 18),  fg='white', bg='black', width=40, height=2, command=pos)
get.place(x=50, y=300)






dashboard.mainloop()