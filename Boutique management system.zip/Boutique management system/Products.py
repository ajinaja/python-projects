import pymysql
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk

#Connecting to database PhpMyAdmin
def connection():
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='',
        db='bottle',
    )
    return conn



#function to refresh the table
def refreshTable():
    for data in my_tree.get_children():
        my_tree.delete(data)

    for array in read():
        my_tree.insert(parent='', index='end', iid=array, text="", values=(array), tag="orow")

    my_tree.tag_configure('orow', background='#beb0ff',font=('Arial', 12))
    my_tree.grid(row=8, column=0, columnspan=5, rowspan=11, padx=10, pady=20)
#======================ends here===================================================

#========================================================
root = Tk()
root.title("Bottle Boutique")
root.geometry("950x600")
my_tree = ttk.Treeview(root)


#creating placeholders for textboxes
ph1 = tk.StringVar()
ph2 = tk.StringVar()
ph3 = tk.StringVar()
ph4 = tk.StringVar()
# ph5 = tk.StringVar()
# ph6 = tk.StringVar()
# ph7 = tk.StringVar()

#placeholder set value function
def setph(word,num):
    if num ==1:
        ph1.set(word)
    if num ==2:
        ph2.set(word)
    if num ==3:
        ph3.set(word)
    if num ==4:
        ph4.set(word)
    # if num ==5:
    #     ph5.set(word)
    # if num ==6:
    #     ph6.set(word)
    # if num ==7:
    #     ph7.set(word)

#creating function to read from database laundry
def read():
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM inventory")
    results = cursor.fetchall()
    conn.commit()
    conn.close()
    return results
#=============================end====================


#function for search button
def search():
    id = str(idEntry.get())
    name = str(nameEntry.get())
    stock = str(stockEntry.get())
    price = str(priceEntry.get())
    # phone = str(phoneEntry.get())
    # Noc = str(NocEntry.get())
    # date = str(dateEntry.get())

    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM inventory WHERE id='" + id + "' or name='" + name + "' or stock='" +stock + "' or price='" +price + "' ")

    try:
        result = cursor.fetchall()

        for num in range(0, 4):
            setph(result[0][num], (num + 1))

        conn.commit()
        conn.close()
    except:
        messagebox.showinfo("Error", "No data in database")

#======================================end=======================================

#function for update button
def update():
    selectedid = ""

    try:
        selected_item = my_tree.selection()[0]
        selectedid = str(my_tree.item(selected_item)['values'][0])
    except:
        messagebox.showinfo("Error", "Please select a data row")

    id = str(idEntry.get())
    name = str(nameEntry.get())
    stock = str(stockEntry.get())
    price = str(priceEntry.get())
    # phone = str(phoneEntry.get())
    # Noc = str(NocEntry.get())
    # date = str(dateEntry.get())

    if (id == "" or id == " ") or (name == "" or name == " ") or (stock == "" or stock == " ") or (price == "" or price == " ") :
        messagebox.showinfo("Error", "All fields are required")
        return
    else:
        try:
            conn = connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE inventory SET id='"+
            id+"', name='"+
            name+"', stock='"+
            stock+"', price='"+
            price+"' WHERE id='"+
            selectedid+"' ")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Stock ID exits already")
            return

    refreshTable()
#==========================end=======================



#function for delete button
def delete():
    decision = messagebox.askquestion("Warning!!", "Are you sure you want to delete the selected data?")
    if decision != "yes":
        return
    else:
        selected_item = my_tree.selection()[0]
        deleteData = str(my_tree.item(selected_item)['values'][0])
        try:
            conn = connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM inventory WHERE id='"+str(deleteData)+"'")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Sorry an error occured")
            return

        refreshTable()
#===================================end========================

#function for reset button
# def reset():
#     decision = messagebox.askquestion("Warning!!", "Do you want to delete all the data in the database?")
#     if decision != "yes":
#         return
#     else:
#         try:
#             conn = connection()
#             cursor = conn.cursor()
#             cursor.execute("DELETE FROM services")
#             conn.commit()
#             conn.close()
#         except:
#             messagebox.showinfo("Error", "Sorry an error occured")
#             return
#
#         refreshTable()
#=======================================end===========================================

#function to insert into the database
def add():
    id = str(idEntry.get())
    name = str(nameEntry.get())
    stock = str(stockEntry.get())
    price = str(priceEntry.get())
    # phone = str(phoneEntry.get())
    # Noc = str(NocEntry.get())
    # date = str(dateEntry.get())
    #
    if (id == "" or id == " ") or (name == "" or name == " ") or (stock == "" or stock == " ") or (price == "" or price == " "):
        messagebox.showinfo("Error", "Please all fields are required")
        return
    else:
        try:
            conn = connection()
            cursor = conn.cursor()                          #
            cursor.execute("INSERT INTO inventory VALUES ('"+id+"','"+name+"','"+stock+"','"+price+"') ")
            conn.commit()
            conn.close()
        except:
            messagebox.showinfo("Error", "Stock ID already exist")
            return
    #calling function below to refresh the data table after inserting to the database
    refreshTable()
#===================ends================================================================================

#function for select button
def select():
    try:
        selected_item = my_tree.selection()[0]
        id = str(my_tree.item(selected_item)['values'][0])
        name = str(my_tree.item(selected_item)['values'][1])
        stock = str(my_tree.item(selected_item)['values'][2])
        price = str(my_tree.item(selected_item)['values'][3])
        # phone = str(my_tree.item(selected_item)['values'][4])
        # Noc = str(my_tree.item(selected_item)['values'][4])
        # date = str(my_tree.item(selected_item)['values'][4])

        setph(id,1)
        setph(name,2)
        setph(stock,3)
        setph(price,4)
        # setph(phone,5)
        # setph(Noc, 6)
        # setph(date, 7)
    except:
        messagebox.showinfo("Error", "Please select a data row")

#==================end=======================


btn_hlb_bg = 'SteelBlue'
#Main Design
label = Label(root, text="Bottle Boutique ", font=('Arial Bold', 30,), bg='#33783f', fg='White' )
label.grid(row=0, column=0, columnspan=8, rowspan=2, padx=10, pady=10)


idLabel = Label(root, text="id", font=('Arial', 15), bg='#33783f', fg='White')
nameLabel = Label(root, text="name", font=('Arial', 15), bg='#33783f', fg='White')
stockLabel = Label(root, text="stock", font=('Arial', 15), bg='#33783f', fg='White')
priceLabel = Label(root, text="price", font=('Arial', 15), bg='#33783f', fg='White')


idLabel.grid(row=3, column=0, columnspan=1, padx=25, pady=5)
nameLabel.grid(row=4, column=0, columnspan=1, padx=25, pady=5)
stockLabel.grid(row=5, column=0, columnspan=1, padx=25, pady=5)
priceLabel.grid(row=6, column=0, columnspan=1, padx=25, pady=5)

idEntry = Entry(root, width=25, bd=5, font=('Arial', 15), textvariable = ph1)
nameEntry = Entry(root, width=25, bd=5, font=('Arial', 15), textvariable = ph2)
stockEntry = Entry(root, width=25, bd=5, font=('Arial', 15), textvariable = ph3)
priceEntry = Entry(root, width=25, bd=5, font=('Arial', 15), textvariable = ph4)

idEntry.grid(row=3, column=1, columnspan=1, padx=1, pady=0)
nameEntry.grid(row=4, column=1, columnspan=1, padx=1, pady=0)
stockEntry.grid(row=5, column=1, columnspan=1, padx=1, pady=0)
priceEntry.grid(row=6, column=1, columnspan=1, padx=1, pady=0)
# phoneEntry.grid(row=7, column=1, columnspan=1, padx=1, pady=0)
# NocEntry.grid(row=8, column=1, columnspan=1, padx=1, pady=0)
# dateEntry.grid(row=9, column=1, columnspan=1, padx=1, pady=0)

addBtn = Button(
    root, text="ADD", padx=10, pady=10, width=10,
    bd=3, font=('Arial', 12), bg="#93ac8f", command=add)
updateBtn = Button(
    root, text="UPDATE",  padx=10, pady=10, width=10,
    bd=3, font=('Arial', 12), bg="#93ac8f", command=update)
deleteBtn = Button(
    root, text="DELETE",  padx=10, pady=10, width=10,
    bd=3, font=('Arial', 12), bg="#93ac8f", command=delete)
searchBtn = Button(
    root, text="SEARCH",  padx=10, pady=10, width=5,
    bd=3, font=('Arial', 8), bg="#93ac8f", command=search)
# resetBtn = Button(
#     root, text="RESET",  padx=10, pady=10, width=10,
#     bd=3, font=('Arial', 12), bg="#84E8F8", command=reset)

selectBtn = Button(
     root, text="SELECT",  padx=10, pady=10, width=10,
     bd=3, font=('Arial', 12), bg="#93ac8f", command=select)

searchBtn.grid(row=2, column=2, columnspan=1, rowspan=2)
addBtn.grid(row=4, column=2, columnspan=1, rowspan=2)
updateBtn.grid(row=4, column=3, columnspan=1, rowspan=2)
deleteBtn.grid(row=6, column=2, columnspan=1, rowspan=2)
#searchBtn.grid(row=5, column=3, columnspan=1, rowspan=2)
#resetBtn.grid(row=7, column=2, columnspan=1, rowspan=2)
selectBtn.grid(row=6, column=3, columnspan=1, rowspan=2)

style = ttk.Style()
style.configure("Treeview.Heading", font=('Arial Bold', 12))


my_tree['columns'] = ("id","Name","No of Stock","Price")

my_tree.column("#0", width=0, stretch=NO)
my_tree.column("id", anchor=W, width=120)
my_tree.column("Name", anchor=W, width=120)
my_tree.column("No of Stock", anchor=W, width=120)
my_tree.column("Price", anchor=W, width=125)


my_tree.heading("id", text="Stock ID", anchor=W)
my_tree.heading("Name", text="Product Name", anchor=W)
my_tree.heading("No of Stock", text="No in Stock", anchor=W)
my_tree.heading("Price", text="Price", anchor=W)


#my_tree.tag_configure('orow', background='#0099ff', font=('Arial bold', 15))



refreshTable()


root.mainloop()