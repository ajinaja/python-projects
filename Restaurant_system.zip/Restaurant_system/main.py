from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql
from mysql.connector import cursor
from PIL import ImageTk, Image


Splash_Screen = Tk()
Splash_Screen.geometry("700x300+300+200")
Splash_Screen.overrideredirect(True)
#Splash_Screen.title("Login Form")


# =========================Bg==================================================================

my_img = ImageTk.PhotoImage(Image.open("1792743-middle.png"))
my_label = Label(image=my_img)
my_label.pack()
#===================================================Function=======================================

#===============================================================Second Form===========================================================
def dashboard():

    dashboard = Toplevel()
    dashboard.geometry("1100x600+100+40")
    dashboard.title("Dashboard")
    dashboard.attributes('-fullscreen', True)

    title_label = Label(dashboard, text="Restaurant Management System", fg='white', bg='tomato', width=200, font=('bold', 20)).pack()



    #=================================================convert variables=============================
    friesz = IntVar()
    saladz = IntVar()
    hambugerz = IntVar()
    chicken_saladz = IntVar()
    fish_Sandwichz  = IntVar()
    cheese_Sandwichz = IntVar()
    chicken_Sandwichz = IntVar()
    teaz = IntVar()
    colaz = IntVar()
    coffez = IntVar()
    orangez = IntVar()
    bottle_waterz =  IntVar()
    vanille_conaz = IntVar()
    strawberryz =  IntVar()
    paymentz = IntVar()

    totalz = IntVar()


    def cal_all():
        receipt.delete("1.0", END)
        e_Total.delete(0, 'end')
        e_Change.delete(0, 'end')
        all  = 200*friesz.get()+500*saladz.get()+150*hambugerz.get()+1500*chicken_saladz.get()+2000*fish_Sandwichz.get()+500*cheese_Sandwichz.get()+2000*chicken_Sandwichz.get()+200*teaz.get()+250*colaz.get()+200*coffez.get()+200*orangez.get()+150*bottle_waterz.get()+150*vanille_conaz.get()+100*strawberryz.get()
        e_Total.insert(0,str(all))

    def total_change():

        all  = 200*friesz.get()+500*saladz.get()+150*hambugerz.get()+1500*chicken_saladz.get()+2000*fish_Sandwichz.get()+500*cheese_Sandwichz.get()+2000*chicken_Sandwichz.get()+200*teaz.get()+250*colaz.get()+200*coffez.get()+200*orangez.get()+150*bottle_waterz.get()+150*vanille_conaz.get()+100*strawberryz.get()
        final = paymentz.get()-all

        e_Change.insert(0,str(final))




    #================================================Clear all===============================================================
    def clearorder():
        e_fries.delete(0, 'end')
        e_salad.delete(0, 'end')
        e_hambuger.delete(0, 'end')
        e_Chicken_Salad.delete(0, 'end')
        e_Fish_Sandwich.delete(0, 'end')
        e_Cheese_Sandwich.delete(0, 'end')
        e_Chicken_Sandwich.delete(0, 'end')
        e_Tea.delete(0, 'end')
        e_Cola.delete(0, 'end')
        e_Coffee.delete(0, 'end')
        e_Orange.delete(0, 'end')
        e_Bottle_Water.delete(0, 'end')
        e_Vanille_Cona.delete(0, 'end')
        e_Strawberry_Shake.delete(0, 'end')
      #  receipt.delete(0, 'end')
        receipt.delete("1.0", END)
        e_Total.delete(0, 'end')
        e_Change.delete(0, 'end')

        e_fries.insert(0, "0")
        e_salad.insert(0, "0")
        e_hambuger.insert(0, "0")
        e_Chicken_Salad.insert(0, "0")
        e_Fish_Sandwich.insert(0, "0")
        e_Cheese_Sandwich.insert(0, "0")
        e_Chicken_Sandwich.insert(0, "0")
        e_Tea.insert(0, "0")
        e_Cola.insert(0, "0")
        e_Coffee.insert(0, "0")
        e_Orange.insert(0, "0")
        e_Bottle_Water.insert(0, "0")
        e_Vanille_Cona.insert(0, "0")
        e_Strawberry_Shake.insert(0, "0")
        #  receipt.delete(0, 'end')
        e_Total.insert(0, "0")
        e_Change.inset(0, "0")






    #===============================================================Insert========================================================
    def insert():

        fries = e_fries.get()
        salad = e_salad.get()
        hambuger = e_hambuger.get()
        Chicken_Salad = e_Chicken_Salad.get()
        Fish_Sandwich = e_Fish_Sandwich.get()
        Cheese_Sandwich = e_Cheese_Sandwich.get()
        Chicken_Sandwich = e_Chicken_Sandwich.get()
        Tea = e_Tea.get()
        Cola = e_Cola.get()
        Coffee = e_Coffee.get()
        Orange = e_Orange.get()
        Bottle_Water = e_Bottle_Water.get()
        Vanille_Cona = e_Vanille_Cona.get()
        Strawberry_Shake = e_Strawberry_Shake.get()


        Payment = e_Payment.get()
        Totalz = e_Total.get()
        Change = e_Change.get()
        if (Payment == "" or Totalz == "" or Change == ""):
            MessageBox.showinfo("Insert Status", "All Payments are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_restaurant_db")
            cursor = con.cursor()
            cursor.execute("insert into order_record values('" + fries + "', '" + salad + "', '" + hambuger + "', '" + Chicken_Salad + "', '" + Fish_Sandwich + "', '" + Cheese_Sandwich + "', '" + Chicken_Sandwich + "', '" + Tea + "', '" + Cola + "', '" + Coffee + "', '" + Orange + "', '" + Bottle_Water + "', '" + Vanille_Cona + "', '" + Strawberry_Shake + "', '" + Payment + "')")
            cursor.execute("commit")


           # show()
            MessageBox.showinfo("Insert Status", "Inserted Successfully")

        con.close()
        all = 200 * friesz.get() + 500 * saladz.get() + 150 * hambugerz.get() + 1500 * chicken_saladz.get() + 2000 * fish_Sandwichz.get() + 500 * cheese_Sandwichz.get() + 2000 * chicken_Sandwichz.get() + 200 * teaz.get() + 250 * colaz.get() + 200 * coffez.get() + 200 * orangez.get() + 150 * bottle_waterz.get() + 150 * vanille_conaz.get() + 100 * strawberryz.get()
        final = paymentz.get() - all

        totalz = 200 * friesz.get() + 500 * saladz.get() + 150 * hambugerz.get() + 1500 * chicken_saladz.get() + 2000 * fish_Sandwichz.get() + 500 * cheese_Sandwichz.get() + 2000 * chicken_Sandwichz.get() + 200 * teaz.get() + 250 * colaz.get() + 200 * coffez.get() + 200 * orangez.get() + 150 * bottle_waterz.get() + 150 * vanille_conaz.get() + 100 * strawberryz.get()

        receipt.insert(END, '==================================================' + '\n')
        receipt.insert(END, '====================Restuarant Management=================' + '\n')
        receipt.insert(END, '======================Customer Receipt=====================' + '\n')


        receipt.insert(END, '==================================================' + '\n')



        receipt.insert(END, 'Fries:\t\t\t\t\t' + e_fries.get() + '\n')
        receipt.insert(END, 'Salad:\t\t\t\t\t' + e_salad.get() + '\n')
        receipt.insert(END, 'hambuger:\t\t\t\t\t' + e_hambuger.get() + '\n')
        receipt.insert(END, 'Chicken_Salad:\t\t\t\t\t' + e_Chicken_Salad.get() + '\n')
        receipt.insert(END, 'Fish_Sandwich:\t\t\t\t\t' + e_Fish_Sandwich.get() + '\n')
        receipt.insert(END, 'Cheese_Sandwich:\t\t\t\t\t' + e_Cheese_Sandwich.get() + '\n')
        receipt.insert(END, 'Chicken_Sandwich:\t\t\t\t\t' + e_Chicken_Sandwich.get() + '\n')
        receipt.insert(END, 'Tea:\t\t\t\t\t' + e_Tea.get() + '\n')
        receipt.insert(END, 'Cola:\t\t\t\t\t' + e_Cola.get() + '\n')
        receipt.insert(END, 'Coffee:\t\t\t\t\t' + e_Coffee.get() + '\n')
        receipt.insert(END, 'Orange:\t\t\t\t\t' + e_Orange.get() + '\n')
        receipt.insert(END, 'Bottle_Water:\t\t\t\t\t' + e_Bottle_Water.get() + '\n')
        receipt.insert(END, 'Vanille_Cona:\t\t\t\t\t' + e_Vanille_Cona.get() + '\n')

        receipt.insert(END, 'Strawberry_Shake:\t\t\t\t\t' + e_Strawberry_Shake.get() + '\n')
        receipt.insert(END, '==================================================' + '\n')
        receipt.insert(END, 'Payment:\t\t\t\t\t' +  "#" + e_Payment.get() + '\n')
        receipt.insert(END, 'Total:\t\t\t\t\t' +  "#" + str(totalz) + '\n')
        receipt.insert(END, 'Change:\t\t\t\t\t' + "#" +str(final) + '\n')




    #================================items=========================================================
    lb1 = Label(dashboard, text="Fast Meal and Vegeterian", fg='white', bg='black', width=48, font=('bold', 15))
    lb1.place(x=50, y=50)
    fries = Label(dashboard,  text="Enter Fries quantity:", fg='tomato', font=('bold', 12))
    fries.place(x=50, y=90)
    e_fries = Entry(dashboard, textvariable=friesz, width=30, font=('bold', 12))
    e_fries.place(x=300, y=90)

    salad = Label(dashboard, text="Enter Salad Quantity:", fg='tomato', font=('bold', 12))
    salad.place(x=50, y=130)
    e_salad = Entry(dashboard, textvariable=saladz,  width=30, font=('bold', 12))
    e_salad.place(x=300, y=130)

    hambuger = Label(dashboard, text="Enter Hambuger Quantity:", fg='tomato', font=('bold', 12))
    hambuger.place(x=50, y=170)
    e_hambuger = Entry(dashboard, textvariable=hambugerz, width=30, font=('bold', 12))
    e_hambuger.place(x=300, y=170)

    Chicken_Salad = Label(dashboard, text="Enter Chicken Salad Quantity:", fg='tomato', font=('bold', 12))
    Chicken_Salad.place(x=50, y=210)
    e_Chicken_Salad = Entry(dashboard, textvariable=chicken_saladz, width=30, font=('bold', 12))
    e_Chicken_Salad.place(x=300, y=210)

    Fish_Sandwich = Label(dashboard, text="Enter Fish Sandwich Quantity:", fg='tomato', font=('bold', 12))
    Fish_Sandwich.place(x=50, y=260)
    e_Fish_Sandwich = Entry(dashboard, textvariable=fish_Sandwichz, width=30, font=('bold', 12))
    e_Fish_Sandwich.place(x=300, y=260)

    Cheese_Sandwich = Label(dashboard, text="Enter Cheese Sandwich Quantity:", fg='tomato', font=('bold', 12))
    Cheese_Sandwich.place(x=50, y=310)
    e_Cheese_Sandwich = Entry(dashboard, textvariable=cheese_Sandwichz, width=30, font=('bold', 12))
    e_Cheese_Sandwich.place(x=300, y=310)

    Chicken_Sandwich = Label(dashboard, text="Enter Chicken Sandwich Quantity:", fg='tomato',  font=('bold', 12))
    Chicken_Sandwich.place(x=50, y=350)
    e_Chicken_Sandwich = Entry(dashboard, textvariable=chicken_Sandwichz,  width=30, font=('bold', 12))
    e_Chicken_Sandwich.place(x=300, y=350)

    #=====================================Drinks==================================

    lb2 = Label(dashboard, text="Drinks", fg='white', bg='black', width=48, font=('bold', 15))
    lb2.place(x=700, y=50)
    Tea = Label(dashboard, text="Enter Tea Quantity:", fg='tomato', font=('bold', 12))
    Tea.place(x=700, y=90)
    e_Tea = Entry(dashboard, width=30, textvariable=teaz, font=('bold', 12))
    e_Tea.place(x=900, y=90)

    Cola = Label(dashboard, text="Enter Cola Quantity:", fg='tomato', font=('bold', 12))
    Cola.place(x=700, y=130)
    e_Cola = Entry(dashboard, width=30, textvariable=colaz, font=('bold', 12))
    e_Cola.place(x=900, y=130)

    Coffee = Label(dashboard, text="Enter Coffee Quantity:", fg='tomato', font=('bold', 12))
    Coffee.place(x=700, y=130)
    e_Coffee = Entry(dashboard, width=30, textvariable=coffez, font=('bold', 12))
    e_Coffee.place(x=900, y=130)

    Orange = Label(dashboard, text="Enter Orange Quantity:", fg='tomato', font=('bold', 12))
    Orange.place(x=700, y=170)
    e_Orange = Entry(dashboard, width=30, textvariable=orangez, font=('bold', 12))
    e_Orange.place(x=900, y=170)

    Bottle_Water = Label(dashboard, text="Enter Bottle Water Quantity:", fg='tomato', font=('bold', 12))
    Bottle_Water.place(x=700, y=210)
    e_Bottle_Water = Entry(dashboard, textvariable=bottle_waterz, width=30, font=('bold', 12))
    e_Bottle_Water.place(x=900, y=210)

    #=======================================Shakes============================================

    lb3 = Label(dashboard, text="Drinks", fg='white', bg='black', width=48, font=('bold', 15))
    lb3.place(x=700, y=260)
    Vanille_Cona = Label(dashboard, text="Enter Vanille Cona Quantity:", fg='tomato', font=('bold', 12))
    Vanille_Cona.place(x=700, y=310)
    e_Vanille_Cona = Entry(dashboard, textvariable=vanille_conaz , width=30, font=('bold', 12))
    e_Vanille_Cona.place(x=900, y=310)

    Strawberry_Shake = Label(dashboard, text="Enter Strawberry Shake Quantity:", fg='tomato', font=('bold', 12))
    Strawberry_Shake.place(x=700, y=350)
    e_Strawberry_Shake = Entry(dashboard, textvariable=strawberryz,  width=30, font=('bold', 12))
    e_Strawberry_Shake.place(x=900, y=350)

    #================================================Total====================================
    lb3 = Label(dashboard, text="Total", fg='white', bg='black', width=48, font=('bold', 15))
    lb3.place(x=50, y=390)

    Sub_Total = Label(dashboard, text="Sub Total", fg='tomato', font=('bold', 12))
    Sub_Total.place(x=50, y=430)


    e_Total = Entry(dashboard, fg='tomato', font=('bold', 12))
    e_Total.place(x=300, y=430)



    Payment = Label(dashboard, text="Enter Amount:", fg='tomato', font=('bold', 12))
    Payment.place(x=50, y=470)
    e_Payment = Entry(dashboard, textvariable=paymentz, width=30, font=('bold', 12))
    e_Payment.place(x=300, y=470)



    Change = Label(dashboard, text="Change:", fg='tomato', font=('bold', 12))
    Change.place(x=50, y=510)
    e_Change = Entry(dashboard, width=20, fg='tomato', font=('bold', 12))
    e_Change.place(x=300, y=510)


    # ================================================Controls====================================
    lb3 = Label(dashboard, text="Controls", fg='white', bg='black', width=48, font=('bold', 15))
    lb3.place(x=50, y=590)

    Sub_Total_btn = Button(dashboard, text="Sub Total", fg='white', bg='tomato', font=("italic", 12), command=cal_all)
    Sub_Total_btn.place(x=50, y=630)

    Change_Total = Button(dashboard, text="Change", fg='white', bg='tomato', font=("italic", 12), command=total_change)
    Change_Total.place(x=150, y=630)

    Insert = Button(dashboard, text="Order/Print Receipt", fg='white', bg='tomato', font=("italic", 12), command=insert)
    Insert.place(x=250, y=630)

    Clearorder = Button(dashboard, text="Reset", fg='white', bg='tomato', font=("italic", 12), command=clearorder)
    Clearorder.place(x=450, y=630)

    Record = Button(dashboard, text="View Record", fg='white', bg='tomato', font=("italic", 12), command=record)
    Record.place(x=550, y=630)



    # ================================================Receipt====================================
    lb3 = Label(dashboard, text="Receipt", fg='white', bg='black', width=48, font=('bold', 15))
    lb3.place(x=700, y=390)

    # receipt = Listbox(dashboard, width=90)
    # receipt.place(x=700, y=430)

    receipt = Text(dashboard, width=50,height=12)
    receipt.place(x=700, y=430)




#================================================All order==================================================

def record():
    record = Tk()

    record.geometry("500x300+400+200")
    record.title("Order Records")

    list = Listbox(record, width=300, height=20)
    list.place(x=50, y=50)

    con = mysql.connect(host="localhost", user="root", password="", database="py_restaurant_db")
    cursor = con.cursor()
    cursor.execute("select * from order_record")
    rows = cursor.fetchall()
    #list.delete(0, list.size())

    for row in rows:
        insertDataz = "Fries               Salad          hambuger            Chicken Salad             Fish Sandwich               Cheese_Sandwich                  Chicken Sandwich                       Tea                                 Cola                                    Coffee        Orange                 Bottle Water         Vanille Cona            Strawberry_Shake           Payment"
        insertData = str(row[0])+'                   '+ row[1] +'                 '+ row[2]+'             '+ row[3]+'             '+ row[4]+'               '+ row[5]+'                 '+ row[6]+'                        '+ row[7]+'                              '+ row[8]+'                             '+ row[9]+'                              '+ row[10]+'                                 '+ row[11]+'                '+ row[12]+'                                    '+ row[13]+'                                    '+ row[14]
        list.insert(list.size()+1, insertDataz,  insertData)






    con.close();









def hide():
    Splash_Screen.destroy()
    login_main()

Splash_Screen.after(5000, hide)


def login_main():
    login = Tk()

    login.geometry("500x300+400+200")
    login.title("Login Form")
    title_label = Label(login, text="ADMIN LOGIN PAGE", fg='white', bg='tomato', width=200, font=('bold', 20)).pack()



    def login_code():
        username = e_username.get();
        password = e_password.get();
        if (username == "" or password == ""):
            MessageBox.showinfo("Empty  Status", "Username and Password is required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="py_restaurant_db")
            cursor = con.cursor()
            cursor.execute("select * from admin_info where username='" + username + "' and password='" + password + "'")
            rows = cursor.fetchall()
            if(rows):
                MessageBox.showinfo("success", "Your have successfully Login")
                e_username.delete(0, 'end')
                e_password.delete(0, 'end')

                dashboard()


                return True

            else:
                MessageBox.showinfo("success", "Incorrect username or password")
                return False
            con.close()
    def clea():
        e_username.delete(0,  'end')
        e_password.delete(0,  'end')


    #=========================Bg==================================================================
    # my_img = ImageTk.PhotoImage(Image.open("1792743-middle.png"))
    # my_label = Label(image=my_img)
    # my_label.pack()
    #================================Username=========================================================
    username = Label(login, text="Enter your Username:", fg='white', bg='tomato', font=('bold', 12))
    username.place(x=50, y=90)
    e_username = Entry(width=20, font=('bold', 12))
    e_username.place(x=250, y=90)

    #====================================================Password=========================================
    password = Label(login, text="Enter your Password:",  fg='white', bg='tomato', font=('bold', 12))
    password.place(x=50, y=130)
    e_password = Entry(login, show="x", width=20, font=('bold', 12))
    e_password.place(x=250, y=130)

    Login = Button(login, text="Login", fg='white', bg='tomato', font=("italic", 12), command=login_code)
    Login.place(x=250, y=190)


    Clear = Button(login, text="Clear", fg='white', bg='tomato', font=("italic", 12), command=clea)
    Clear.place(x=400, y=190)




Splash_Screen.mainloop()