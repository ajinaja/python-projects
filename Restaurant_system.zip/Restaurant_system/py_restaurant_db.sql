-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2022 at 11:35 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `py_restaurant_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`username`, `password`) VALUES
('mikey', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `order_record`
--

CREATE TABLE `order_record` (
  `fries` varchar(50) NOT NULL,
  `salad` varchar(50) NOT NULL,
  `hambuger` varchar(50) NOT NULL,
  `Chicken_Salad` varchar(50) NOT NULL,
  `Fish_Sandwich` varchar(50) NOT NULL,
  `Cheese_Sandwich` varchar(50) NOT NULL,
  `Chicken_Sandwich` varchar(50) NOT NULL,
  `Tea` varchar(50) NOT NULL,
  `Cola` varchar(50) NOT NULL,
  `Coffee` varchar(50) NOT NULL,
  `Orange` varchar(50) NOT NULL,
  `Bottle_Water` varchar(50) NOT NULL,
  `Vanille_Cona` varchar(50) NOT NULL,
  `Strawberry_Shake` varchar(50) NOT NULL,
  `Payment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_record`
--

INSERT INTO `order_record` (`fries`, `salad`, `hambuger`, `Chicken_Salad`, `Fish_Sandwich`, `Cheese_Sandwich`, `Chicken_Sandwich`, `Tea`, `Cola`, `Coffee`, `Orange`, `Bottle_Water`, `Vanille_Cona`, `Strawberry_Shake`, `Payment`) VALUES
('3', '0', '0', '0', '44', '0', '0', '0', '0', '0', '4', '0', '2', '0', '9000000'),
('3', '0', '0', '0', '44', '0', '0', '0', '0', '0', '4', '0', '2', '0', '9000000'),
('3', '0', '0', '0', '44', '0', '0', '0', '0', '0', '4', '0', '2', '0', '9000000'),
('0', '0', '0', '0', '7', '0', '0', '2', '0', '0', '0', '7', '9', '0', '300000'),
('7', '0', '0', '0', '7', '0', '0', '2', '0', '0', '0', '7', '9', '0', '300000'),
('1', '0', '0', '8', '0', '90', '0', '5', '0', '0', '0', '20', '0', '0', '70000'),
('0', '0', '0', '0', '0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '2000'),
('0', '0', '2', '0', '0', '2', '0', '0', '0', '8', '3', '1', '0', '0', '5000'),
('0', '0', '0', '0', '0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '3000'),
('0', '0', '0', '0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '0', '5000'),
('0', '2', '0', '0', '0', '8', '0', '0', '0', '0', '8', '0', '0', '0', '70000'),
('0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '9', '0', '0', '0', '3000'),
('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
('0', '3', '0', '0', '0', '5', '8', '0', '0', '8', '0', '0', '0', '0', '60000'),
('0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '0', '8', '0', '0', '80000'),
('0', '0', '0', '0', '0', '9', '0', '0', '0', '0', '0', '9', '0', '0', '80000'),
('0', '0', '0', '0', '0', '5', '0', '0', '0', '0', '0', '8', '0', '0', '40000'),
('0', '0', '0', '0', '0', '4', '0', '0', '0', '0', '4', '0', '0', '0', '30000'),
('0', '0', '0', '0', '0', '0', '8', '0', '0', '0', '0', '3', '0', '0', '50000'),
('0', '0', '0', '3', '0', '0', '0', '0', '0', '0', '0', '5', '0', '0', '500000'),
('0', '0', '0', '0', '5', '0', '0', '0', '0', '0', '0', '5', '0', '0', '90000'),
('0', '0', '0', '0', '0', '3', '0', '0', '0', '0', '4', '0', '0', '0', '50000'),
('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
('50', '0', '0', '0', '50', '2', '0', '0', '0', '5', '0', '0', '9', '0', '8000000'),
('0', '0', '0', '0', '0', '0', '4', '0', '0', '0', '9', '0', '0', '0', '80000'),
('3', '0', '7', '4', '0', '8', '0', '0', '0', '50', '2', '0', '9', '1', '500000');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
