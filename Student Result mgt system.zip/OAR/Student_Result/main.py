import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import mysql.connector as mysql


def staff_login():
    # Create window object
    slp = Tk()

    def clear():
        e_username.delete(0, 'end')
        e_password.delete(0, 'end')

    def logins():
        usernames = e_username.get()
        passwords = e_password.get()

        if (usernames == "" or passwords == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the empty space ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            curses = con.cursor()
            curses.execute("SELECT * FROM `staff_records` WHERE `Username`='" + usernames + "' AND `Password`='" + passwords + "'")
            rows = curses.fetchall()

            if (rows):
                messagebox.showinfo("Login Status", "Login Successful ...?")
                slp.withdraw()
                dashboard()
            else:
                messagebox.showinfo("Login Status", "Invalid Username or Password ...?")

            con.close()

    def closes():
        slp.destroy()

    tittle = Label(slp, text="Staff Login", font=('bold', 15))
    tittle.place(x=250, y=5)
    closef = Button(slp, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=550, y=2)

    # Username
    username = Label(slp, text='Username:', font=('bold', 15))
    username.place(x=20, y=90)

    e_username = Entry(slp, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_username.place(x=250, y=90)

    # Password
    password = Label(slp, text='Password:', font=('bold', 15))
    password.place(x=20, y=160)

    e_password = Entry(slp, width=18, fg="#000", show='&', border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_password.place(x=250, y=160)

    clear = Button(slp, text="Reset", font="italic, 15", bg="white", command=clear)
    clear.place(x=300, y=230)

    login = Button(slp, text="Log In", font="italic, 15", bg="white", command=logins)
    login.place(x=400, y=230)

    slp.title('Staff Login')
    slp.geometry('580x350')
    slp.configure(bg='yellowgreen')

    # Start program
    slp.mainloop()


def dashboard():
    def student_scores():
        sdb.withdraw()
        add_score_s()

    def add_semester_results():
        sdb.withdraw()
        semester()


    #def add_students():
        #admin_login()
    def closes():
        sdb.destroy()

    sdb = Tk()

    tittle = Label(sdb, text="Student Result Management System", font=('bold', 19))
    tittle.place(x=250, y=5)
    closef = Button(sdb, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=850, y=2)

    add_score1 = Button(sdb, text="Add Score", font="italic, 35", width=29, bg="white", command=student_scores)
    add_score1.place(x=20, y=50)

    add_semester_result = Button(sdb, text="Semester Results", width=29, font="italic, 35", bg="white", command=add_semester_results)
    add_semester_result.place(x=20, y=150)

    """add_general_result = Button(sdb, text="Generales Result", width=29, font="italic, 35", bg="white", command=add_general_results)
    add_general_result.place(x=20, y=250)"""

    # add_student = Button(adb, text="Book", font="italic, 35", bg="white", command=add_students)
    # add_student.place(x=350, y=150)

    sdb.title('Student Result Management System')
    sdb.geometry('900x450')
    sdb.configure(bg="yellowgreen")

def add_score_s():
    def check():
        score1 = e_score.get()
        if (score1 == ""):
            messagebox.showwarning("Checking Status", "Please, Score must not be empty")
        else:
            scores = int(e_score.get())
            e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')
            if (scores >= 75 and scores <= 100):
                e_gpa.insert(0, 4.00)
                # e_gpa.get(4.00)
                e_grade.insert(0, "A")
            elif (scores >= 70 and scores <= 74):
                e_gpa.insert(0, 3.50)
                e_grade.insert(0, "AB")
            elif (scores >= 65 and scores <= 69):
                e_gpa.insert(0, 3.25)
                e_grade.insert(0, "B")
            elif (scores >= 60 and scores <= 64):
                e_gpa.insert(0, 3.00)
                e_grade.insert(0, "BC")
            elif (scores >= 55 and scores <= 59):
                e_gpa.insert(0, 2.75)
                e_grade.insert(0, "C")
            elif (scores >= 50 and scores <= 54):
                e_gpa.insert(0, 2.50)
                e_grade.insert(0, "CD")
            elif (scores >= 45 and scores <= 49):
                e_gpa.insert(0, 2.25)
                e_grade.insert(0, "D")
            elif (scores >= 40 and scores <= 44):
                e_gpa.insert(0, 2.00)
                e_grade.insert(0, "E")
            elif (scores >= 00 and scores <= 39):
                e_gpa.insert(0, 0.00)
                e_grade.getvar("F")
            elif (scores > 100 and scores < 0):
                e_gpa.insert(0, 0.00)
                e_grade.insert(0, "")

    def insert():
        matric_nos = e_matric_no.get()
        full_names = e_full_name.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        sessions = e_session.get()
        course_codes = e_course_code.get()
        scores = e_score.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()

        if (
                matric_nos == "" or full_names == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == "" or sessions == "" or course_codes == "" or scores == "" or gpas == "" or grades == ""):
            messagebox.showinfo("Insert Status", "All Fields are required")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # INSERT INTO `student_score`(`ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Course_Code`, `Score`, `Unit`, `GPA`, `Grade`, `Session`, `Created_Date`, `Last_Update`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11],[value-12],[value-13],[value-14],[value-15],[value-16])
        cursor = con.cursor()
        cursor.execute(
            "INSERT INTO `student_score`(`Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Course_Code`, `Score`, `Unit`, `GPA`, `Grade`, `Session`) VALUES ('" + matric_nos + "','" + full_names + "','" + schools + "','" + departments + "','" + levels + "','" + semesters + "','" + programmes + "','" + course_codes + "','" + scores + "', '" + units + "','" + gpas + "','" + grades + "','" + sessions + "')")
        cursor.execute("commit")

        e_matric_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_school.delete(0, 'end')
        e_department.delete(0, 'end')
        e_level.delete(0, 'end')
        e_semester.delete(0, 'end')
        e_programme.delete(0, 'end')
        e_session.delete(0, 'end')
        e_course_code.delete(0, 'end')
        e_score.delete(0, 'end')
        e_unit.delete(0, 'end')
        e_gpa.delete(0, 'end')
        e_grade.delete(0, 'end')

        messagebox.showinfo("Insert Status", "Inserted Successfully")
        con.close()

    def checks():
        if (e_matric_no.get() == "" or e_course_code.get() == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Matric. No. and Course Code ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # student_result »Table: staff_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `student_score` WHERE Matric_No='" + e_matric_no.get() + "' AND Course_Code='" + e_course_code.get() + "' ")
            # SELECT * FROM `student_score` WHERE Matric_No='" + e_matric_no.get() + "' AND Course_Code='" + e_course_code.get() + "'
            rows = curses.fetchall()
            if (rows):
                messagebox.showinfo("Check Information", "This course has been saved for this student")
            else:
                insert()

                con.close()

    def delete():
        if (e_matric_no.get() == "" or e_course_code.get() == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Matric. No. and Course Code")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            cursor = con.cursor()
            cursor.execute(
                "DELETE FROM `student_score` WHERE Matric_No='" + e_matric_no.get() + "' AND Course_Code='" + e_course_code.get() + "'")
            cursor.execute("commit");

            # e_matric_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_school.delete(0, 'end')
            e_department.delete(0, 'end')
            e_level.delete(0, 'end')
            e_semester.delete(0, 'end')
            e_programme.delete(0, 'end')
            e_session.delete(0, 'end')
            # e_course_code.delete(0, 'end')
            e_score.delete(0, 'end')
            e_unit.delete(0, 'end')
            e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')
            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()

    def update():
        matric_nos = e_matric_no.get()
        full_names = e_full_name.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        sessions = e_session.get()
        course_codes = e_course_code.get()
        scores = e_score.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()

        if (
                matric_nos == "" or full_names == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == "" or sessions == "" or course_codes == "" or scores == "" or unit == "" or gpas == "" or grades == ""):
            messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            cursor = con.cursor()
            cursor.execute(
                "UPDATE `student_score` SET Full_Name='" + full_names + "', School='" + schools + "', Department ='" + departments + "', Level='" + levels + "', Semester='" + semesters + "', Programme='" + programmes + "', Session='" + sessions + "', Score='" + scores + "', Unit='" + units + "', GPA='" + gpas + "', Grade='" + grades + "' WHERE Matric_No='" + matric_nos + "' AND Course_Code='" + course_codes + "' ")
            cursor.execute("commit")

            # e_matric_no.delete(0, 'end')
            e_full_name.delete(0, 'end')
            e_school.delete(0, 'end')
            e_department.delete(0, 'end')
            e_level.delete(0, 'end')
            e_semester.delete(0, 'end')
            e_programme.delete(0, 'end')
            e_session.delete(0, 'end')
            # e_course_code.delete(0, 'end')
            e_score.delete(0, 'end')
            e_unit.delete(0, 'end')
            e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')
            messagebox.showinfo("Update Status", "Updated Successfully")
            con.close()

    def get():
        if (e_matric_no.get() == "" or e_course_code.get() == ""):
            messagebox.showinfo("Fetch Status", "Please, fill up the field of Matric. No. and Course Code ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # student_result »Table: staff_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `student_score` WHERE Matric_No='" + e_matric_no.get() + "' AND Course_Code='" + e_course_code.get() + "'")
            # SELECT * FROM `student_score` WHERE 1
            # SELECT `ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Session`, `Course_Code`, `Score`, `GPA`, `Grade`, `Created_Date`, `Last_Update` FROM `student_score` WHERE 1
            rows = curses.fetchall()

            for row in rows:
                # Clear
                # e_matric_no.delete(0, 'end')
                e_full_name.delete(0, 'end')
                e_school.delete(0, 'end')
                e_department.delete(0, 'end')
                e_level.delete(0, 'end')
                e_semester.delete(0, 'end')
                e_programme.delete(0, 'end')
                e_session.delete(0, 'end')
                # e_course_code.delete(0, 'end')
                e_score.delete(0, 'end')
                e_unit.delete(0, 'end')
                e_gpa.delete(0, 'end')
                e_grade.delete(0, 'end')
                #  Fetch
                # e_matric_no.insert(0, row[1])
                e_full_name.insert(0, row[2])
                e_school.insert(0, row[3])
                e_department.insert(0, row[4])
                e_level.insert(0, row[5])
                e_semester.insert(0, row[6])
                e_programme.insert(0, row[7])
                e_session.insert(0, row[13])
                # e_course_code.insert(0, row[8])
                e_score.insert(0, row[9])
                e_unit.insert(0, row[10])
                e_gpa.insert(0, row[11])
                e_grade.insert(0, row[12])

                con.close()

    def clear():
        e_matric_no.delete(0, 'end')
        e_full_name.delete(0, 'end')
        e_school.delete(0, 'end')
        e_department.delete(0, 'end')
        e_level.delete(0, 'end')
        e_semester.delete(0, 'end')
        e_programme.delete(0, 'end')
        e_session.delete(0, 'end')
        e_course_code.delete(0, 'end')
        e_score.delete(0, 'end')
        e_unit.delete(0, 'end')
        e_gpa.delete(0, 'end')
        e_grade.delete(0, 'end')

    # Create window object
    def closes():
        asc.withdraw()
        dashboard()

    asc = Tk()
    tittle = Label(asc, text="Student Result Management System", font=('bold', 19))
    tittle.place(x=250, y=5)
    closef = Button(asc, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=1150, y=2)

    # Matric No
    matric_no = Label(asc, text='Matric No:', font=('bold', 18))
    matric_no.place(x=20, y=100)

    e_matric_no = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_matric_no.place(x=170, y=100)

    # Name
    full_name = Label(asc, text='Full Name:', font=('bold', 18))
    full_name.place(x=20, y=150)

    e_full_name = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_full_name.place(x=170, y=150)

    # School
    school = Label(asc, text='School:', font=('bold', 18))
    school.place(x=20, y=200)

    e_school = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_school.place(x=170, y=200)

    # Department
    department = Label(asc, text='Department:', font=('bold', 18))
    department.place(x=20, y=250)

    e_department = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_department.place(x=170, y=250)

    # Level
    level = Label(asc, text='Level:', font=('bold', 18))
    level.place(x=20, y=300)

    e_level = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_level.place(x=170, y=300)

    # Semester
    semester = Label(asc, text='Semester:', font=('bold', 18))
    semester.place(x=20, y=350)

    e_semester = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_semester.place(x=170, y=350)

    # Programme
    programme = Label(asc, text='Programme:', font=('bold', 18))
    programme.place(x=20, y=400)

    e_programme = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_programme.place(x=170, y=400)

    # Session
    session = Label(asc, text='Session:', font=('bold', 18))
    session.place(x=550, y=100)

    e_session = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_session.place(x=700, y=100)

    # Course Code
    course_code = Label(asc, text='Course Code:', font=('bold', 18))
    course_code.place(x=550, y=150)

    e_course_code = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_course_code.place(x=700, y=150)

    # Score
    score = Label(asc, text='Score:', font=('bold', 18))
    score.place(x=550, y=200)

    e_score = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    # e_score = Entry(asc, width=25, fg="black", border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
    e_score.place(x=700, y=200)

    # Unit
    unit = Label(asc, text='Unit:', font=('bold', 18))
    unit.place(x=550, y=250)

    e_unit = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_unit.place(x=700, y=250)

    # GPA
    gpa = Label(asc, text='GPA:', font=('bold', 18))
    gpa.place(x=550, y=300)

    e_gpa = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_gpa.place(x=700, y=300)

    # Grade
    grade = Label(asc, text='Grade:', font=('bold', 18))
    grade.place(x=550, y=350)

    e_grade = Entry(asc, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_grade.place(x=700, y=350)

    insert = Button(asc, text="Save", font="italic, 20", bg="white", command=checks)
    insert.place(x=650, y=400)

    clears = Button(asc, text="Clear", font="italic, 20", bg="white", command=clear)
    clears.place(x=650, y=480)

    checks = Button(asc, text="Check", font="italic, 20", bg="white", command=check)
    checks.place(x=760, y=480)

    delete = Button(asc, text="Delete", font="italic, 20", bg="white", command=delete)
    delete.place(x=760, y=400)

    update = Button(asc, text="Update", font="italic, 20", bg="white", command=update)
    update.place(x=880, y=400)

    get = Button(asc, text="Search", font="italic, 20", bg="white", command=get)
    get.place(x=1000, y=400)
    """
    bb = Button(asc, text="Test", font="italic, 20", bg="white", command=sem)
    bb.place(x=400, y=400) """

    asc.title('Student Result Management System')
    asc.geometry('1200x590')
    asc.configure(bg="yellowgreen")

    # Start program
    asc.mainloop()



def semester():
    def generate():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        total_courses = e_total_course.get()
        sessions = e_session.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()

        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == ""):
            messagebox.showinfo("Generating Status",
                                "Please, fill up the field of Matric. No., School, Department, Level, Semester and Programme ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # student_result »Table: staff_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `student_score` WHERE Matric_No='" + matric_nos + "' AND School='" + schools + "' AND Department='" + departments + "' AND Level='" + levels + "' AND Semester='" + semesters + "' AND Programme='" + programmes + "' ")
            rows = curses.fetchall()
            ts = 0
            t_unit = 0
            t_gpa = 0.00
            # unitm = 0
            # gpam = 0.00

            for row in rows:
                ts = ts + 1
                unitm = int(row[10])
                gpam = float(row[11])
                t_unit = t_unit + unitm
                t_gpa = t_gpa + (gpam * unitm)
                e_session.delete(0, 'end')
                e_session.insert(0, row[13])
            con.close()

            f_gpa = float(t_gpa / t_unit)
            # e_grade.delete(0, 'end')
            e_total_course.delete(0, 'end')
            e_total_course.insert(0, ts)
            e_unit.delete(0, 'end')
            e_unit.insert(0, t_unit)
            e_gpa.delete(0, 'end')
            e_gpa.insert(0, f_gpa)
            check_gpa()

    def check_gpa():
        # gpass = e_gpa.get()
        if (e_gpa.get() == ""):
            messagebox.showwarning("Checking Status", "Please, Score must not be empty")
        else:
            gpass = float(e_gpa.get())
            # e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')
            if (gpass >= 4.00):
                # e_gpa.insert(0, 4.00)
                # e_gpa.get(4.00)
                e_grade.insert(0, "A")
            elif (gpass >= 3.50 and gpass < 4.00):
                # e_gpa.insert(0, 3.50)
                e_grade.insert(0, "AB")
            elif (gpass >= 3.25 and gpass < 3.50):
                # e_gpa.insert(0, 3.25)
                e_grade.insert(0, "B")
            elif (gpass >= 3.00 and gpass < 3.25):
                # e_gpa.insert(0, 3.00)
                e_grade.insert(0, "BC")
            elif (gpass >= 2.75 and gpass < 3.00):
                # e_gpa.insert(0, 2.75)
                e_grade.insert(0, "C")
            elif (gpass >= 2.50 and gpass < 2.75):
                # e_gpa.insert(0, 2.50)
                e_grade.insert(0, "CD")
            elif (gpass >= 2.25 and gpass < 2.50):
                # e_gpa.insert(0, 2.25)
                e_grade.insert(0, "D")
            elif (gpass >= 2.00 and gpass <= 2.25):
                # e_gpa.insert(0, 2.00)
                e_grade.insert(0, "E")
            elif (gpass >= 0.00 and gpass <= 2.00):
                # e_gpa.insert(0, 0.00)
                e_grade.insert(0, "F")
            elif (gpass > 4.00 and gpass < 0.00):
                # e_gpa.insert(0, 0.00)
                e_grade.insert(0, "")

    def insert_record():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        total_courses = e_total_course.get()
        sessions = e_session.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()

        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == "" or total_courses == "" or sessions == "" or units == "" or gpas == "" or grades == ""):
            messagebox.showinfo("Generating Status",
                                "Please, fill up the field of Matric. No., School, Department, Level, Semester and Programme ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
        cursor = con.cursor()
        cursor.execute(
            "INSERT INTO `student_current_result`(`Matric_No`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Total_Course`, `Unit`, `GPA`, `Grade`, `Session`) VALUES ('" + matric_nos + "','" + schools + "','" + departments + "','" + levels + "','" + semesters + "','" + programmes + "','" + total_courses + "','" + units + "','" + gpas + "','" + grades + "','" + sessions + "')")
        cursor.execute("commit")

        e_matric_no.delete(0, 'end')
        e_school.delete(0, 'end')
        e_department.delete(0, 'end')
        e_level.delete(0, 'end')
        e_semester.delete(0, 'end')
        e_programme.delete(0, 'end')
        e_total_course.delete(0, 'end')
        e_session.delete(0, 'end')
        e_unit.delete(0, 'end')
        e_gpa.delete(0, 'end')
        e_grade.delete(0, 'end')

        messagebox.showinfo("Insert Status", "Inserted Successfully")
        con.close()

    def checks():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()

        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == ""):
            messagebox.showinfo("Generating Status",
                                "Please, fill up the field of Matric. No., School, Department, Level, Semester and Programme ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # student_result »Table: staff_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `student_current_result` WHERE Matric_No='" + matric_nos + "' AND School='" + schools + "' AND Department='" + departments + "' AND Level='" + levels + "' AND Semester='" + semesters + "' AND Programme='" + programmes + "' ")
            rows = curses.fetchall()
            if (rows):
                messagebox.showinfo("Check Information", "This course has been saved for this student")
            else:
                insert_record()

            con.close()

    def delete():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == ""):
            messagebox.showinfo("Generating Status",
                                "Please, fill up the field of Matric. No., School, Department, Level, Semester and Programme ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            cursor = con.cursor()
            cursor.execute(
                "DELETE FROM `student_current_result` WHERE Matric_No='" + matric_nos + "' AND School='" + schools + "' AND Department='" + departments + "' AND Level='" + levels + "' AND Semester='" + semesters + "' AND Programme='" + programmes + "' ")
            # DELETE FROM `student_score` WHERE 0
            cursor.execute("commit");

            e_matric_no.delete(0, 'end')
            e_school.delete(0, 'end')
            e_department.delete(0, 'end')
            e_level.delete(0, 'end')
            e_semester.delete(0, 'end')
            e_programme.delete(0, 'end')
            e_total_course.delete(0, 'end')
            e_session.delete(0, 'end')
            e_unit.delete(0, 'end')
            e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')

            messagebox.showinfo("Delete Status", "Deleted Successfully")
            con.close()

    def update():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        total_courses = e_total_course.get()
        sessions = e_session.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()

        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == "" or total_courses == "" or sessions == "" or units == "" or gpas == "" or grades == ""):
            messagebox.showinfo("Update Status", "Please, fill up the empty space....?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            cursor = con.cursor()
            cursor.execute(
                "UPDATE `student_current_result` SET `Total_Course`='" + total_courses + "',`Unit`='" + units + "',`GPA`='" + gpas + "',`Grade`='" + grades + "' WHERE  Matric_No='" + matric_nos + "' AND School='" + schools + "' AND Department='" + departments + "' AND Level='" + levels + "' AND Semester='" + semesters + "' AND Programme='" + programmes + "' ")
            cursor.execute("commit");

            e_matric_no.delete(0, 'end')
            e_school.delete(0, 'end')
            e_department.delete(0, 'end')
            e_level.delete(0, 'end')
            e_semester.delete(0, 'end')
            e_programme.delete(0, 'end')
            e_total_course.delete(0, 'end')
            e_session.delete(0, 'end')
            e_unit.delete(0, 'end')
            e_gpa.delete(0, 'end')
            e_grade.delete(0, 'end')

            messagebox.showinfo("Update Status", "Updated Successfully")
            con.close()

    def get():
        matric_nos = e_matric_no.get()
        schools = e_school.get()
        departments = e_department.get()
        levels = e_level.get()
        semesters = e_semester.get()
        programmes = e_programme.get()
        total_courses = e_total_course.get()
        sessions = e_session.get()
        units = e_unit.get()
        gpas = e_gpa.get()
        grades = e_grade.get()
        if (
                matric_nos == "" or schools == "" or departments == "" or levels == "" or semesters == "" or programmes == ""):
            messagebox.showinfo("Generating Status",
                                "Please, fill up the field of Matric. No., School, Department, Level, Semester and Programme ...?")
        else:
            con = mysql.connect(host="localhost", user="root", password="", database="student_result")
            # student_result »Table: staff_records
            curses = con.cursor()
            curses.execute(
                "SELECT * FROM `student_current_result` WHERE Matric_No='" + matric_nos + "' AND School='" + schools + "' AND Department='" + departments + "' AND Level='" + levels + "' AND Semester='" + semesters + "' AND Programme='" + programmes + "' ")
            # SELECT * FROM `student_score` WHERE 1
            # SELECT `ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Session`, `Course_Code`, `Score`, `GPA`, `Grade`, `Created_Date`, `Last_Update` FROM `student_score` WHERE 1
            rows = curses.fetchall()
            if(rows):
                for row in rows:
                    # Clear
                    e_matric_no.delete(0, 'end')
                    e_school.delete(0, 'end')
                    e_department.delete(0, 'end')
                    e_level.delete(0, 'end')
                    e_semester.delete(0, 'end')
                    e_programme.delete(0, 'end')
                    e_total_course.delete(0, 'end')
                    e_session.delete(0, 'end')
                    e_unit.delete(0, 'end')
                    e_gpa.delete(0, 'end')
                    e_grade.delete(0, 'end')
                    #  Fetch
                    e_matric_no.insert(0, row[1])
                    e_school.insert(0, row[2])
                    e_department.insert(0, row[3])
                    e_level.insert(0, row[4])
                    e_semester.insert(0, row[5])
                    e_programme.insert(0, row[6])
                    e_total_course.insert(0, row[7])
                    e_session.insert(0, row[11])
                    e_unit.insert(0, row[8])
                    e_gpa.insert(0, row[9])
                    e_grade.insert(0, row[10])

                    con.close()
            else:
                messagebox.showwarning("Status Info", "Record not found")

    def clear():
        e_matric_no.delete(0, 'end')
        e_school.delete(0, 'end')
        e_department.delete(0, 'end')
        e_level.delete(0, 'end')
        e_semester.delete(0, 'end')
        e_programme.delete(0, 'end')
        e_total_course.delete(0, 'end')
        e_session.delete(0, 'end')
        e_unit.delete(0, 'end')
        e_gpa.delete(0, 'end')
        e_grade.delete(0, 'end')
    def closes():
        csr.withdraw()
        dashboard()

    # Create window object
    csr = Tk()

    tittle = Label(csr, text="Current Semester Result", font=('bold', 19))
    tittle.place(x=450, y=5)
    closef = Button(csr, text="X", font="italic, 13", fg="red", bg="white", command=closes)
    closef.place(x=1150, y=2)

    # Matric No
    matric_no = Label(csr, text='Matric No:', font=('bold', 18))
    matric_no.place(x=20, y=100)

    e_matric_no = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_matric_no.place(x=170, y=100)

    # School
    school = Label(csr, text='School:', font=('bold', 18))
    school.place(x=20, y=150)

    school_list = ['Applied Science', 'Engineering', 'Management']

    e_school = ttk.Combobox(csr, values=school_list, width=17, font=('Modern No. 20', 25, 'bold'))
    e_school.place(x=170, y=150)

    # Department
    department = Label(csr, text='Department:', font=('bold', 18))
    department.place(x=20, y=200)

    department_list = ['Accountancy', 'Agricutural Technology', 'Architectural Engineering',
                       'Business Administrative Management', 'Civil Engineering', 'Computer Engineering',
                       'Computer Science', 'Cooporative Economics Management', 'Electrical and Electronics Engineering',
                       'Fishery Technology', 'Science Laboratary Technology', 'Statistics"']

    e_department = ttk.Combobox(csr, values=department_list, width=17, font=('Modern No. 20', 25, 'bold'))
    e_department.place(x=170, y=200)

    # Level
    level = Label(csr, text='Level:', font=('bold', 18))
    level.place(x=20, y=250)

    level_list = ['ND I', 'ND II', 'HND I', 'HND II']

    e_level = ttk.Combobox(csr, values=level_list, width=17, font=('Modern No. 20', 25, 'bold'))
    e_level.place(x=170, y=250)

    # Semester
    semester = Label(csr, text='Semester:', font=('bold', 18))
    semester.place(x=20, y=300)

    semester_list = ['First', 'Second']

    e_semester = ttk.Combobox(csr, values=semester_list, width=17, font=('Modern No. 20', 25, 'bold'))
    e_semester.place(x=170, y=300)

    # Programme
    programme = Label(csr, text='Programme:', font=('bold', 18))
    programme.place(x=20, y=350)

    programme_list = ['FT', 'PT']

    e_programme = ttk.Combobox(csr, values=programme_list, width=17, font=('Modern No. 20', 25, 'bold'))
    e_programme.place(x=170, y=350)

    # Total Course
    total_course = Label(csr, text='Total Course:', font=('bold', 18))
    total_course.place(x=20, y=400)

    e_total_course = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_total_course.place(x=170, y=400)

    # Session
    session = Label(csr, text='Session:', font=('bold', 18))
    session.place(x=550, y=100)

    e_session = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_session.place(x=700, y=100)

    # Unit
    unit = Label(csr, text='Unit:', font=('bold', 18))
    unit.place(x=550, y=150)

    e_unit = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_unit.place(x=700, y=150)

    # GPA
    gpa = Label(csr, text='GPA:', font=('bold', 18))
    gpa.place(x=550, y=200)

    e_gpa = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    # e_score = Entry(asc, width=25, fg="black", border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
    e_gpa.place(x=700, y=200)

    # Grade
    grade = Label(csr, text='Grade:', font=('bold', 18))
    grade.place(x=550, y=250)

    e_grade = Entry(csr, width=18, fg="#000", border=0, bg='white', font=('Modern No. 20', 25, 'bold'))
    e_grade.place(x=700, y=250)

    insert = Button(csr, text="Save", font="italic, 20", bg="white", command=checks)
    insert.place(x=650, y=400)

    clears = Button(csr, text="Clear", font="italic, 20", bg="white", command=clear)
    clears.place(x=650, y=480)

    generates = Button(csr, text="Generate", font="italic, 20", bg="white", command=generate)
    generates.place(x=760, y=480)

    delete = Button(csr, text="Delete", font="italic, 20", bg="white", command=delete)
    delete.place(x=760, y=400)

    update = Button(csr, text="Update", font="italic, 20", bg="white", command=update)
    update.place(x=880, y=400)

    get = Button(csr, text="Search", font="italic, 20", bg="white", command=get)
    get.place(x=1000, y=400)

    csr.title('Student Result Management System')
    csr.geometry('1200x590')
    csr.configure(bg="yellowgreen")

    # Start program
    csr.mainloop()


staff_login()