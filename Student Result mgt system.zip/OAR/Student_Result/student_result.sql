-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2022 at 11:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_result`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff_records`
--

CREATE TABLE `staff_records` (
  `ID` int(255) NOT NULL,
  `Names` varchar(75) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Position` varchar(20) NOT NULL,
  `School` text NOT NULL,
  `Department` text NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_records`
--

INSERT INTO `staff_records` (`ID`, `Names`, `Gender`, `Position`, `School`, `Department`, `Username`, `Password`, `Created_Date`, `Last_Update`) VALUES
(1, 'Omotore Adeleye Raphael', 'Male', 'Staff Adviser', 'Applied Science', 'Computer Science', 'Adewest', '12345', '2022-05-11 12:34:19', '2022-05-11 12:34:19'),
(2, 'Omotore Adeleye Raphael', 'Male', 'HOD', 'Engineering', 'Computer Engineering', 'Omotore', '12345', '2022-05-13 10:10:07', '2022-05-13 10:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `students_record`
--

CREATE TABLE `students_record` (
  `ID` int(255) NOT NULL,
  `Matric_No` varchar(35) NOT NULL,
  `Full_Name` varchar(75) NOT NULL,
  `School` text NOT NULL,
  `Department` text NOT NULL,
  `Programme` varchar(10) NOT NULL,
  `Session` varchar(15) NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students_record`
--

INSERT INTO `students_record` (`ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Programme`, `Session`, `Created_Date`, `Last_Update`) VALUES
(1, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'FT ND I', '2018/2019', '2022-05-27 20:50:51', '2022-05-27 20:50:51'),
(2, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'FT ND I', '2018/2019', '2022-05-27 20:51:01', '2022-05-27 20:51:01'),
(3, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'FT ND I', '2018/2019', '2022-05-27 20:51:09', '2022-05-27 20:51:09'),
(4, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'FT ND I', '2018/2019', '2022-05-27 20:51:16', '2022-05-27 20:51:16'),
(5, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'FT ND I', '2018/2019', '2022-05-27 20:51:23', '2022-05-27 20:51:23');

-- --------------------------------------------------------

--
-- Table structure for table `student_current_result`
--

CREATE TABLE `student_current_result` (
  `ID` int(255) NOT NULL,
  `Matric_No` varchar(35) NOT NULL,
  `School` text NOT NULL,
  `Department` text NOT NULL,
  `Level` varchar(10) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Programme` varchar(5) NOT NULL,
  `Total_Course` int(5) NOT NULL,
  `Unit` int(5) NOT NULL,
  `GPA` decimal(5,2) NOT NULL,
  `Grade` varchar(5) NOT NULL,
  `Session` varchar(15) NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_current_result`
--

INSERT INTO `student_current_result` (`ID`, `Matric_No`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Total_Course`, `Unit`, `GPA`, `Grade`, `Session`, `Created_Date`, `Last_Update`) VALUES
(2, 'FPI/CSC/18/001', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 11, 27, '1.99', 'F', '2018/2019', '2022-06-14 20:41:10', '2022-06-14 20:41:10');

-- --------------------------------------------------------

--
-- Table structure for table `student_final_result`
--

CREATE TABLE `student_final_result` (
  `ID` int(255) NOT NULL,
  `Matric_No` varchar(35) NOT NULL,
  `School` text NOT NULL,
  `Department` text NOT NULL,
  `Level` varchar(10) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Programme` varchar(5) NOT NULL,
  `Semester_No` int(11) NOT NULL,
  `GPA` decimal(5,2) NOT NULL,
  `CGPA` decimal(5,2) NOT NULL,
  `Grade` varchar(5) NOT NULL,
  `Position` varchar(20) NOT NULL,
  `Session` varchar(15) NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_score`
--

CREATE TABLE `student_score` (
  `ID` int(255) NOT NULL,
  `Matric_No` varchar(35) NOT NULL,
  `Full_Name` varchar(75) NOT NULL,
  `School` text NOT NULL,
  `Department` text NOT NULL,
  `Level` varchar(20) NOT NULL,
  `Semester` varchar(10) NOT NULL,
  `Programme` varchar(10) NOT NULL,
  `Course_Code` varchar(10) NOT NULL,
  `Score` int(3) NOT NULL,
  `Unit` int(2) NOT NULL,
  `GPA` decimal(5,2) NOT NULL,
  `Grade` varchar(3) NOT NULL,
  `Session` varchar(15) NOT NULL,
  `Created_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Last_Update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_score`
--

INSERT INTO `student_score` (`ID`, `Matric_No`, `Full_Name`, `School`, `Department`, `Level`, `Semester`, `Programme`, `Course_Code`, `Score`, `Unit`, `GPA`, `Grade`, `Session`, `Created_Date`, `Last_Update`) VALUES
(1, 'FPI/CSC/18/001', 'Kolapo', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM111', 43, 3, '2.00', 'E', '2018/2019', '2022-05-19 14:15:08', '2022-06-14 20:36:42'),
(2, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM112', 61, 3, '3.00', 'BC', '2018/2019', '2022-05-19 14:17:15', '2022-05-27 18:47:43'),
(3, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM113', 27, 4, '0.00', 'F', '2018/2019', '2022-05-19 14:29:15', '2022-05-27 18:47:43'),
(4, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM114', 46, 2, '2.25', 'D', '2018/2019', '2022-05-19 18:45:55', '2022-05-27 18:47:43'),
(5, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM115', 55, 3, '2.75', 'C', '2018/2019', '2022-05-19 18:46:32', '2022-05-27 18:47:43'),
(6, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM116', 52, 3, '2.50', 'CD', '2018/2019', '2022-05-19 18:47:00', '2022-05-27 18:47:43'),
(7, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM117', 45, 2, '2.25', 'D', '2018/2019', '2022-05-19 18:47:30', '2022-05-27 18:47:43'),
(8, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'MTH111', 32, 2, '0.00', 'F', '2018/2019', '2022-05-19 18:48:05', '2022-05-27 18:47:43'),
(9, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS101', 57, 2, '2.75', 'C', '2018/2019', '2022-05-19 18:50:17', '2022-05-27 18:47:43'),
(10, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS111', 56, 2, '2.75', 'C', '2018/2019', '2022-05-19 18:50:47', '2022-05-27 18:47:43'),
(11, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'LIB101', 61, 1, '3.00', 'BC', '2018/2019', '2022-05-19 18:51:12', '2022-05-27 18:47:43'),
(12, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM111', 50, 3, '2.50', 'CD', '2018/2019', '2022-05-20 10:54:03', '2022-05-27 18:47:43'),
(13, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM112', 75, 3, '4.00', 'A', '2018/2019', '2022-05-20 10:54:48', '2022-05-27 18:47:43'),
(14, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM113', 55, 4, '2.75', 'C', '2018/2019', '2022-05-20 10:55:18', '2022-05-27 18:47:43'),
(15, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM114', 61, 2, '3.00', 'BC', '2018/2019', '2022-05-20 10:55:50', '2022-05-27 18:47:43'),
(16, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM115', 58, 3, '2.75', 'C', '2018/2019', '2022-05-20 10:56:30', '2022-05-27 18:47:43'),
(17, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM116', 56, 3, '2.75', 'C', '2018/2019', '2022-05-20 10:57:31', '2022-05-27 18:47:43'),
(18, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM117', 75, 2, '4.00', 'A', '2018/2019', '2022-05-20 10:57:56', '2022-05-27 18:47:43'),
(19, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'MTH111', 67, 2, '3.25', 'B', '2018/2019', '2022-05-20 10:58:50', '2022-05-27 18:47:43'),
(20, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS101', 61, 2, '3.00', 'BC', '2018/2019', '2022-05-20 10:59:28', '2022-05-27 18:47:43'),
(21, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS111', 58, 2, '2.75', 'C', '2018/2019', '2022-05-20 10:59:50', '2022-05-27 18:47:43'),
(22, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'LIB101', 60, 1, '3.00', 'BC', '2018/2019', '2022-05-20 11:01:01', '2022-05-27 18:47:43'),
(23, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM111', 58, 3, '2.75', 'C', '2018/2019', '2022-05-20 12:38:19', '2022-05-27 18:47:43'),
(24, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM112', 50, 3, '2.50', 'CD', '2018/2019', '2022-05-20 12:38:55', '2022-05-27 18:47:43'),
(25, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM113', 52, 4, '2.50', 'CD', '2018/2019', '2022-05-20 12:39:33', '2022-05-27 18:47:43'),
(26, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM114', 51, 2, '2.50', 'CD', '2018/2019', '2022-05-20 12:39:57', '2022-05-27 18:47:43'),
(27, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM115', 50, 3, '2.50', 'CD', '2018/2019', '2022-05-20 12:40:38', '2022-05-27 18:47:43'),
(28, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM116', 56, 3, '2.75', 'C', '2018/2019', '2022-05-20 12:40:55', '2022-05-27 18:47:43'),
(29, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM117', 55, 2, '2.75', 'C', '2018/2019', '2022-05-20 12:41:15', '2022-05-27 18:47:43'),
(30, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'MTH111', 52, 2, '2.50', 'CD', '2018/2019', '2022-05-20 12:41:40', '2022-05-27 18:47:43'),
(31, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS101', 60, 2, '3.00', 'BC', '2018/2019', '2022-05-20 12:42:03', '2022-05-27 18:47:43'),
(32, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS111', 58, 2, '2.75', 'C', '2018/2019', '2022-05-20 12:42:27', '2022-05-27 18:47:43'),
(33, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'LIB101', 61, 1, '3.00', 'BC', '2018/2019', '2022-05-20 12:42:49', '2022-05-27 18:47:43'),
(34, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM111', 62, 3, '3.00', 'BC', '2018/2019', '2022-05-22 19:44:50', '2022-05-27 18:47:43'),
(35, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM112', 56, 3, '2.75', 'C', '2018/2019', '2022-05-22 19:45:11', '2022-05-27 18:47:43'),
(36, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM113', 61, 4, '3.00', 'BC', '2018/2019', '2022-05-22 19:47:43', '2022-05-27 18:47:43'),
(37, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM114', 52, 2, '2.50', 'CD', '2018/2019', '2022-05-22 19:48:08', '2022-05-27 18:47:43'),
(38, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM115', 53, 3, '2.50', 'CD', '2018/2019', '2022-05-22 19:48:45', '2022-05-27 18:47:43'),
(39, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM116', 53, 3, '2.50', 'CD', '2018/2019', '2022-05-22 19:49:06', '2022-05-27 18:47:43'),
(40, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM117', 63, 2, '3.00', 'BC', '2018/2019', '2022-05-22 19:49:32', '2022-05-27 18:47:43'),
(41, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'MTH111', 45, 2, '2.25', 'D', '2018/2019', '2022-05-22 19:50:14', '2022-05-27 18:47:43'),
(42, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS101', 58, 2, '2.75', 'C', '2018/2019', '2022-05-22 19:50:44', '2022-05-27 18:47:43'),
(43, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS111', 56, 2, '2.75', 'C', '2018/2019', '2022-05-22 19:51:31', '2022-05-27 18:47:43'),
(44, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'LIB101', 61, 1, '3.00', 'BC', '2018/2019', '2022-05-22 19:51:56', '2022-05-27 18:47:43'),
(45, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM111', 60, 3, '3.00', 'BC', '2018/2019', '2022-05-22 19:54:39', '2022-05-27 18:47:43'),
(46, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM112', 51, 3, '2.50', 'CD', '2018/2019', '2022-05-22 19:55:17', '2022-05-27 18:47:43'),
(47, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM113', 55, 4, '2.75', 'C', '2018/2019', '2022-05-22 19:55:32', '2022-05-27 18:47:43'),
(48, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM114', 45, 2, '2.25', 'D', '2018/2019', '2022-05-22 19:55:49', '2022-05-27 18:47:43'),
(49, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM115', 67, 3, '3.25', 'B', '2018/2019', '2022-05-22 19:56:19', '2022-05-27 18:47:43'),
(50, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM116', 55, 3, '2.75', 'C', '2018/2019', '2022-05-22 19:56:38', '2022-05-27 18:47:43'),
(51, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'COM117', 62, 2, '3.00', 'BC', '2018/2019', '2022-05-22 19:56:57', '2022-05-27 18:47:43'),
(52, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'MTH111', 48, 2, '2.25', 'D', '2018/2019', '2022-05-22 19:57:20', '2022-05-27 18:47:43'),
(53, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS101', 55, 2, '2.75', 'C', '2018/2019', '2022-05-22 19:57:44', '2022-05-27 18:47:43'),
(54, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'GNS111', 62, 2, '3.00', 'BC', '2018/2019', '2022-05-22 19:58:29', '2022-05-27 18:47:43'),
(55, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'First', 'FT', 'LIB101', 57, 1, '2.75', 'C', '2018/2019', '2022-05-22 19:59:01', '2022-05-27 18:47:43'),
(56, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM121', 55, 3, '2.75', 'C', '2018/2019', '2022-05-22 20:06:40', '2022-05-27 18:47:43'),
(57, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM122', 50, 3, '2.50', 'CD', '2018/2019', '2022-05-22 20:08:13', '2022-05-27 18:47:43'),
(58, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM123', 50, 3, '2.50', 'CD', '2018/2019', '2022-05-22 20:08:46', '2022-05-27 18:47:43'),
(59, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM124', 40, 3, '2.00', 'E', '2018/2019', '2022-05-22 20:09:04', '2022-05-27 18:47:43'),
(60, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM125', 51, 3, '2.50', 'CD', '2018/2019', '2022-05-22 20:09:42', '2022-05-27 18:47:43'),
(61, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM126', 41, 3, '2.00', 'E', '2018/2019', '2022-05-22 20:09:59', '2022-05-27 18:47:43'),
(62, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM127', 46, 2, '2.25', 'D', '2018/2019', '2022-05-22 20:10:27', '2022-05-27 18:47:43'),
(63, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS121', 52, 2, '2.50', 'CD', '2018/2019', '2022-05-22 20:11:06', '2022-05-27 18:47:43'),
(64, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS102', 43, 2, '2.00', 'E', '2018/2019', '2022-05-22 20:11:27', '2022-05-27 18:47:43'),
(65, 'FPI/CSC/18/001', 'KHVJGFJHF', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'EED126', 55, 2, '2.75', 'C', '2018/2019', '2022-05-22 20:11:59', '2022-05-27 18:47:43'),
(66, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM121', 53, 3, '2.50', 'CD', '2018/2019', '2022-05-22 20:14:10', '2022-05-27 18:47:43'),
(67, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM122', 58, 3, '2.75', 'C', '2018/2019', '2022-05-22 20:14:27', '2022-05-27 18:47:43'),
(68, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM123', 65, 3, '3.25', 'B', '2018/2019', '2022-05-22 20:14:39', '2022-05-27 18:47:43'),
(69, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM124', 67, 3, '3.25', 'B', '2018/2019', '2022-05-22 20:15:39', '2022-05-27 18:47:43'),
(70, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM125', 63, 3, '3.00', 'BC', '2018/2019', '2022-05-22 20:15:53', '2022-05-27 18:47:43'),
(71, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM126', 52, 3, '2.50', 'CD', '2018/2019', '2022-05-22 20:16:15', '2022-05-27 18:47:43'),
(72, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM127', 68, 2, '3.25', 'B', '2018/2019', '2022-05-22 20:16:39', '2022-05-27 18:47:43'),
(73, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS121', 52, 2, '2.50', 'CD', '2018/2019', '2022-05-22 20:17:10', '2022-05-27 18:47:43'),
(74, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS102', 48, 2, '2.25', 'D', '2018/2019', '2022-05-22 20:17:37', '2022-05-27 18:47:43'),
(75, 'FPI/CSC/18/002', 'GIDHHJGHDJJJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'EED126', 66, 2, '3.25', 'B', '2018/2019', '2022-05-22 20:17:54', '2022-05-27 18:47:43'),
(76, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM121', 73, 3, '3.50', 'AB', '2018/2019', '2022-05-23 11:41:06', '2022-05-27 18:47:43'),
(77, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM122', 55, 3, '2.75', 'C', '2018/2019', '2022-05-23 11:41:24', '2022-05-27 18:47:43'),
(78, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM123', 62, 3, '3.00', 'BC', '2018/2019', '2022-05-23 11:41:47', '2022-05-27 18:47:43'),
(79, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM124', 65, 3, '3.25', 'B', '2018/2019', '2022-05-23 11:42:11', '2022-05-27 18:47:43'),
(80, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM125', 76, 3, '4.00', 'A', '2018/2019', '2022-05-23 11:42:31', '2022-05-27 18:47:43'),
(81, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM126', 57, 3, '2.75', 'C', '2018/2019', '2022-05-23 11:42:53', '2022-05-27 18:47:43'),
(82, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM127', 72, 2, '3.50', 'AB', '2018/2019', '2022-05-23 11:43:20', '2022-05-27 18:47:43'),
(83, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS121', 50, 2, '2.50', 'CD', '2018/2019', '2022-05-23 11:43:51', '2022-05-27 18:47:43'),
(84, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS102', 57, 2, '2.75', 'C', '2018/2019', '2022-05-23 11:44:08', '2022-05-27 18:47:43'),
(85, 'FPI/CSC/18/003', 'bali', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'EED126', 55, 2, '2.75', 'C', '2018/2019', '2022-05-23 11:44:45', '2022-05-27 18:47:43'),
(86, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM121', 68, 3, '3.25', 'B', '2018/2019', '2022-05-23 11:51:08', '2022-05-27 18:47:43'),
(87, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM122', 60, 3, '3.00', 'BC', '2018/2019', '2022-05-23 11:51:21', '2022-05-27 18:47:43'),
(88, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM123', 60, 3, '3.00', 'BC', '2018/2019', '2022-05-23 11:51:32', '2022-05-27 18:47:43'),
(89, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM124', 66, 3, '3.25', 'B', '2018/2019', '2022-05-23 11:51:46', '2022-05-27 18:47:43'),
(90, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM125', 68, 3, '3.25', 'B', '2018/2019', '2022-05-23 11:52:06', '2022-05-27 18:47:43'),
(91, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM126', 70, 3, '3.50', 'AB', '2018/2019', '2022-05-23 11:52:33', '2022-05-27 18:47:43'),
(92, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM127', 71, 2, '3.50', 'AB', '2018/2019', '2022-05-23 11:53:37', '2022-05-27 18:47:43'),
(93, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS121', 68, 2, '3.25', 'B', '2018/2019', '2022-05-23 11:54:06', '2022-05-27 18:47:43'),
(94, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS102', 66, 2, '3.25', 'B', '2018/2019', '2022-05-23 11:54:24', '2022-05-27 18:47:43'),
(95, 'FPI/CSC/18/004', 'MVGJGJGDJ', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'EED126', 53, 2, '2.50', 'CD', '2018/2019', '2022-05-23 11:54:57', '2022-05-27 18:47:43'),
(96, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM121', 75, 3, '4.00', 'A', '2018/2019', '2022-05-23 11:59:46', '2022-05-27 18:47:43'),
(97, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM122', 53, 3, '2.50', 'CD', '2018/2019', '2022-05-23 12:00:00', '2022-05-27 18:47:43'),
(98, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM123', 61, 3, '3.00', 'BC', '2018/2019', '2022-05-23 12:00:18', '2022-05-27 18:47:43'),
(99, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM124', 76, 3, '4.00', 'A', '2018/2019', '2022-05-23 12:00:32', '2022-05-27 18:47:43'),
(100, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM125', 70, 3, '3.50', 'AB', '2018/2019', '2022-05-23 12:05:13', '2022-05-27 18:47:43'),
(101, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM126', 55, 3, '2.75', 'C', '2018/2019', '2022-05-23 12:05:27', '2022-05-27 18:47:43'),
(102, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'COM127', 70, 2, '3.50', 'AB', '2018/2019', '2022-05-23 12:06:46', '2022-05-27 18:47:43'),
(103, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS121', 63, 2, '3.00', 'BC', '2018/2019', '2022-05-23 12:07:59', '2022-05-27 18:47:43'),
(104, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'GNS102', 40, 2, '2.00', 'E', '2018/2019', '2022-05-23 12:08:26', '2022-05-27 18:47:43'),
(105, 'FPI/CSC/18/005', 'HDGHOWIURHFN', 'Applied Science', 'Computer Science', 'ND I', 'Second', 'FT', 'EED126', 65, 2, '3.25', 'B', '2018/2019', '2022-05-23 12:08:42', '2022-05-27 18:47:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff_records`
--
ALTER TABLE `staff_records`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `students_record`
--
ALTER TABLE `students_record`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_current_result`
--
ALTER TABLE `student_current_result`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_final_result`
--
ALTER TABLE `student_final_result`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_score`
--
ALTER TABLE `student_score`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `staff_records`
--
ALTER TABLE `staff_records`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students_record`
--
ALTER TABLE `students_record`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_current_result`
--
ALTER TABLE `student_current_result`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_final_result`
--
ALTER TABLE `student_final_result`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_score`
--
ALTER TABLE `student_score`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
