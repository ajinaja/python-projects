from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql
from mysql.connector import cursor

dashboard = Tk()
dashboard.geometry("700x600+300+60")
dashboard.title("Dashboard")

title_label = Label(dashboard, text="Computer Lab. Management System", fg='white', bg='blue', width=200, font=('bold', 20)).pack()


def insert_item():
    name = e_name.get()
    brand = e_brand.get()
    model = e_model.get()
    status = e_status.get()
    quantity = e_quantity.get()

    if name == "" or brand == "" or model == "" or status == "" or quantity == "":
        MessageBox.showinfo("Insert Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="py_lab")
        cursor = con.cursor()
        cursor.execute("insert into lab values('" + name + "','" + quantity + "','" + brand + "','" + model + "','" + status + "')")
        cursor.execute("commit")

        e_name.delete(0, 'end')
        e_brand.delete(0, 'end')
        e_model.delete(0, 'end')
        e_status.delete(0, 'end')
        e_quantity.delete(0, 'end')
        show()
        MessageBox.showinfo("Insert Status", "Item Successfully Added")
        con.close()

def show():
    con = mysql.connect(host="localhost", user="root", password="", database="py_lab")
    cursor = con.cursor()
    cursor.execute("select * from lab")
    rows = cursor.fetchall()
    list.delete(0, list.size())

    for row in rows:
        insertData = str(row[0])+ '        '+ row[1] +'    '+ row[2] +'    '+ row[3] +'    '+ row[4]
        list.insert(list.size()+1, insertData)

    con.close();

def get():
    if(e_name.get() == ""):
        MessageBox.showinfo("Fetch  Status", "name is compulsory for delete")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="py_lab")
        cursor = con.cursor()
        cursor.execute("select * from lab where name='"+ e_name.get() +"'")
        rows = cursor.fetchall()


        for row in rows:
            e_quantity.insert(0, row[1])
            e_brand.insert(0, row[2])
            e_model.insert(0, row[3])
            e_status.insert(0, row[4])

        con.close()
def update():
    name = e_name.get()
    brand = e_brand.get()
    model = e_model.get()
    status = e_status.get()
    quantity = e_quantity.get()

    if name == "" or brand == "" or model == "" or status == "" or quantity == "":
        MessageBox.showinfo("Update Status", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="py_lab")
        cursor = con.cursor()
        cursor.execute("Update lab set brand='"+ brand +"', model='"+ model +"', quantity='"+ quantity +"', status='"+ status +"' where name='"+ name +"'")
        cursor.execute("commit");

        e_name.delete(0, 'end')
        e_brand.delete(0, 'end')
        e_model.delete(0, 'end')
        e_status.delete(0, 'end')
        e_quantity.delete(0, 'end')
        show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close()


name = Label(dashboard, text="Enter Item name:", fg='blue', font=('bold', 12))
name.place(x=50, y=90)
e_name = Entry(dashboard,  width=30, font=('bold', 12))
e_name.place(x=200, y=90)

brand = Label(dashboard, text="Enter Item Brand:", fg='blue', font=('bold', 12))
brand.place(x=50, y=130)
e_brand = Entry(dashboard, width=30, font=('bold', 12))
e_brand.place(x=200, y=130)

model = Label(dashboard, text="Enter Item Model:", fg='blue', font=('bold', 12))
model.place(x=50, y=170)
e_model = Entry(dashboard, width=30, font=('bold', 12))
e_model.place(x=200, y=170)

quantity = Label(dashboard, text="Enter Item Quantity:", fg='blue', font=('bold', 12))
quantity.place(x=50, y=210)
e_quantity = Entry(dashboard, width=30, font=('bold', 12))
e_quantity.place(x=200, y=210)

status = Label(dashboard, text="Enter Item Status:", fg='blue', font=('bold', 12))
status.place(x=50, y=250)
e_status = Entry(dashboard, width=30, font=('bold', 12))
e_status.place(x=200, y=250)


insert = Button(dashboard, text="insert", font=("italic", 10), bg="white", command=insert_item)
insert.place(x=50, y=290)

update = Button(dashboard, text="update", font=("italic", 10), bg="white", command=update)
update.place(x=150, y=290)

get = Button(dashboard, text="get", font=("italic", 10), bg="white", command=get)
get.place(x=250, y=290)

list = Listbox(dashboard, width=50, font=("italic, 15"))
list.place(x=50, y=330)
# list.pack()
show()




dashboard.mainloop()