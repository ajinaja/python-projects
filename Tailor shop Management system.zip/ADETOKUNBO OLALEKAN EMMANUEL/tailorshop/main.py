from tkinter import *
import tkinter.messagebox as MessageBox
import mysql.connector as mysql

import datetime

app = Tk()


# insect to database
def save():
    customername = customer_name.get();
    customerphoneno = customer_phone.get();
    waistsize = waist_size.get();
    trouserheight = trouser_height.get();
    topheight = top_height.get();
    shouldersize = shoulder_size.get();
    chestsize = chest_size.get();
    datecollection = date_collection.get();

    if (
            customername == "" or customerphoneno == "" or waistsize == "" or trouserheight == "" or topheight == "" or shouldersize == "" or chestsize == "" or datecollection == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="tailor")
        cursor = con.cursor()
        cursor.execute(
            "insert into shop values('" + customername + "','" + customerphoneno + "', '" + waistsize + "', '" + trouserheight + "','" + topheight + "', '" + shouldersize + "','" + chestsize + "', '" + datecollection + "')")
        cursor.execute("commit");

        customer_name.delete(0, 'end')
        customer_phone.delete(0, 'end')
        waist_size.delete(0, 'end')
        trouser_height.delete(0, 'end')
        top_height.delete(0, 'end')
        shoulder_size.delete(0, 'end')
        chest_size.delete(0, 'end')
        date_collection.delete(0, 'end')

        # show()
        MessageBox.showinfo("Insert Status", "Customer size has been saved Successfully")
        con.close();


# delete from database
def delete():
    if (customer_phone.get() == ""):
        MessageBox.showinfo("Delete  Status", "Customer Phone Number feild is compulsary")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="tailor")
        cursor = con.cursor()
        cursor.execute("delete from shop where customerphoneno='" + customer_phone.get() + "'")
        cursor.execute("commit");

        customer_name.delete(0, 'end')
        customer_phone.delete(0, 'end')
        waist_size.delete(0, 'end')
        trouser_height.delete(0, 'end')
        top_height.delete(0, 'end')
        shoulder_size.delete(0, 'end')
        chest_size.delete(0, 'end')
        date_collection.delete(0, 'end')
        # show()
        MessageBox.showinfo("Delete Status", "Customer size has been deleted successfully")
        con.close();

# update database
def update():
    customername = customer_name.get();
    customerphoneno = customer_phone.get();
    waistsize = waist_size.get();
    trouserheight = trouser_height.get();
    topheight = top_height.get();
    shouldersize = shoulder_size.get();
    chestsize = chest_size.get();
    datecollection = date_collection.get();

    if (
            customername == "" or customerphoneno == "" or waistsize == "" or trouserheight == "" or topheight == "" or shouldersize == "" or chestsize == "" or datecollection == ""):
        MessageBox.showerror("Insert Field", "All Fields are required")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="tailor")
        cursor = con.cursor()
        cursor.execute(
            "Update shop set customername='" + customername + "', customerphoneno='" + customerphoneno + "', waistsize='" + waistsize + "', trouserheight='" + trouserheight + "', topheight='" + topheight + "', shouldersize='" + shouldersize + "', chestsize='" + chestsize + "', datecollection='" + datecollection + "' where customerphoneno='" + customer_phone.get() + "'")
        cursor.execute("commit");

        customer_name.delete(0, 'end')
        customer_phone.delete(0, 'end')
        waist_size.delete(0, 'end')
        trouser_height.delete(0, 'end')
        top_height.delete(0, 'end')
        shoulder_size.delete(0, 'end')
        chest_size.delete(0, 'end')
        date_collection.delete(0, 'end')
        # show()
        MessageBox.showinfo("Update Status", "Updated Successfully")
        con.close();

# get from database
def get():
    if(customer_phone.get() == ""):
        MessageBox.showinfo("Fetch  Status", "Customer Phone Numberr field is compulsory")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="tailor")
        cursor = con.cursor()
        cursor.execute("select * from shop where customerphoneno='"+ customer_phone.get() +"'")
        rows = cursor.fetchall()


        for row in rows:
            customer_name.insert(0, row[0])
            waist_size.insert(0, row[2])
            trouser_height.insert(0, row[3])
            top_height.insert(0, row[4])
            shoulder_size.insert(0, row[5])
            chest_size.insert(0, row[6])
            date_collection.insert(0, row[7])


        con.close();

date = datetime.datetime.now().date()
timee = datetime.datetime.now().time()

# components
heading = Label(app, text="Tailor Shop Management System", font=('Goudy 30 bold'), fg='black', bg="cyan")
heading.place(x=200, y=0)

date_l = Label(app, text="Today's Date: " + str(date), font=('arial 12 '), fg='black', bg="cyan")
date_l.place(x=550, y=480)

time_l = Label(app, text="Today's Time: " + str(timee), font=('arial 12 '), fg='black', bg="cyan")
time_l.place(x=780, y=480)



# customer_name
customer_name = Label(app, text="Customer Name", font=('Goudy 12'), fg='black', bg="cyan")
customer_name.place(x=30, y=70)
customer_name = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
customer_name.place(x=30, y=100, height=35, width=400)

# customer_phone
customer_phone = Label(app, text="Customer Phone", font=('Goudy 12'), fg='black', bg="cyan")
customer_phone.place(x=30, y=150)
customer_phone = Entry(width=25, font=('arial 12 '), bg='magenta', fg='white')
customer_phone.place(x=30, y=180, height=35, width=400)

# waist_size
waist_size = Label(app, text="Waist Size", font=('Goudy 12'), fg='black', bg="cyan")
waist_size.place(x=30, y=230)
waist_size = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
waist_size.place(x=30, y=260, height=35, width=400)

# trouser_height
trouser_height = Label(app, text="Trouser Height", font=('Goudy 12'), fg='black', bg="cyan")
trouser_height.place(x=500, y=70)
trouser_height = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
trouser_height.place(x=500, y=100, height=35, width=400)

# top_height
top_height = Label(app, text="Top Height", font=('Goudy 12'), fg='black', bg="cyan")
top_height.place(x=500, y=150)
top_height = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
top_height.place(x=500, y=180, height=35, width=400)

# shoulder_size
shoulder_size = Label(app, text="Shoulder Size", font=('Goudy 12'), fg='black', bg="cyan")
shoulder_size.place(x=500, y=230)
shoulder_size = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
shoulder_size.place(x=500, y=260, height=35, width=400)

# chest_size
chest_size = Label(app, text="Chest Size", font=('Goudy 12'), fg='black', bg="cyan")
chest_size.place(x=30, y=310)
chest_size = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
chest_size.place(x=30, y=340, height=35, width=400)

# date_collection
date_collection = Label(app, text="Date of Collection", font=('Goudy 12'), fg='black', bg="cyan")
date_collection.place(x=500, y=310)
date_collection = Entry(width=25, font=('arial 12'), bg='magenta', fg='white')
date_collection.place(x=500, y=340, height=35, width=400)

# button
save = Button(app, text="SAVE", width=15, height=2, bg='magenta', command=save, cursor="hand2")
save.place(x=100, y=420)

delete = Button(app, text="DELETE", width=15, height=2, bg='red', command=delete, cursor="hand2")
delete.place(x=300, y=420)

update = Button(app, text="UPDATE", width=15, height=2, bg='magenta', command=update, cursor="hand2")
update.place(x=500, y=420)

get = Button(app, text="GET", width=15, height=2, bg='magenta', command=get, cursor="hand2")
get.place(x=700, y=420)

app.title("Tailor Shop Management System")
app.geometry('950x502')
app.configure(bg="cyan")

app.mainloop()

